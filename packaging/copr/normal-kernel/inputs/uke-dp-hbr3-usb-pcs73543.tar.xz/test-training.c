#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

typedef uint8_t u8;
typedef uint32_t u32;

enum drm_dp_phy { DP_PHY_DPRX, DP_PHY_LTTPR1 };
enum { DP_TRAINING_NONE, DP_TRAINING_1, DP_TRAINING_2 };
enum {
    DP_TRAINING_PATTERN_DISABLE, DP_TRAINING_PATTERN_1, DP_TRAINING_PATTERN_2,
    DP_TRAINING_PATTERN_3, DP_TRAINING_PATTERN_4 = 7,
    DP_LINK_SCRAMBLING_DISABLE = 0x20, DP_TRAINING_PATTERN_SET = 0x102,
    REG_DP_STATE_CTRL = 0x40, DP_LINK_STATUS_SIZE = 6,
};
#define DP_TRAINING_PATTERN_SET_PHY_REPEATER(phy) (0xf0010 + (phy))
#define drm_dbg_dp(...) ((void)0)

struct msm_dp_link_info {
    unsigned int num_lanes, rate, rate_set, supported_rates[4];
    bool use_rate_set;
};
struct msm_dp_link {
    struct msm_dp_link_info link_params, link_caps;
    struct { unsigned int p_level, v_level; } phy_params;
};
struct msm_dp_panel { u8 dpcd[16]; };
struct msm_dp_ctrl_private { struct msm_dp_link *link; void *aux; };

static bool hbr3_available, equalized;
static u8 recovered, current_pattern;
static int write_error, read_error, reads, writes, updates, waits, last_address;

static bool uke_dp_hbr3_available(void) { return hbr3_available; }
static bool drm_dp_tps4_supported(const u8 *dpcd) { return dpcd[0] == 4; }
static bool drm_dp_tps3_supported(const u8 *dpcd) { return dpcd[0] == 3; }
static void msm_dp_write_link(void *ctrl, int reg, int value) {}
static int msm_dp_ctrl_set_pattern_state_bit(void *ctrl, u32 bit)
{
    assert(bit >= 2 && bit <= 4);
    return 0;
}
static int drm_dp_read_channel_eq_delay(void *aux, const u8 *dpcd,
                                        enum drm_dp_phy phy, bool uhbr)
{
    return 400;
}
static void fsleep(int delay) { assert(delay == 400); waits++; }
static int drm_dp_dpcd_write_byte(void *aux, int address, u8 value)
{
    last_address = address;
    current_pattern = value;
    writes++;
    return write_error;
}
static int drm_dp_dpcd_read_phy_link_status(void *aux, enum drm_dp_phy phy, u8 *status)
{
    reads++;
    status[0] = recovered;
    status[1] = equalized;
    return read_error;
}
static bool drm_dp_clock_recovery_ok(const u8 *status, unsigned int lanes)
{
    unsigned int mask = (1U << lanes) - 1;
    return (status[0] & mask) == mask;
}
static bool drm_dp_channel_eq_ok(const u8 *status, unsigned int lanes)
{
    return status[1] && drm_dp_clock_recovery_ok(status, lanes);
}
static void msm_dp_link_adjust_levels(void *link, const u8 *status) {}
static int msm_dp_ctrl_update_phy_vx_px(void *ctrl, enum drm_dp_phy phy)
{
    updates++;
    return 0;
}

#include "actual-training.inc"

int main(void)
{
    struct msm_dp_link link = {
        .link_caps = { .rate = 810000, .num_lanes = 4 },
        .link_params = { .rate = 810000, .num_lanes = 4 },
    };
    struct msm_dp_ctrl_private ctrl = { .link = &link };
    struct msm_dp_panel panel = { .dpcd = { 4 } };
    u8 status[DP_LINK_STATUS_SIZE] = { 3 };
    int step = DP_TRAINING_NONE;

    write_error = -EREMOTEIO;
    assert(msm_dp_ctrl_link_train_2(&ctrl, &panel, &step, DP_PHY_DPRX) == -EREMOTEIO);
    assert(step == DP_TRAINING_NONE && !reads && !updates && !waits);
    assert(current_pattern == DP_TRAINING_PATTERN_4);
    assert(msm_dp_ctrl_clear_training_pattern(&ctrl, &panel, DP_PHY_DPRX) == -EREMOTEIO);
    assert(!waits && writes == 2 && current_pattern == DP_TRAINING_PATTERN_DISABLE);
    write_error = 0;
    read_error = -ETIMEDOUT;
    assert(msm_dp_ctrl_link_train_2(&ctrl, &panel, &step, DP_PHY_DPRX) == -ETIMEDOUT);
    assert(step == DP_TRAINING_NONE && reads == 1 && !updates);
    read_error = 0;
    assert(msm_dp_ctrl_link_train_2(&ctrl, &panel, &step, DP_PHY_DPRX) == -ENOLINK);
    assert(step == DP_TRAINING_2 && reads == 2 && !updates);

    recovered = 15;
    step = DP_TRAINING_NONE;
    assert(msm_dp_ctrl_link_train_2(&ctrl, &panel, &step, DP_PHY_DPRX) == -ETIMEDOUT);
    assert(step == DP_TRAINING_2 && reads == 8 && updates == 5);
    equalized = true;
    step = DP_TRAINING_NONE;
    panel.dpcd[0] = 3;
    assert(!msm_dp_ctrl_link_train_2(&ctrl, &panel, &step, DP_PHY_LTTPR1));
    assert(reads == 9 && updates == 5 && step == DP_TRAINING_NONE);
    assert(last_address == DP_TRAINING_PATTERN_SET_PHY_REPEATER(DP_PHY_LTTPR1));
    assert(current_pattern == (DP_TRAINING_PATTERN_3 | DP_LINK_SCRAMBLING_DISABLE));
    assert(!msm_dp_ctrl_clear_training_pattern(&ctrl, &panel, DP_PHY_LTTPR1));

    hbr3_available = true;
    assert(!msm_dp_ctrl_retry_link_params(&ctrl, &panel, DP_TRAINING_1, status));
    assert(link.link_params.rate == 540000 && link.link_params.num_lanes == 4);
    assert(!msm_dp_ctrl_retry_link_params(&ctrl, &panel, DP_TRAINING_2, status));
    assert(link.link_params.rate == 810000 && link.link_params.num_lanes == 2);
    assert(!msm_dp_ctrl_retry_link_params(&ctrl, &panel, DP_TRAINING_2, status));
    assert(link.link_params.rate == 540000 && link.link_params.num_lanes == 2);
    assert(!msm_dp_ctrl_retry_link_params(&ctrl, &panel, DP_TRAINING_2, status));
    assert(link.link_params.rate == 810000 && link.link_params.num_lanes == 1);

    link.link_params = link.link_caps;
    assert(!msm_dp_ctrl_retry_link_params(&ctrl, &panel, DP_TRAINING_2, status));
    status[0] = 0;
    assert(!msm_dp_ctrl_retry_link_params(&ctrl, &panel, DP_TRAINING_1, status));
    assert(link.link_params.rate == 270000 && link.link_params.num_lanes == 4);
    hbr3_available = false;
    link.link_params = link.link_caps;
    status[0] = 15;
    assert(!msm_dp_ctrl_retry_link_params(&ctrl, &panel, DP_TRAINING_2, status));
    assert(link.link_params.rate == 810000 && link.link_params.num_lanes == 2);
    link.link_params = (struct msm_dp_link_info) {
        .rate = 270000, .num_lanes = 2, .rate_set = 1, .use_rate_set = true,
        .supported_rates = { 162000, 270000 },
    };
    assert(!msm_dp_ctrl_retry_link_params(&ctrl, &panel, DP_TRAINING_1, status));
    assert(link.link_params.rate == 162000 && link.link_params.num_lanes == 2);
    puts("Native TPS4, AUX errors, clock recovery and four HBR2/HBR3 retry states passed.");
}
