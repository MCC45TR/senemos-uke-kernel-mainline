set -Eeuo pipefail
source=$1
out=$2
compiler=$3
work=$(cd -- "$(dirname -- "$0")" && pwd)
mkdir -p "$out"
for name in msm_dp_ctrl_train_pattern_set msm_dp_ctrl_clear_training_pattern \
    msm_dp_ctrl_link_train_2 msm_dp_ctrl_link_rate_down_shift \
    msm_dp_ctrl_link_lane_down_shift msm_dp_ctrl_clock_recovery_any_ok \
    msm_dp_ctrl_retry_link_params; do
    sed -n "/^static .* ${name}(/,/^}/p" "$source"
done > "$out/actual-training.inc"
[[ $(grep -c '^}' "$out/actual-training.inc") == 7 ]]
for mode in plain sanitized; do
    flags=()
    if [[ $mode == sanitized ]]; then
        flags=(-fsanitize=address,undefined -fno-omit-frame-pointer -no-pie)
    fi
    binary="$out/dp-training-$compiler-$mode"
    "$compiler" -std=gnu11 -Wall -Wextra -Werror -Wno-unused-parameter \
        "${flags[@]}" -I"$out" "$work/test-training.c" -o "$binary"
    ASAN_OPTIONS=detect_leaks=0 "$binary"
done
