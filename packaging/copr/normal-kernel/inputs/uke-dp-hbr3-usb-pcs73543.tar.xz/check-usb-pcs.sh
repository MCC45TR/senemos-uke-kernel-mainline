set -Eeuo pipefail
source=$1
out=$2
compiler=$3
work=$(cd -- "$(dirname -- "$0")" && pwd)
mkdir -p "$out"
for name in qmp_combo_usb_init qmp_combo_usb_exit qmp_combo_uke_reconfigure; do
    sed -n "/^static int ${name}(/,/^}/p" "$source"
done > "$out/actual-usb-pcs.inc"
[[ $(grep -c '^}' "$out/actual-usb-pcs.inc") == 3 ]]
power_on=$(sed -n '/^static int qmp_combo_usb_power_on(/,/^}/p' "$source")
grep -Fq 'qphy_setbits(pcs, cfg->regs[QPHY_PCS_POWER_DOWN_CONTROL], SW_PWRDN);' <<< "$power_on"
grep -Fq 'qmp_combo_usb_power_off(phy);' <<< "$power_on"
! grep -Eq 'clk_.*pipe_clk' <<< "$power_on"
for mode in plain sanitized; do
    flags=()
    if [[ $mode == sanitized ]]; then
        flags=(-fsanitize=address,undefined -fno-omit-frame-pointer -no-pie)
    fi
    binary="$out/usb-pcs-$compiler-$mode"
    "$compiler" -std=gnu11 -Wall -Wextra -Werror -Wno-unused-parameter \
        "${flags[@]}" -I"$out" "$work/test-usb-pcs.c" -o "$binary"
    ASAN_OPTIONS=detect_leaks=0 "$binary"
done
