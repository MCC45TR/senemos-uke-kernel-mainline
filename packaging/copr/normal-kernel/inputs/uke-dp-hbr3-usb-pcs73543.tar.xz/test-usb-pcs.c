#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stdio.h>

enum { QMPPHY_MODE_USB3DP, QMPPHY_MODE_DP_ONLY, QMPPHY_MODE_USB3_ONLY };
enum { DP_PHY_PD_CTL_PSR_PWRDN = 1, QSERDES_DP_PHY_PD_CTL = 0 };
#define dev_err(...) ((void)0)

struct qmp_combo;
struct phy { struct qmp_combo *qmp; };
struct qmp_phy_cfg { void (*dp_aux_init)(struct qmp_combo *qmp); };
struct qmp_combo {
    struct phy *usb_phy;
    const struct qmp_phy_cfg *cfg;
    char *dp_dp_phy;
    unsigned int phy_mutex, init_count, usb_init_count, dp_init_count;
    int qmpphy_mode, uke_route_error;
    bool uke_gdsc, usb_powered_on;
};
static unsigned int common_start, common_stop, usb_start, usb_stop, aux_init;
static int start_error;
static bool pipe_enabled;
static struct qmp_combo *phy_get_drvdata(struct phy *phy) { return phy->qmp; }
static void mutex_lock(unsigned int *lock) { assert(!(*lock)++); }
static void mutex_unlock(unsigned int *lock) { assert((*lock)-- == 1); }
static void writel(unsigned int value, void *reg) { assert(pipe_enabled); }
static void init_aux_mock(struct qmp_combo *qmp)
{
    assert(pipe_enabled && qmp->init_count > 0);
    aux_init++;
}
static int qmp_combo_com_init(struct qmp_combo *qmp, bool force)
{
    if (qmp->uke_route_error)
        return qmp->uke_route_error;
    if (force || !qmp->init_count++) {
        assert(!pipe_enabled);
        pipe_enabled = true;
        common_start++;
    }
    return 0;
}
static int qmp_combo_com_exit(struct qmp_combo *qmp, bool force)
{
    assert(qmp->init_count > 0);
    if (force || !--qmp->init_count) {
        assert(pipe_enabled);
        assert(!qmp->usb_powered_on);
        pipe_enabled = false;
        common_stop++;
    }
    return 0;
}
static int qmp_combo_usb_power_on(struct phy *phy)
{
    assert(pipe_enabled);
    assert(!phy->qmp->usb_powered_on);
    usb_start++;
    if (start_error)
        return start_error;
    phy->qmp->usb_powered_on = true;
    return 0;
}
static int qmp_combo_usb_power_off(struct phy *phy)
{
    assert(pipe_enabled);
    assert(phy->qmp->usb_powered_on);
    phy->qmp->usb_powered_on = false;
    usb_stop++;
    return 0;
}

#include "actual-usb-pcs.inc"

int main(void)
{
    const struct qmp_phy_cfg cfg = { .dp_aux_init = init_aux_mock };
    char dp_reg;
    struct qmp_combo qmp = {
        .cfg = &cfg, .dp_dp_phy = &dp_reg, .uke_gdsc = true,
        .qmpphy_mode = QMPPHY_MODE_DP_ONLY,
    };
    struct phy phy = { .qmp = &qmp };
    qmp.usb_phy = &phy;

    assert(!qmp_combo_usb_init(&phy));
    assert(pipe_enabled && qmp.usb_init_count == 1 && !usb_start);
    assert(!qmp_combo_usb_exit(&phy));
    assert(!pipe_enabled && !qmp.init_count && !qmp.usb_init_count && !usb_stop);

    qmp.qmpphy_mode = QMPPHY_MODE_USB3_ONLY;
    start_error = -ETIMEDOUT;
    assert(qmp_combo_usb_init(&phy) == -ETIMEDOUT);
    assert(!pipe_enabled && common_start == common_stop && !qmp.usb_init_count);

    assert(!qmp_combo_com_init(&qmp, false));
    qmp.dp_init_count = 1;
    assert(qmp_combo_usb_init(&phy) == -ETIMEDOUT);
    assert(pipe_enabled && qmp.init_count == 1 && !qmp.usb_init_count);
    start_error = 0;
    assert(!qmp_combo_usb_init(&phy));
    assert(qmp.usb_powered_on && qmp.init_count == 2);
    qmp.qmpphy_mode = QMPPHY_MODE_DP_ONLY;
    assert(!qmp_combo_uke_reconfigure(&qmp));
    assert(pipe_enabled && !qmp.usb_powered_on && qmp.usb_init_count == 1);
    assert(aux_init == 1 && usb_start == 3 && usb_stop == 1);
    assert(!qmp_combo_uke_reconfigure(&qmp));
    assert(aux_init == 2 && usb_start == 3 && usb_stop == 1);
    qmp.qmpphy_mode = QMPPHY_MODE_USB3DP;
    assert(!qmp_combo_uke_reconfigure(&qmp));
    assert(pipe_enabled && qmp.usb_powered_on && qmp.usb_init_count == 1);
    assert(aux_init == 3 && usb_start == 4 && usb_stop == 1);
    assert(!qmp_combo_usb_exit(&phy));
    assert(pipe_enabled && !qmp.usb_powered_on && !qmp.usb_init_count);
    assert(!qmp_combo_com_exit(&qmp, false));
    assert(!pipe_enabled && common_start == common_stop && !qmp.phy_mutex);
    puts("Native QMP USB/DP route transitions and shared clock ownership passed.");
}
