#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C
[[ $# == 2 ]]
assets=$(cd -- "$(dirname -- "$0")" && pwd)
tree=$(realpath -e -- "$2")
patch=$assets/dpu-rm-optional-dspp.patch
proof=$assets/uke-kernel-migration-check-7.3.5-41.dpu_optional_dspp26.fc46.aarch64.rpm
key=2204a661ea630a5303500085538797e72a3e4eca
cd "$tree"
case $1 in
    prepare)
        (cd "$assets"; sha256sum -c --strict --quiet SHA256SUMS)
        sha256sum -c --strict --quiet "$assets/before.sha256"
        [[ $(gpg --batch --with-colons --show-keys "$assets/parent-key.gpg" | awk -F: '$1=="fpr"{print tolower($10);exit}') == "$key" ]]
        trust=$(mktemp -d --tmpdir="$tree" .dpu-optional-dspp.XXXXXXXX)
        trap 'rm -rf -- "$trust"' EXIT
        rpmkeys --dbpath "$trust" --import "$assets/parent-key.gpg"
        rpmkeys --dbpath "$trust" --checksig -v "$proof" > "$trust/signatures"
        [[ $(grep -Fc "key fingerprint: $key: OK" "$trust/signatures") == 2 ]]
        ! grep -Eq 'NOKEY|NOT OK|BAD' "$trust/signatures"
        rpm2cpio "$proof" | cpio -i --quiet --to-stdout \
            './usr/share/uke-kernel-migration-check/dpu-optional-dspp73526/qualification.txt' > "$trust/receipt"
        hash=$(sha256sum "$patch")
        grep -Fxq "${hash%% *}  ${patch##*/}" "$trust/receipt"
        [[ $(grep -Fxc '32768 atomic trials, 23344 rejects, state=6bee27b2fa6298ad' "$trust/receipt") == 8 ]]
        [[ $(grep -Fxc 'Expected catalog messages at error level: 0' "$trust/receipt") == 4 ]]
        grep -Fxq 'Native AArch64 DPU resource manager object checked; exact source inverse verified.' "$trust/receipt"
        git apply --check --whitespace=error "$patch"
        git apply --whitespace=error "$patch"
        sha256sum -c --strict "$assets/after.sha256"
        ;;
    restore)
        sha256sum -c --strict "$assets/after.sha256"
        git apply --reverse --check --whitespace=error "$patch"
        git apply --reverse --whitespace=error "$patch"
        sha256sum -c --strict "$assets/before.sha256"
        ;;
    *) exit 2 ;;
esac
