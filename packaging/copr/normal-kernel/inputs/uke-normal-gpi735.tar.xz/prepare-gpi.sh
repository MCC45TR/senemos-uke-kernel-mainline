#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C

[[ $# == 2 || $# == 3 ]]
phase=$1
tree=$(realpath -e -- "$2")
assets=$(cd -- "$(dirname -- "$0")" && pwd)
geni="$assets/geni"
gpi="$assets/gpi"
geni_patch="$geni/0025-i2c-qcom-geni-release-partial-gpi-batches.patch"
gpi_patch="$gpi/0026-dma-qcom-gpi-set-rx-length-only-for-i2c-reads.patch"

check_qualification() {
    local directory=$1 package=$2 test_name=$3 expected=$4
    shift 4
    local proof member hash
    proof=$(rpm2cpio "$directory/$package" | cpio -i --quiet --to-stdout \
        "./usr/share/uke-kernel-migration-check/$test_name/qualification.txt")
    grep -Fxq 'Signed normal 7.4.10 Linux baseline, COPR 11366170.' <<< "$proof"
    grep -Fxq "$expected" <<< "$proof"
    for member in "$@"; do
        read -r hash _ < <(sha256sum -- "$member")
        grep -Fxq "$hash  ./${member##*/}" <<< "$proof"
    done
}

case $phase in
    prepare)
        [[ $# == 2 ]]
        (cd "$assets"; sha256sum -c --strict --quiet SHA256SUMS)
        check_qualification "$geni" uke-kernel-migration-check-7.3.5-22.geni_batch.fc46.aarch64.rpm geni-batch735 \
            'ARM64 GENI I2C object compiled and batch patch reverses to the exact 7.4.10 source.' \
            "$geni_patch" "$geni/before.sha256" "$geni/after.sha256"
        check_qualification "$gpi" uke-kernel-migration-check-7.3.5-23.gpi_shape.fc46.aarch64.rpm gpi-go-shape735 \
            'ARM64 QCOM GPI object compiled and the write GO patch reverses to the exact 7.4.10 source.' \
            "$gpi_patch" "$gpi/before.sha256" "$gpi/after.sha256"

        cd -- "$tree"
        sha256sum -c --strict --quiet "$geni/before.sha256" "$gpi/before.sha256"
        git apply --check --whitespace=error "$geni_patch" "$gpi_patch"
        git apply --whitespace=error "$geni_patch" "$gpi_patch"
        sha256sum -c --strict --quiet "$geni/after.sha256" "$gpi/after.sha256"
        ;;
    linked)
        [[ $# == 3 ]]
        geni_module="$tree/drivers/i2c/busses/i2c-qcom-geni.ko"
        gpi_module="$tree/drivers/dma/qcom/gpi.ko"
        for module in "$geni_module" "$gpi_module"; do
            readelf -h "$module" | grep -F AArch64
            [[ $(modinfo -F vermagic "$module") == "$3 "* ]]
        done
        readelf -Ws "$geni_module" | awk '$7 != "UND" && $8 == "geni_i2c_xfer" { found = 1 } END { exit !found }'
        readelf -Ws "$gpi_module" | awk '$7 != "UND" && $8 == "gpi_prep_slave_sg" { found = 1 } END { exit !found }'
        grep -Fx 'CONFIG_I2C_QCOM_GENI=m' "$tree/.config"
        grep -Fx 'CONFIG_QCOM_GPI_DMA=m' "$tree/.config"
        sha256sum "$geni_module" "$gpi_module"
        ;;
    restore)
        [[ $# == 2 ]]
        cd -- "$tree"
        sha256sum -c --strict --quiet "$geni/after.sha256" "$gpi/after.sha256"
        git apply --reverse --check --whitespace=error "$geni_patch" "$gpi_patch"
        git apply --reverse --whitespace=error "$geni_patch" "$gpi_patch"
        sha256sum -c --strict --quiet "$geni/before.sha256" "$gpi/before.sha256"
        ;;
    *) exit 2 ;;
esac
