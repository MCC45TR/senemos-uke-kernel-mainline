#!/usr/bin/bash
# Exercise the shipped UCSI edge decoder and RGB frame generator.
set -Eeuo pipefail
kernel=$(realpath -- "${1:?prepared kernel tree}")
work=$(mktemp -d)
trap 'find "$work" -depth -delete' EXIT
cat > "$work/check.c" <<'C'
#include <assert.h>
#include <stdbool.h>
#include <stddef.h>
#include <string.h>
#include "uke-rgb-policy.h"

struct device { const char *of_node; };
struct ucsi { struct device *dev; };
struct ucsi_connector {
	unsigned int num;
	struct ucsi *ucsi;
	bool uke_attach_known, uke_attached;
	bool CONNECTED, PWR_DIR;
};
#define TYPEC_SINK false
#define UCSI_CONSTAT(con, name) ((con)->name)
static bool matched_machine = true;
static unsigned int notices;
static int uke_sink_attach;
static bool of_machine_is_compatible(const char *name)
{
	assert(!strcmp(name, "xiaomi,uke"));
	return matched_machine;
}
static bool of_device_is_compatible(const char *node, const char *name)
{
	return node && !strcmp(node, name);
}
static void blocking_notifier_call_chain(int *head, unsigned long action, void *data)
{
	assert(head == &uke_sink_attach && !action && !data);
	notices++;
}
C
sed -n '/^static void ucsi_uke_sink_attach(/,/^}/p' "$kernel/drivers/usb/typec/ucsi/ucsi.c" >> "$work/check.c"
cat >> "$work/check.c" <<'C'

static void expect_frame(unsigned int elapsed, bool blue, unsigned int delay)
{
	struct uke_rgb_frame f = uke_rgb_usb_attach_frame(elapsed);

	assert(f.rgb == (blue ? 0x0000ff : 0));
	assert(f.brightness == (blue ? UKE_RGB_LIMIT : 0));
	assert(f.delay_ms == delay);
}

int main(void)
{
	struct device dev = { "xiaomi,uke-typec-pmic-glink" };
	struct ucsi ucsi = { &dev };
	struct ucsi_connector con = { .num = 1, .ucsi = &ucsi, .CONNECTED = true };

	ucsi_uke_sink_attach(&con, 2);
	assert(!con.uke_attach_known);
	ucsi_uke_sink_attach(&con, 3);
	assert(con.uke_attach_known && con.uke_attached && !notices);
	con.CONNECTED = false;
	ucsi_uke_sink_attach(&con, -5);
	assert(con.uke_attached && !notices);
	ucsi_uke_sink_attach(&con, 3);
	assert(!con.uke_attached && !notices);
	con.CONNECTED = true;
	ucsi_uke_sink_attach(&con, 3);
	assert(con.uke_attached && notices == 1);
	for (int i = 0; i < 64; i++) {
		con.PWR_DIR = i % 2;
		ucsi_uke_sink_attach(&con, 3);
	}
	assert(notices == 1);
	con.CONNECTED = false;
	ucsi_uke_sink_attach(&con, 3);
	con.CONNECTED = true;
	ucsi_uke_sink_attach(&con, 3);
	con.PWR_DIR = false;
	ucsi_uke_sink_attach(&con, 3);
	assert(notices == 1);
	con.CONNECTED = false;
	ucsi_uke_sink_attach(&con, 3);
	con.CONNECTED = true;
	matched_machine = false;
	ucsi_uke_sink_attach(&con, 3);
	matched_machine = true;
	con.num = 2;
	ucsi_uke_sink_attach(&con, 3);
	con.num = 1;
	dev.of_node = NULL;
	ucsi_uke_sink_attach(&con, 3);
	assert(notices == 1 && !con.uke_attached);
	dev.of_node = "xiaomi,uke-typec-pmic-glink";
	ucsi_uke_sink_attach(&con, 3);
	assert(notices == 2);

	expect_frame(0, true, 700);
	expect_frame(699, true, 1);
	expect_frame(700, false, 500);
	expect_frame(1199, false, 1);
	expect_frame(1200, true, 700);
	expect_frame(1899, true, 1);
	expect_frame(1900, false, 500);
	expect_frame(2399, false, 1);
	expect_frame(2400, false, 0);
	expect_frame(3000, false, 0);
	return 0;
}
C
"${CC:-cc}" -std=gnu11 -Wall -Wextra -Werror -I "$kernel/drivers/leds" "$work/check.c" -o "$work/check"
"$work/check"
printf '%s\n' 'UCSI physical sink attach and RGB 700/500/700 ms timing passed.'
