#!/usr/bin/bash
set -Eeuo pipefail
umask 077
ulimit -c 0
driver=$(realpath -- "$1")
fixture=$(realpath -- "$2")
tmp=$(mktemp -d)
trap 'find "$tmp" -depth -delete' EXIT
sed -n '/^#define SSC_ACCEL_BATCH_NS /p;
        /^struct ssc_accel_batch {$/,/^};$/p' "$driver" > "$tmp/actual-batch.inc"
sed -n '/^static bool ssc_current(/,/^}/p;
        /^static int ssc_stream_get(/,/^}/p;
        /^static int ssc_stream_put(/,/^}/p;
        /^static bool ssc_accel_batch_available(/,/^}/p;
        /^static bool ssc_accel_batch_take(/,/^}/p;
        /^static int ssc_read_sample(/,/^}/p;
        /^static int ssc_read_raw(/,/^}/p' "$driver" > "$tmp/actual-callbacks.inc"
for compiler in ${UKE_TEST_COMPILERS:-gcc clang}; do
  "$compiler" -std=gnu11 -O1 -Wall -Wextra -Werror -fsanitize=undefined \
      -fno-sanitize-recover=all -I "$tmp" "$fixture" -o "$tmp/test"
  "$tmp/test"
done
