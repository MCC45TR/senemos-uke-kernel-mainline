#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>

typedef uint64_t u64;
typedef int64_t s64;
#define NSEC_PER_MSEC 1000000ULL
#define SSC_SAMPLE_MAX 6
#define SSC_TIMEOUT 5000
#define SSC_STREAM_DIRECT 1
#define SSC_STREAM_BUFFER 2
#define IIO_CHAN_INFO_SCALE 1
#define IIO_CHAN_INFO_RAW 2
#define IIO_VAL_INT_64 3

#include "actual-batch.inc"

struct task {
 pid_t pid;
 u64 start_boottime;
};
static struct task reader = { 22, 333 };
#define current (&reader)
static pid_t task_pid_nr(const struct task *task) { return task->pid; }
static u64 now;
static u64 ktime_get_boottime_ns(void) { return now; }

struct ssc_controller {
 struct ssc_accel_batch accel_batch;
 unsigned int endpoint_count;
 u64 generation, client_generation;
 bool removed, paused, lookup_fault, client_open;
 bool control, state;
};
enum { SSC_ACCEL, SSC_QUATERNION, SSC_LIGHT };
struct ssc_description { int kind; };
struct ssc_sensor {
 struct ssc_controller *controller;
 const struct ssc_description *description;
 bool ready, stream_active, need_stop;
 int error;
 unsigned int stream_users;
 u64 revision, sample_sequence, ticks;
 int sample_done;
 s64 sample[SSC_SAMPLE_MAX];
};
struct iio_dev { struct ssc_sensor *sensor; bool direct, busy; };
struct iio_chan_spec { unsigned int address; };
static struct ssc_controller controller;
static struct ssc_sensor sensor;
static struct iio_dev io;
static const struct ssc_description accel = { SSC_ACCEL };
static const struct ssc_description light = { SSC_LIGHT };
static unsigned int starts, stops;
static bool failed_start, failed_stop, timed_out, change_revision;
static void *iio_priv(struct iio_dev *dev) { return &dev->sensor; }
static bool iio_device_claim_direct(struct iio_dev *dev)
{
 if (dev->busy) return false;
 assert(!dev->direct);
 return (dev->direct = true);
}
static void iio_device_release_direct(struct iio_dev *dev)
{
 assert(dev->direct);
 dev->direct = false;
}
static void mutex_lock(bool *locked) { assert(!*locked); *locked = true; }
static void mutex_unlock(bool *locked) { assert(*locked); *locked = false; }
#define spin_lock_irqsave(lock, flags) do { (flags) = 0; mutex_lock(lock); } while (0)
#define spin_unlock_irqrestore(lock, flags) do { assert(!(flags)); mutex_unlock(lock); } while (0)
#define lockdep_assert_held(lock) assert(*(lock))
static bool ssc_stream_user_valid(unsigned int user) { return user == SSC_STREAM_DIRECT || user == SSC_STREAM_BUFFER; }
static int ssc_start(struct ssc_sensor *s)
{
 starts++;
 if (failed_start) return -EIO;
 s->ticks = 0;
 s->stream_active = true;
 return 0;
}
static int ssc_stop(struct ssc_sensor *s)
{
 stops++;
 s->stream_active = false;
 s->ticks = 0;
 if (change_revision) s->revision++;
 return failed_stop ? -EIO : 0;
}
static unsigned long wait_for_completion_timeout(int *completion, unsigned long limit)
{
 assert(completion == &sensor.sample_done && limit == SSC_TIMEOUT);
 if (timed_out) return 0;
 now += 160 * NSEC_PER_MSEC;
 sensor.sample_sequence++;
 sensor.ticks++;
 sensor.sample[0] = 10 * starts;
 sensor.sample[1] = 10 * starts + 1;
 sensor.sample[2] = 10 * starts + 2;
 return 1;
}
static int ssc_read_scale(const struct ssc_description *d, int *v, int *v2)
{
 (void)d;
 *v = 0;
 *v2 = 1;
 return IIO_VAL_INT_64;
}
static unsigned int ssc_sample_channels(const struct ssc_description *d)
{
 return d->kind == SSC_ACCEL ? 3 : 1;
}
static void iio_val_s64_decompose(s64 value, int *v, int *v2)
{
 *v = (int)value;
 *v2 = (int)((u64)value >> 32);
}

#include "actual-callbacks.inc"

static void reset(void)
{
 controller = (struct ssc_controller) {
  .endpoint_count = 1, .generation = 9, .client_generation = 9, .client_open = true,
 };
 sensor = (struct ssc_sensor) {
  .controller = &controller, .description = &accel, .ready = true, .revision = 5,
 };
 io = (struct iio_dev) { .sensor = &sensor };
 reader = (struct task) { 22, 333 };
 now = 1000 * NSEC_PER_MSEC;
 starts = stops = 0;
 failed_start = failed_stop = timed_out = change_revision = false;
}
static int axis(unsigned int n)
{
 int val = 0, val2 = 0;
 int result = ssc_read_raw(&io, &(struct iio_chan_spec) { .address = n },
                      &val, &val2, IIO_CHAN_INFO_RAW);
 assert(!io.direct && !controller.control && !controller.state);
 return result == IIO_VAL_INT_64 ? val : result;
}
int main(void)
{
 reset();
 assert(axis(0) == 10);
 now += 90000;
 assert(axis(1) == 11);
 now += SSC_ACCEL_BATCH_NS - 90000;
 assert(axis(2) == 12 && starts == 1 && stops == 1);
 assert(axis(2) == 22 && starts == 2 && stops == 2);

 reset(); assert(axis(0) == 10);
 now += SSC_ACCEL_BATCH_NS + 1;
 assert(axis(1) == 21 && starts == 2);
 reset(); assert(axis(0) == 10);
 reader.pid++;
 assert(axis(1) == 21 && starts == 2);
 reset(); assert(axis(0) == 10);
 reader.start_boottime++;
 assert(axis(1) == 21 && starts == 2);
 reset(); assert(axis(0) == 10);
 sensor.revision++;
 assert(axis(1) == 21 && starts == 2);
 reset(); assert(axis(0) == 10);
 sensor.sample_sequence++;
 assert(axis(1) == 21 && starts == 2);
 reset(); assert(axis(0) == 10);
 controller.client_generation = ++controller.generation;
 assert(axis(1) == 21 && starts == 2);
 reset(); assert(axis(0) == 10);
 controller.paused = true;
 assert(axis(1) == -ENODEV && starts == 1);
 reset(); assert(axis(0) == 10);
 now = controller.accel_batch.stopped_ns - 1;
 assert(axis(1) == 21 && starts == 2);

 reset(); assert(axis(0) == 10);
 io.busy = true;
 assert(axis(1) == -EBUSY && starts == 1);
 io.busy = false;
 mutex_lock(&controller.control);
 assert(ssc_stream_get(&sensor, SSC_STREAM_BUFFER) == 0);
 assert(ssc_stream_put(&sensor, SSC_STREAM_BUFFER) == 0);
 mutex_unlock(&controller.control);
 assert(axis(1) == 31 && starts == 3);

 reset();
 assert(axis(2) == 12 && axis(1) == 21);
 assert(axis(0) == 30 && axis(0) == 40 && axis(1) == 41 && axis(2) == 42);
 assert(starts == 4 && stops == 4);

 reset(); timed_out = true;
 assert(axis(0) == -ETIMEDOUT && !controller.accel_batch.next_axis);
 reset(); failed_start = true;
 assert(axis(0) == -EIO && !controller.accel_batch.next_axis);
 reset(); failed_stop = true;
 assert(axis(0) == -EIO && !controller.accel_batch.next_axis);
 reset(); change_revision = true;
 assert(axis(0) == 10 && !controller.accel_batch.next_axis);
 reset(); sensor.description = &light;
 assert(axis(0) == 10 && axis(0) == 20 && starts == 2);
 assert(!controller.accel_batch.next_axis);
 puts("Actual SSC callbacks use one XYZ request pair and refuse stale, unrelated or failed samples.");
}
