#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C

[[ $# == 2 || $# == 3 ]]
phase=$1
tree=$(realpath -e -- "$2")
assets=$(cd -- "$(dirname -- "$0")" && pwd)
rgb="$assets/0001-uke-rgb-notify-usb-sink-attach.patch"
ssc="$assets/ssc-batch-linked.patch"
ssc_source=drivers/iio/common/uke-ssc/uke-ssc-iio.c
attach_header=include/linux/usb/uke-ucsi-attach.h

receipt() {
    rpm2cpio "$assets/$1" | cpio -i --quiet --to-stdout "$2"
}

verify_asset() {
    local path=$1 recorded=$2 proof=$3 digest
    read -r digest _ < <(sha256sum "$path")
    grep -Fxq "$digest  $recorded" <<< "$proof"
}

check_receipts() {
    local rgb_proof ssc_proof
    rgb_proof=$(receipt uke-rgb-usb-attach-check-0.1-2.fc46.aarch64.rpm ./usr/share/uke-source-checks/rgb-usb-attach.txt)
    ssc_proof=$(receipt uke-kernel-migration-check-7.3.5-17.fc46.aarch64.rpm ./usr/share/uke-kernel-migration-check/ssc-accel-kbuild735/qualification.txt)
    grep -Fxq 'Parent: published signed 7.3.5-13 SRPM, COPR 11360422' <<< "$rgb_proof"
    test "$(grep -Fxc 'UCSI physical sink attach and RGB 700/500/700 ms timing passed.' <<< "$rgb_proof")" = 2
    grep -Fxq 'Actual A13 ARM64 UCSI and RGB objects compile, link symbols agree, and the source patch reverses cleanly.' <<< "$rgb_proof"
    verify_asset "$rgb" "${rgb##*/}" "$rgb_proof"
    verify_asset "$assets/rgb-before.sha256" pre.sha256 "$rgb_proof"
    verify_asset "$assets/rgb-after.sha256" post.sha256 "$rgb_proof"
    verify_asset "$assets/rgb-usb-attach.sh" rgb-usb-attach.sh "$rgb_proof"
    grep -Fxq 'Parent: signed normal 7.4.7 source, COPR 11365568' <<< "$ssc_proof"
    grep -Fxq 'Real ARM64 Uke SSC composite compiled and the signed 7.4.7 source was restored.' <<< "$ssc_proof"
    grep -Fxq 'Actual SSC callbacks use one XYZ request pair and refuse stale, unrelated or failed samples.' <<< "$ssc_proof"
    verify_asset "$ssc" "${ssc##*/}" "$ssc_proof"
    verify_asset "$assets/ssc-before.sha256" before.sha256 "$ssc_proof"
    verify_asset "$assets/ssc-after.sha256" linked-after.sha256 "$ssc_proof"
    verify_asset "$assets/check-accel-batch.sh" check-accel-batch.sh "$ssc_proof"
    verify_asset "$assets/accel-batch-fixture.c" accel-batch-fixture.c "$ssc_proof"
}

case $phase in
    prepare)
        [[ $# == 2 ]]
        (cd -- "$assets"; sha256sum --strict -c --quiet SHA256SUMS)
        check_receipts
        cd -- "$tree"
        [[ ! -e $attach_header ]]
        sha256sum --strict -c --quiet "$assets/rgb-before.sha256" "$assets/ssc-before.sha256"
        git apply --check --whitespace=error "$rgb" "$ssc"
        git apply --whitespace=error "$rgb" "$ssc"
        sha256sum --strict -c --quiet "$assets/rgb-after.sha256" "$assets/ssc-after.sha256"
        bash "$assets/rgb-usb-attach.sh" "$tree"
        UKE_TEST_COMPILERS=gcc bash "$assets/check-accel-batch.sh" "$tree/$ssc_source" "$assets/accel-batch-fixture.c"
        ;;
    linked)
        [[ $# == 3 && $3 =~ ^[0-9]+\.[0-9]+\.[0-9]+-[0-9]+$ ]]
        cd -- "$tree"
        ucsi=drivers/usb/typec/ucsi/typec_ucsi.ko
        led=drivers/leds/leds-uke-rgb.ko
        ssc_module=drivers/iio/common/uke-ssc/uke-ssc.ko
        for option in TYPEC_UCSI LEDS_UKE_RGB IIO_UKE_SSC; do
            grep -Fxq "CONFIG_${option}=m" .config
        done
        for module in "$ucsi" "$led" "$ssc_module"; do
            readelf -h "$module" | grep -F AArch64
            [[ $(modinfo -F vermagic "$module") == "$3 "* ]]
        done
        for callback in uke_ucsi_register_sink_attach uke_ucsi_unregister_sink_attach; do
            readelf -Ws "$ucsi" | awk -v name="$callback" '
                $4=="FUNC" && $5=="GLOBAL" && $7!="UND" && $8==name { count++ }
                END { exit count!=1 }
            '
            readelf -Ws "$led" | awk -v name="$callback" '
                $7=="UND" && $8==name { count++ }
                END { exit count!=1 }
            '
        done
        modinfo -F depends "$led" | tr ',' '\n' | grep -Fx typec_ucsi
        readelf -Ws "$ssc_module" | awk '
            $4=="FUNC" && $7!="UND" && $8=="ssc_read_raw_multi" { count++ }
            END { exit count!=1 }
        '
        sha256sum "$ucsi" "$led" "$ssc_module"
        ;;
    restore)
        [[ $# == 2 ]]
        cd -- "$tree"
        sha256sum --strict -c --quiet "$assets/rgb-after.sha256" "$assets/ssc-after.sha256"
        git apply --reverse --check --whitespace=error "$ssc" "$rgb"
        git apply --reverse --whitespace=error "$ssc" "$rgb"
        sha256sum --strict -c --quiet "$assets/rgb-before.sha256" "$assets/ssc-before.sha256"
        [[ ! -e $attach_header ]]
        ;;
    *) exit 2 ;;
esac
