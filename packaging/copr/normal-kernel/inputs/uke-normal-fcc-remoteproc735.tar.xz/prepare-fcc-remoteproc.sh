#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C

[[ $# == 2 || $# == 3 ]]
phase=$1
tree=$(realpath -e -- "$2")
assets=$(cd -- "$(dirname -- "$0")" && pwd)
fcc="$assets/0028-power-supply-qcom-battmgr-observe-fitted-fcc.patch"
wakeup="$assets/rproc-release-duplicate-crash-wakeup.patch"

receipt() {
    local package=$1 entrypoint=$2
    rpm2cpio "$assets/$package" |
        cpio -i --quiet --to-stdout "./usr/share/uke-kernel-migration-check/$entrypoint/qualification.txt"
}

verify_asset() {
    local path=$1 recorded=$2 proof=$3 digest
    read -r digest _ < <(sha256sum "$path")
    grep -Fxq "$digest  $recorded" <<< "$proof"
}

check_patches() {
    local fcc_proof wakeup_proof seal
    fcc_proof=$(receipt uke-kernel-migration-check-7.3.5-25.fcc_observe.fc46.aarch64.rpm fcc-observation735)
    wakeup_proof=$(receipt uke-kernel-migration-check-7.3.5-26.rproc_wakeup.fc46.aarch64.rpm rproc-wakeup735)
    grep -Fxq 'Signed normal Uke 7.3.5-20 source, COPR 11366541.' <<< "$fcc_proof"
    test "$(grep -Fxc 'Fitted FCC observation: exclusive GET framing, raw sentinels, prior control state and error handling passed.' <<< "$fcc_proof")" = 2
    grep -Fxq 'ARM64 QCOM battery driver object compiled and the patch reverses to the exact signed preimage.' <<< "$fcc_proof"
    verify_asset "$fcc" "./${fcc##*/}" "$fcc_proof"
    grep -Fxq 'Signed Uke 7.3.5-21 source, COPR 11366897. Relevant remoteproc source and header replay.' <<< "$wakeup_proof"
    test "$(grep -Fc 'Actual remoteproc crash worker: candidate: 32 ' <<< "$wakeup_proof")" = 2
    grep -Fxq 'ARM64 remoteproc driver built; crash event and wakeup cleanup symbols preserved, source reverses exactly.' <<< "$wakeup_proof"
    for seal in "$wakeup" "$assets/wakeup-before.sha256" "$assets/wakeup-after.sha256"; do
        verify_asset "$seal" "${seal##*/}" "$wakeup_proof"
    done
}

case $phase in
    prepare)
        [[ $# == 2 ]]
        (cd "$assets"; sha256sum -c --strict --quiet SHA256SUMS)
        check_patches
        cd -- "$tree"
        sha256sum -c --strict --quiet "$assets/batt-before.sha256" "$assets/wakeup-before.sha256"
        for patch in "$fcc" "$wakeup"; do
            git apply --check --whitespace=error "$patch"
            git apply --whitespace=error "$patch"
        done
        sha256sum -c --strict --quiet "$assets/batt-after.sha256" "$assets/wakeup-after.sha256"
        ;;
    linked)
        [[ $# == 3 && $3 =~ ^[0-9]+\.[0-9]+\.[0-9]+-[0-9]+$ ]]
        module="$tree/drivers/power/supply/qcom_battmgr.ko"
        core="$tree/drivers/remoteproc/remoteproc_core.o"
        readelf -h "$module" | grep -F AArch64
        readelf -h "$core" | grep -F AArch64
        [[ $(modinfo -F vermagic "$module") == "$3 "* ]]
        readelf -Ws "$module" | awk '
            $7!="UND" && $8=="qcom_battmgr_uke_battery_status_worker" { burst=1 }
            $7!="UND" && $8=="dev_attr_uke_oem_batt_fcc_raw" { fcc=1 }
            END { exit !(burst && fcc) }
        '
        grep -aqF 'uke_oem_batt_fcc_raw' "$module"
        readelf -Ws "$core" | awk '
            $7=="UND" && $8=="pm_relax" { relax=1 }
            $7=="UND" && $8=="sysfs_notify" { notify=1 }
            $7=="UND" && $8=="kobject_uevent_env" { event=1 }
            END { exit !(relax && notify && event) }
        '
        grep -Fxq 'CONFIG_REMOTEPROC=y' "$tree/.config"
        grep -Fxq 'CONFIG_PM_SLEEP=y' "$tree/.config"
        grep -aqF 'RPROC_EVENT=crash' "$tree/arch/arm64/boot/Image"
        sha256sum "$module" "$core"
        ;;
    restore)
        [[ $# == 2 ]]
        cd -- "$tree"
        sha256sum -c --strict --quiet "$assets/batt-after.sha256" "$assets/wakeup-after.sha256"
        for patch in "$wakeup" "$fcc"; do
            git apply --reverse --check --whitespace=error "$patch"
            git apply --reverse --whitespace=error "$patch"
        done
        sha256sum -c --strict --quiet "$assets/batt-before.sha256" "$assets/wakeup-before.sha256"
        [[ ! -e Documentation/ABI/testing/sysfs-driver-qcom-battmgr-uke-fcc ]]
        ;;
    *) exit 2 ;;
esac
