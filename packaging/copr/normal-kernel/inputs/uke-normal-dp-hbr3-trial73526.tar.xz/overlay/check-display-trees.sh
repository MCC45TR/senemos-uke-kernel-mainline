#!/usr/bin/bash
# Qualify both O82 overlays and isolate the experimental DT changes.
set -Eeuo pipefail
kernel=$1
profile=$2
output=$3
source=$profile/src/display/sm7675-uke-native-display-oem-modes.dtso
generator=$profile/src/display/generate-native-panels.sh
mkdir -p "$output"/{before,default,trial}
export UKE_NATIVE_VIDEO_SOURCE="$profile/src/video/sm7675-uke-native-video.dtso"
flags=(-DUKE_USB_TYPEC=1 -DUKE_AUDIO_SERVICES=1 -DUKE_AUDIO_SPEAKERS=1 -DUKE_AUDIO_MICROPHONES=1)
bash "$generator" "$kernel" "$output/before" "$source" auto "${flags[@]}"
(cd "$profile/.." && git apply --check "$4" && git apply "$4")
bash "$generator" "$kernel" "$output/default" "$source" auto "${flags[@]}"
bash "$generator" "$kernel" "$output/trial" "$source" auto "${flags[@]}" -DUKE_DP_HBR3_TRIAL=1
dp=/fragment@208/__overlay__/display-subsystem@ae00000/displayport-controller@af54000
endpoint=$dp/ports/port@1/endpoint
opp=$dp/opp-table/opp-810000000
for variant in 36 42; do
    stock=$output/default/display-$variant.dtbo
    trial=$output/trial/display-$variant.dtbo
    cmp "$output/before/display-$variant.dtbo" "$stock"
    if fdtget -t x "$stock" "$endpoint" link-frequencies >/dev/null 2>&1; then exit 1; fi
    if fdtget -t x "$stock" "$opp" opp-hz >/dev/null 2>&1; then exit 1; fi
    [[ $(fdtget -t x "$trial" "$endpoint" link-frequencies) == \
        '0 608f3d00 0 a0eebb00 1 41dd7600 1 e2cc3100' ]]
    [[ $(fdtget -t u "$trial" "$opp" opp-hz) == '0 810000000' ]]
    dtc -q -I dtb -O dts -s "$stock" > "$output/default-$variant.dts"
    dtc -q -I dtb -O dts -s "$trial" |
        sed -e "/^[[:space:]]*link-frequencies = /d" \
            -e "/^[[:space:]]*opp-810000000 {/,/^[[:space:]]*};/d" \
            > "$output/trial-restored-$variant.dts"
    diff -B -u "$output/default-$variant.dts" "$output/trial-restored-$variant.dts"
    printf 'O82 %s default DT byte identical; HBR3 adds exactly the endpoint rates and link OPP.\n' "$variant"
done
(cd "$profile/.." && git apply --reverse --check "$4" && git apply --reverse "$4")
