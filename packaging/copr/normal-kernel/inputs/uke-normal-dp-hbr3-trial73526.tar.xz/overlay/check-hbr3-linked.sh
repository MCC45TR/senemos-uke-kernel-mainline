#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C
[[ $# == 3 && $3 =~ ^[0-9]+\.[0-9]+\.[0-9]+-[0-9]+$ ]]
out=$(realpath -e "$1")
tree=$(realpath -e "$2")
assets=$(cd -- "$(dirname -- "$0")" && pwd)
abi=$3
cd "$out"
for module in drivers/gpu/drm/msm/msm.ko \
              drivers/phy/qualcomm/phy-qcom-qmp-combo.ko \
              drivers/clk/qcom/dispcc-sm8550.ko; do
    readelf -h "$module" | grep -F AArch64
    [[ $(modinfo -F vermagic "$module") == "$abi "* ]]
    sha256sum "$module"
done
bash "$assets/check-embedded-hbr3.sh" "$tree/native-generated" "$tree"
