#!/usr/bin/bash
set -Eeuo pipefail
header=$1
output=$2
cat > "$output.c" <<'C'
#include <assert.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

typedef uint64_t u64;
struct device_node {
    bool available;
    int refs;
    const u64 *rates;
    int count;
    struct device_node *related;
};

static const u64 hbr3[] = {1620000000, 2700000000, 5400000000, 8100000000};
static const u64 hbr2[] = {1620000000, 2700000000, 5400000000};
static const u64 wrong[] = {1620000000, 5400000000, 8100000001};
static const u64 eight[] = {810000000};
static const u64 five[] = {540000000};
static bool uke, sm7675;
static struct device_node dp, endpoint, opps, opp;
static struct device_node *root_dp, *root_endpoint;
static unsigned cases;

static struct device_node *of_node_get(struct device_node *node)
{
    if (node)
        ++node->refs;
    return node;
}

static void of_node_put(struct device_node *node)
{
    if (node)
        assert(node->refs-- > 0);
}

static void of_node_release(struct device_node **node)
{
    of_node_put(*node);
}

static bool of_machine_is_compatible(const char *value)
{
    if (!strcmp(value, "xiaomi,uke"))
        return uke;
    assert(!strcmp(value, "qcom,sm7675"));
    return sm7675;
}

static struct device_node *of_find_compatible_node(struct device_node *from,
                                                    const char *type,
                                                    const char *name)
{
    assert(!from && !type && !strcmp(name, "qcom,sm7675-dp"));
    return of_node_get(root_dp);
}

static bool of_device_is_available(struct device_node *node)
{
    return node->available;
}

static struct device_node *of_graph_get_endpoint_by_regs(
    struct device_node *node, int port, int ep)
{
    assert(node == &dp && port == 1 && ep == 0);
    return of_node_get(root_endpoint);
}

static int of_property_count_u64_elems(struct device_node *node,
                                       const char *property)
{
    assert(node == &endpoint && !strcmp(property, "link-frequencies"));
    return node->count;
}

static int of_property_read_u64_index(struct device_node *node,
                                       const char *property, int index,
                                       u64 *rate)
{
    assert(node == &endpoint && !strcmp(property, "link-frequencies"));
    if (!node->rates || index < 0 || index >= node->count)
        return -1;
    *rate = node->rates[index];
    return 0;
}

static struct device_node *of_parse_phandle(struct device_node *node,
                                            const char *property, int index)
{
    assert(node == &dp && !strcmp(property, "operating-points-v2") && !index);
    return of_node_get(node->related);
}

#define for_each_available_child_of_node_scoped(parent, child)                 \
    for (struct device_node *child __attribute__((cleanup(of_node_release))) =  \
             (parent)->related && (parent)->related->available                \
                 ? of_node_get((parent)->related) : NULL;                      \
         child; of_node_put(child), child = NULL)

static int of_property_read_u64(struct device_node *node, const char *property,
                                u64 *rate)
{
    assert(node == &opp && !strcmp(property, "opp-hz"));
    if (!node->rates)
        return -1;
    *rate = node->rates[0];
    return 0;
}
C
sed -n '/^static inline bool uke_dp_hbr3_available(void)/,/^}/p' "$header" >> "$output.c"
cat >> "$output.c" <<'C'

static void reset(void)
{
    uke = sm7675 = true;
    dp = (struct device_node){.available = true, .related = &opps};
    endpoint = (struct device_node){.available = true, .rates = hbr3, .count = 4};
    opps = (struct device_node){.available = true, .related = &opp};
    opp = (struct device_node){.available = true, .rates = eight};
    root_dp = &dp;
    root_endpoint = &endpoint;
}

static void check(bool expected)
{
    assert(uke_dp_hbr3_available() == expected);
    assert(!dp.refs && !endpoint.refs && !opps.refs && !opp.refs);
    ++cases;
    reset();
}

int main(void)
{
    reset();
    check(true);
    uke = false; check(false);
    sm7675 = false; check(false);
    root_dp = NULL; check(false);
    dp.available = false; check(false);
    root_endpoint = NULL; check(false);
    endpoint.available = false; check(false);
    endpoint.count = -1; check(false);
    endpoint.rates = NULL; check(false);
    endpoint.rates = hbr2; endpoint.count = 3; check(false);
    endpoint.rates = wrong; endpoint.count = 3; check(false);
    dp.related = NULL; check(false);
    opps.available = false; check(false);
    opps.related = NULL; check(false);
    opp.available = false; check(false);
    opp.rates = NULL; check(false);
    opp.rates = five; check(false);
    printf("HBR3 DT admission and balanced node references verified in %u cases.\n",
           cases);
}
C
gcc -O2 -Wall -Wextra -Werror -std=gnu11 "$output.c" -o "$output"
"$output"
gcc -O1 -Wall -Wextra -Werror -std=gnu11 -fsanitize=address,undefined "$output.c" -o "$output-sanitized"
"$output-sanitized"
