#!/usr/bin/bash
# Replace the generated overlays only after matching the normal profile.
set -Eeuo pipefail
export LC_ALL=C
[[ $# == 1 ]]
assets=$(cd -- "$(dirname -- "$0")" && pwd)
tree=$(realpath -e -- "$1")
source="$tree/native-profile"
output="$tree/native-generated"
header="$tree/arch/arm64/kernel/uke-native-display.h"
[[ $(cat "$source/audio-profile") == microphones ]]
[[ $(cat "$source/usb-profile") == typec-v1 ]]
work=$(mktemp -d --tmpdir="$output" .hbr3-build.XXXXXXXX)
cp "$header" "$work/original.h"
cleanup() {
    local rc=$?
    if ((rc)); then install -m644 "$work/original.h" "$header"; fi
    rm -rf -- "$work"
}
trap cleanup EXIT
bash "$assets/check-display-trees.sh" "$tree" "$source" "$work" \
    "$assets/0110-uke-dp-trial-profile.patch"
cmp "$work/original.h" "$work/before/uke-native-display.h"
for file in display-36.dtbo display-42.dtbo display.dtbo; do
    cmp "$output/$file" "$work/before/$file"
done
bash "$assets/check-embedded-hbr3.sh" "$work/trial" "$tree"
for file in display-36.dts display-42.dts display.dts display-36.dtbo \
            display-42.dtbo display.dtbo uke-native-display.h; do
    install -m644 "$work/trial/$file" "$output/$file"
done
