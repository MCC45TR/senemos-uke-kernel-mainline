#!/usr/bin/bash
# SPDX-License-Identifier: GPL-2.0-only
set -Eeuo pipefail
export LC_ALL=C
[[ $# == 2 ]] || exit 2
assets=$(cd -- "$(dirname -- "$0")" && pwd)
target=$(realpath -e "$2")
proof=$assets/uke-kernel-migration-check-7.3.5-39.dp_hbr3_trial26.fc46.aarch64.rpm
patch=$assets/0110-uke-dp-guard-cliffs-hbr3.patch
profile=$assets/0110-uke-dp-trial-profile.patch
key=2204a661ea630a5303500085538797e72a3e4eca

cd "$target"
case $1 in
    prepare)
        (cd "$assets"; sha256sum --strict --check --quiet SHA256SUMS)
        sha256sum --strict --check --quiet "$assets/before.sha256"
        [[ $(gpg --batch --with-colons --show-keys "$assets/parent-key.gpg" | awk -F: '$1=="fpr"{print tolower($10);exit}') == "$key" ]]
        state=$(mktemp -d --tmpdir="$target" .hbr3-proof.XXXXXXXX)
        trap 'rm -rf -- "$state"' EXIT
        rpmkeys --dbpath "$state" --import "$assets/parent-key.gpg"
        rpmkeys --dbpath "$state" --checksig -v "$proof" > "$state/signatures"
        [[ $(grep -Fc "key fingerprint: $key: OK" "$state/signatures") == 2 ]]
        ! grep -Eq 'NOKEY|BAD|NOT OK' "$state/signatures"
        rpm2cpio "$proof" | cpio -i --quiet --to-stdout \
            './usr/share/uke-kernel-migration-check/dp-hbr3-trial73526/qualification.txt' > "$state/receipt"
        grep -Fxq 'Exact signed normal 7.3.5-26 source, COPR 11368308.' "$state/receipt"
        grep -Fxq 'Three native ARM64 display objects checked; source reverses to signed preimage.' "$state/receipt"
        for file in "$patch" "$profile"; do
            digest=$(sha256sum "$file")
            grep -Fxq "${digest%% *}  ${file##*/}" "$state/receipt"
        done
        git apply --check --whitespace=error "$patch" "$profile"
        git apply --whitespace=error "$patch" "$profile"
        sha256sum --strict --check --quiet "$assets/after.sha256"
        ;;
    restore)
        sha256sum --strict --check --quiet "$assets/after.sha256"
        git apply --reverse --check --whitespace=error "$patch" "$profile"
        git apply --reverse --whitespace=error "$patch" "$profile"
        sha256sum --strict --check --quiet "$assets/before.sha256"
        [[ ! -e include/linux/phy/uke-dp.h ]]
        ;;
    *) exit 2 ;;
esac
