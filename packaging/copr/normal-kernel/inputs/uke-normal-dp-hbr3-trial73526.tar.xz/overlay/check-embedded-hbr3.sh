#!/usr/bin/bash
# Ensure the existing ABL selector embeds both trial overlays.
set -Eeuo pipefail
export LC_ALL=C
[[ $# == 2 ]]
output=$(realpath -e -- "$1")
tree=$(realpath -e -- "$2")
header=$tree/arch/arm64/kernel/uke-native-display.h
dp=/fragment@208/__overlay__/display-subsystem@ae00000/displayport-controller@af54000
tmp=$(mktemp -d --tmpdir="$output" .hbr3-readback.XXXXXXXX)
trap 'rm -rf -- "$tmp"' EXIT
for variant in 36 42; do
    dtbo="$output/display-$variant.dtbo"
    [[ $(fdtget -t x "$dtbo" "$dp/ports/port@1/endpoint" link-frequencies) == \
        '0 608f3d00 0 a0eebb00 1 41dd7600 1 e2cc3100' ]]
    [[ $(fdtget -t u "$dtbo" "$dp/opp-table/opp-810000000" opp-hz) == '0 810000000' ]]
    awk -v prefix="static unsigned char uke_native_overlay_${variant}[]" '
        index($0,prefix)==1 {body=1; next}
        body && /^};/ {body=0; found++; next}
        body {gsub(/0x|,|[[:space:]]/,""); printf "%s", $0}
        END {if (found!=1 || body) exit 1}
    ' "$header" > "$tmp/$variant.hex"
    od -An -v -tx1 "$dtbo" | tr -d '[:space:]' | cmp - "$tmp/$variant.hex"
    printf 'Early ABL O82 %s overlay embeds 8.1 Gbit/s and 810 MHz.\n' "$variant"
done
cmp "$output/display-42.dtbo" "$output/display.dtbo"
