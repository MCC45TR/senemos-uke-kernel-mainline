#!/usr/bin/bash
set -Eeuo pipefail
ulimit -c 0
source=$1
fixture=$2
output=$3
compiler=$4
mkdir -p "$output"
sed -n '/^static int o82_get_modes(/,/^}/p' "$source" > "$output/preferred-modes.inc"
[[ $(grep -c '^}' "$output/preferred-modes.inc") == 1 ]]
for variant in plain sanitized; do
    options=()
    if [[ $variant == sanitized ]]; then
        options=(-fsanitize=address,undefined -fno-omit-frame-pointer)
    fi
    binary="$output/test-preferred-$compiler-$variant"
    "$compiler" -std=gnu11 -Wall -Wextra -Werror -Wno-sign-compare -I"$output" "${options[@]}" "$fixture" -o "$binary"
    ASAN_OPTIONS=detect_leaks=0 "$binary"
done
