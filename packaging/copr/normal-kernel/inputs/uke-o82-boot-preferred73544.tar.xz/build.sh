#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C
[[ $# == 2 && $(uname -m) == aarch64 ]]
inputs=$(realpath -e "$1")
result=$(realpath -m "$2")
mkdir replay
cd replay
parent=senemos-uke-linux-kernel-mainline-7.3.5-44.fc46.src.rpm
base=https://download.copr.fedorainfracloud.org/results/mcc45tr/uke-linux-unstable/fedora-rawhide-aarch64/11371977-senemos-uke-linux-kernel-mainline
key=2204a661ea630a5303500085538797e72a3e4eca
curl -qfsSL --proto '=https' --retry 2 --max-time 205 --max-filesize 190000000 "$base/$parent" -o "$parent"
sha256sum -c --strict "$inputs/parent.sha256"
[[ $(gpg --batch --with-colons --show-keys "$inputs/parent-key.gpg" | awk -F: '$1=="fpr"{print tolower($10);exit}') == "$key" ]]
mkdir trust out
rpmkeys --dbpath "$PWD/trust" --import "$inputs/parent-key.gpg"
rpmkeys --dbpath "$PWD/trust" --checksig -v "$parent" > parent-signatures.txt
[[ $(grep -Fc "key fingerprint: $key: OK" parent-signatures.txt) == 2 ]]
! grep -Eq 'NOKEY|BAD|NOT OK' parent-signatures.txt
rpm2cpio "$parent" | cpio -id --quiet --no-absolute-filenames './linux-7.3.5.tar.xz' './senemos-native-profile-7.3.5.tar.xz' './senemos-uke-adaptation-7.3.5.tar.xz' './uke-native-abm734.tar.xz' './uke-dp-sst422-73541.tar.xz' './0010-uke-charge-observe-confirmed-panel-state.patch'
printf '%s  %s\n' 048eddcf2bbed8f44e27b6e415835e8bc9204b0b898e0c5a71dd393afa00ffa8 uke-dp-sst422-73541.tar.xz | sha256sum -c --strict
tar -xJf linux-7.3.5.tar.xz
tar -xJf senemos-native-profile-7.3.5.tar.xz native-profile/patches/display native-profile/src/display native-profile/patches/boot/0009-uke-displayport-dma-scope.patch native-profile/audio-profile
tar -xJf senemos-uke-adaptation-7.3.5.tar.xz senemos-adaptation
tar -xJf uke-native-abm734.tar.xz abm734/src/display/0077-o82-live-abm734.patch abm734/src/display/abm734-post.sha256
profile=$PWD/native-profile
out=$PWD/out
cd linux-7.3.5
git init -q
mv ../senemos-adaptation .
while IFS= read -r name; do
    git apply "senemos-adaptation/patches/$name"
    printf '%s\n' "$name" >> senemos-applied-patches.txt
done < senemos-adaptation/patches/series
git apply "$profile/patches/display/0065-msm-framebuffer-pin-state.patch"
bash "$profile/src/display/prepare-source.sh" "$PWD"
for name in 0066-msm-dpu-reservation-ownership.patch 0067-msm-kms-lifecycle-unwind.patch \
            0068-msm-scanout-retirement.patch \
            0005-native-dpu-dsc-active-width.patch; do
    git apply "$profile/patches/display/$name"
done
if [[ $(cat "$profile/audio-profile") =~ ^(hdmi-only|speakers|microphones)$ ]]; then
    git apply --include="drivers/gpu/drm/msm/**" "$profile/patches/boot/0009-uke-displayport-dma-scope.patch"
    if [[ $(cat "$profile/audio-profile") =~ ^(speakers|microphones)$ ]]; then
        git apply "$profile/patches/display/0057-uke-displayport-eld-notification.patch"
    fi
fi
for name in 0069-o82-requested-vrr-floor.patch 0070-o82-adaptive-backlight.patch \
            0071-o82-panel-variants.patch; do
    git apply "$profile/patches/display/$name"
done
bash "$profile/src/display/prepare-o82-regdma.sh" "$PWD"
git apply "$profile/src/display/0075-o82-avr-retime-rollback.patch"
git apply --include=drivers/gpu/drm/msm/msm_atomic.c --include=drivers/gpu/drm/msm/dsi/dsi.h --include=drivers/gpu/drm/panel/panel-xiaomi-o82.c --include=include/linux/qcom-uke-display.h ../abm734/src/display/0077-o82-live-abm734.patch
grep -F '  drivers/gpu/drm/msm/msm_atomic.c' ../abm734/src/display/abm734-post.sha256 | sha256sum -c --strict

panel=drivers/gpu/drm/panel/panel-xiaomi-o82.c
git apply --check --include="$panel" --include=include/drm/uke-o82-charge-screen.h ../0010-uke-charge-observe-confirmed-panel-state.patch
git apply --include="$panel" --include=include/drm/uke-o82-charge-screen.h ../0010-uke-charge-observe-confirmed-panel-state.patch
patch=$inputs/0001-drm-panel-o82-use-144hz-for-boot-handoff.patch
sha256sum -c --strict "$inputs/before.sha256"
git apply --check --whitespace=error "$patch"
git apply --whitespace=error "$patch"
sha256sum -c --strict "$inputs/after.sha256"
for compiler in gcc clang; do
    bash "$inputs/check-preferred.sh" "$panel" "$inputs/test-preferred.c" "$out" "$compiler"
done | tee "$out/tests.txt"
[[ $(grep -Fxc 'Native O82 preferred mode and five fitted profile cases passed.' "$out/tests.txt") == 4 ]]
cp "$inputs/accepted.config" "$out/.config"
scripts/config --file "$out/.config" --set-str INITRAMFS_SOURCE '' --set-str MODULE_SIG_KEY certs/signing_key.pem \
    --set-str SYSTEM_TRUSTED_KEYS '' --set-str SYSTEM_REVOCATION_KEYS ''
make -s O="$out" ARCH=arm64 LLVM=1 LLVM_IAS=1 -j4 olddefconfig prepare modules_prepare
object="${panel%.c}.o"
make -s O="$out" ARCH=arm64 LLVM=1 LLVM_IAS=1 -j4 "$object"
llvm-readelf -h "$out/$object" | grep -F AArch64
llvm-nm "$out/$object" | grep -E ' [tT] o82_abm_update$'
git apply --reverse --check --whitespace=error "$patch"
git apply --reverse --whitespace=error "$patch"
sha256sum -c --strict "$inputs/before.sha256"
{
    cat "$inputs/parent.sha256" "$inputs/before.sha256" "$inputs/after.sha256" "$out/tests.txt"
    (cd "$out"; sha256sum "$object")
    printf '%s\n' 'Signed cumulative O82 ABM and charge-screen preimage, panel patch inverse, and AArch64 object verified.'
} > "$result"
