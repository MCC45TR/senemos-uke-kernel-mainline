#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C

[[ $# == 2 || $# == 3 ]]
phase=$1
tree=$(realpath -e -- "$2")
assets=$(cd -- "$(dirname -- "$0")" && pwd)
patch="$assets/0029-uke-bind-fixed-cap-to-settings-epoch.patch"
driver=drivers/power/supply/qcom_battmgr

check_receipt() {
    local proof digest file
    (cd "$assets"; sha256sum --strict -c --quiet proof.sha256)
    proof=$(rpm2cpio "$assets/uke-kernel-migration-check-7.3.5-27.fixed_cap_epoch.fc46.aarch64.rpm" |
        cpio -i --quiet --to-stdout ./usr/share/uke-kernel-migration-check/fixed-cap-epoch735/qualification.txt)
    grep -Fxq 'Signed normal Uke 7.3.5-21 source, COPR 11366897, with fitted read-only FCC.' <<<"$proof"
    grep -Fxq 'Previous source failed the stale settings dispatcher and wire regression checks.' <<<"$proof"
    grep -Fxq 'ARM64 QCOM battery driver object compiled and the patch reverses to the exact FCC source preimage.' <<<"$proof"
    test "$(grep -Fc '156 fixed-target' <<<"$proof")" = 2
    for file in "$patch" "$assets/before.sha256" "$assets/after.sha256"; do
        read -r digest _ < <(sha256sum "$file")
        grep -Fxq "$digest  ./${file##*/}" <<<"$proof"
    done
}

case $phase in
    prepare)
        [[ $# == 2 ]]
        check_receipt
        cd -- "$tree"
        sha256sum --strict -c --quiet "$assets/before.sha256"
        git apply --check --whitespace=error "$patch"
        git apply --whitespace=error "$patch"
        sha256sum --strict -c --quiet "$assets/after.sha256"
        ;;
    linked)
        [[ $# == 3 && $3 =~ ^[0-9]+\.[0-9]+\.[0-9]+-[0-9]+$ ]]
        cd -- "$tree"
        for feature in CURRENT OEM_STATUS READY_PUBLICATION THRESHOLDS; do
            grep -Fxq "CONFIG_BATTERY_QCOM_BATTMGR_UKE_${feature}=y" .config
        done
        readelf -h "$driver.ko" | grep -F AArch64
        [[ $(modinfo -F vermagic "$driver.ko") == "$3 "* ]]
        readelf -Ws "$driver.ko" | awk '
            $7!="UND" && $8=="uke_charge_apply_existing_cap_online_store" { apply=1 }
            $7!="UND" && $8=="dev_attr_uke_oem_batt_fcc_raw" { fcc=1 }
            END { exit !(apply && fcc) }
        '
        sha256sum "$driver.ko"
        ;;
    restore)
        [[ $# == 2 ]]
        cd -- "$tree"
        sha256sum --strict -c --quiet "$assets/after.sha256"
        git apply --reverse --check --whitespace=error "$patch"
        git apply --reverse --whitespace=error "$patch"
        sha256sum --strict -c --quiet "$assets/before.sha256"
        ;;
    *)
        exit 2 ;;
esac
