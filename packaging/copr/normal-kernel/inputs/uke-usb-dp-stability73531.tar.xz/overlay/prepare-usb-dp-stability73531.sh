#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C
[[ $# == 2 ]]
assets=$(cd -- "$(dirname -- "$0")" && pwd)
tree=$(realpath -e -- "$2")
key=2204a661ea630a5303500085538797e72a3e4eca
aux="$assets/mst-keep-aux-after-last-stream.patch"
training="$assets/uke-dp-propagate-training-failure.patch"
mst="$assets/msm-dp-mst-align-mode-list-with-atomic.patch"
cd -- "$tree"
(cd -- "$assets" && sha256sum -c --strict --quiet SHA256SUMS)
case "$1" in
    prepare)
        sha256sum -c --strict "$assets/before.sha256" "$assets/mst-mode-before.sha256"
        [[ $(gpg --batch --with-colons --show-keys "$assets/parent-key.gpg" |
            awk -F: '$1=="fpr" && !seen++ {print tolower($10)}') == "$key" ]]
        umask 077
        trust=$(mktemp -d --tmpdir="$tree" .uke-usb-dp.XXXXXXXX)
        trap 'find "$trust" -maxdepth 1 -type f -delete; rmdir -- "$trust"' EXIT
        rpmkeys --dbpath "$trust" --import "$assets/parent-key.gpg"
        proof="$assets/uke-kernel-migration-check-7.3.5-55.uke_usb_dp_stability31.fc46.aarch64.rpm"
        rpmkeys --dbpath "$trust" --checksig -v "$proof" > "$trust/signatures"
        [[ $(grep -Fc "key fingerprint: $key: OK" "$trust/signatures") == 2 ]]
        ! grep -Eq 'NOKEY|BAD|NOT OK' "$trust/signatures"
        rpm2cpio "$proof" | cpio -i --quiet --to-stdout             './usr/share/uke-kernel-migration-check/usb-dp-stability31/qualification.txt' > "$trust/receipt"
        grep -Fxq 'Four native AArch64 MSM DP objects and exact patch inverses verified.' "$trust/receipt"
        [[ $(grep -c 'cases passed[.]$' "$trust/receipt") == 12 ]]
        (
            cd "$assets"
            for entry in before.sha256 after.sha256 training-after.sha256 mst-mode-before.sha256 mst-mode-after.sha256                 "${aux##*/}" "${training##*/}" "${mst##*/}"; do
                grep -Fxq "$(sha256sum -- "$entry")" "$trust/receipt"
            done
        )
        git apply --check --whitespace=error "$aux"
        git apply --whitespace=error "$aux"
        sha256sum -c --strict "$assets/after.sha256"
        git apply --check --whitespace=error "$training" "$mst"
        git apply --whitespace=error "$training" "$mst"
        sha256sum -c --strict "$assets/training-after.sha256" "$assets/mst-mode-after.sha256"
        ;;
    restore)
        sha256sum -c --strict "$assets/training-after.sha256" "$assets/mst-mode-after.sha256"
        git apply --reverse --check --whitespace=error "$mst" "$training"
        git apply --reverse --whitespace=error "$mst" "$training"
        sha256sum -c --strict "$assets/after.sha256"
        git apply --reverse --check --whitespace=error "$aux"
        git apply --reverse --whitespace=error "$aux"
        sha256sum -c --strict "$assets/before.sha256" "$assets/mst-mode-before.sha256"
        ;;
    *) exit 2 ;;
esac
