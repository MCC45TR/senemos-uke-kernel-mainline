#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C
umask 077
[[ $# == 2 ]]
assets=$(cd -- "$(dirname -- "$0")" && pwd)
makefile=drivers/media/i2c/Makefile
patch=$assets/0001-arm64-describe-fitted-front-camera-id.patch
make_rule='obj-$(CONFIG_SM_CAMCC_7675) += uke-front-camera-id.o'
camera_files=(uke-front-camera-id.c uke-front-camera-clock.h uke-front-sensor-power.h)
fingerprint=2204a661ea630a5303500085538797e72a3e4eca

check_receipt() {
    local rpm=$1 program=$2 receipt=$3
    rpmkeys --dbpath "$trust/rpm" --checksig -v "$rpm" > "$trust/signatures"
    [[ $(grep -Fc "key fingerprint: $fingerprint: OK" "$trust/signatures") == 2 ]]
    ! grep -Eq 'NOKEY|BAD|NOT OK' "$trust/signatures"
    rpm2cpio "$rpm" |
        cpio -i --quiet --to-stdout "./usr/share/uke-kernel-migration-check/$program/qualification.txt" > "$receipt"
}

cd "$(realpath -e "$2")"
(cd "$assets"; sha256sum -c --strict --quiet SHA256SUMS)
case "$1" in
    prepare)
        sha256sum -c --strict "$assets/abl-before.sha256"
        git apply --check --whitespace=error "$patch"
        [[ $(gpg --batch --with-colons --show-keys "$assets/parent-key.gpg" |
            awk -F: '$1=="fpr"{print tolower($10);exit}') == "$fingerprint" ]]
        trust=$(mktemp -d --tmpdir="$PWD" .front-id-proof.XXXXXXXX)
        trap 'find "$trust" -depth -delete' EXIT
        mkdir "$trust/rpm"
        rpmkeys --dbpath "$trust/rpm" --import "$assets/parent-key.gpg"
        check_receipt "$assets/uke-kernel-migration-check-7.3.5-67.uke_front_pin_owner35.fc46.aarch64.rpm" \
            front-pin-owner35 "$trust/pins"
        [[ $(grep -Fxc '20 startup failures, exact power/ID order, EGPIO handback and repeated ownership passed.' "$trust/pins") == 4 ]]
        grep -Fxq "$(cd "$assets"; sha256sum uke-front-sensor-power.h)" "$trust/pins"
        check_receipt "$assets/uke-kernel-migration-check-7.3.5-69.uke_front_camera_id35.fc46.aarch64.rpm" \
            front-camera-id35 "$trust/driver"
        [[ $(grep -Fxc 'Fitted camera DT, inactive legacy sensor, nine refusals and no-space guard passed.' "$trust/driver") == 4 ]]
        grep -Fxq 'Native AArch64 front camera driver and selected DT fixup objects compiled.' "$trust/driver"
        (cd "$assets"; sha256sum "${camera_files[@]}" uke-front-camera-id-dt.h) |
            while IFS= read -r line; do grep -Fxq "$line" "$trust/driver"; done
        [[ -f $makefile && ! -e $assets/Makefile.before ]]
        ! grep -Fq 'uke-front-camera-id.o' "$makefile"
        for name in "${camera_files[@]}"; do [[ ! -e drivers/media/i2c/$name ]]; done
        [[ ! -e arch/arm64/kernel/uke-front-camera-id-dt.h ]]
        cp -T "$makefile" "$assets/Makefile.before"
        for name in "${camera_files[@]}"; do install -m644 "$assets/$name" "drivers/media/i2c/$name"; done
        install -m644 "$assets/uke-front-camera-id-dt.h" arch/arm64/kernel/
        printf '\n%s\n' "$make_rule" >> "$makefile"
        git apply --whitespace=error "$patch"
        sha256sum -c --strict "$assets/abl-after.sha256"
        ;;
    restore)
        sha256sum -c --strict "$assets/abl-after.sha256"
        git apply --reverse --check --whitespace=error "$patch"
        { cat "$assets/Makefile.before"; printf '\n%s\n' "$make_rule"; } | cmp - "$makefile"
        for name in "${camera_files[@]}"; do cmp "$assets/$name" "drivers/media/i2c/$name"; done
        cmp "$assets/uke-front-camera-id-dt.h" arch/arm64/kernel/uke-front-camera-id-dt.h
        git apply --reverse --whitespace=error "$patch"
        cp -T "$assets/Makefile.before" "$makefile"
        unlink "$assets/Makefile.before"
        for name in "${camera_files[@]}"; do unlink "drivers/media/i2c/$name"; done
        unlink arch/arm64/kernel/uke-front-camera-id-dt.h
        sha256sum -c --strict "$assets/abl-before.sha256"
        ;;
    *) exit 2 ;;
esac
