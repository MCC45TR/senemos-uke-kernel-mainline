// SPDX-License-Identifier: GPL-2.0-only
#include <linux/device.h>
#include <linux/i2c.h>
#include <linux/mutex.h>
#include <linux/of.h>
#include <linux/of_address.h>
#include <linux/regulator/consumer.h>
#include <linux/slab.h>
#include <linux/sysfs.h>

#include "uke-front-sensor-power.h"

struct uke_front_camera_id {
	struct uke_front_sensor_power power;
	struct mutex lock;
	bool attempted;
	int result;
	u16 id;
};

static const struct {
	const char *name;
	const char *property;
	const char *provider;
} uke_front_supplies[UKE_FRONT_RAIL_COUNT] = {
	[UKE_FRONT_BOB] = { "bob", "bob-supply", "pmxr2230_bob" },
	[UKE_FRONT_CUSTOM] = { "custom", "custom-supply", "pmxr2230_s2" },
	[UKE_FRONT_VIO] = { "vio", "vio-supply", "pmxr2230_l20" },
	[UKE_FRONT_VANA] = { "vana", "vana-supply", "camera_front_avdd_ldo" },
	[UKE_FRONT_VDIG] = { "vdig", "vdig-supply", "pm_v6c_l3" },
};

static int uke_front_camera_check_bus(struct i2c_client *client)
{
	struct device_node *bus = of_get_parent(client->dev.of_node);
	struct resource registers;
	bool matched;

	matched = bus && client->addr == 0x10 &&
		  !(client->flags & I2C_CLIENT_TEN) &&
		  i2c_check_functionality(client->adapter, I2C_FUNC_I2C) &&
		  of_device_is_compatible(bus, "qcom,geni-i2c") &&
		  !of_address_to_resource(bus, 0, &registers) &&
		  registers.start == 0x880000;
	of_node_put(bus);
	return matched ? 0 : -ENODEV;
}

static int uke_front_camera_get_supplies(struct uke_front_sensor_power *power)
{
	struct device *dev = power->sensor;
	struct device_node *node, *supply;
	const char *name;
	unsigned int i;
	bool matched;

	node = dev->of_node;
	for (i = 0; i < UKE_FRONT_RAIL_COUNT; i++) {
		if (of_property_count_u32_elems(node, uke_front_supplies[i].property) != 1)
			return -EINVAL;
		supply = of_parse_phandle(node, uke_front_supplies[i].property, 0);
		if (!supply)
			return -EINVAL;
		matched = !of_property_read_string(supply, "regulator-name", &name) &&
			  !strcmp(name, uke_front_supplies[i].provider);
		of_node_put(supply);
		if (!matched)
			return -EINVAL;
		power->supplies[i] = devm_regulator_get_optional(dev, uke_front_supplies[i].name);
		if (IS_ERR(power->supplies[i]))
			return PTR_ERR(power->supplies[i]);
	}
	return 0;
}

static int uke_front_camera_read_id(struct i2c_client *client,
				    struct uke_front_camera_id *sensor)
{
	struct uke_front_sensor_power *power = &sensor->power;
	struct device *dev = &client->dev;
	void *resources;
	int ret;

	resources = devres_open_group(dev, NULL, GFP_KERNEL);
	if (!resources)
		return -ENOMEM;

	ret = uke_front_camera_get_supplies(power);
	if (ret)
		goto release;
	power->clock = uke_front_camera_clock_get(dev);
	if (IS_ERR(power->clock)) {
		ret = PTR_ERR(power->clock);
		goto release;
	}

	sensor->attempted = true;
	ret = uke_front_sensor_identify(client, power, &sensor->id);
	sensor->result = ret;
	if (power->fault) {
		devres_remove_group(dev, resources);
		dev_err(dev, "front camera power ownership retained after error %d\n", power->fault);
		return ret;
	}

release:
	devres_release_group(dev, resources);
	return ret == -EPROBE_DEFER ? -EAGAIN : ret;
}

static ssize_t sensor_id_show(struct device *dev, struct device_attribute *attr,
			      char *buf)
{
	struct i2c_client *client = to_i2c_client(dev);
	struct uke_front_camera_id *sensor = i2c_get_clientdata(client);
	int ret;

	guard(mutex)(&sensor->lock);

	ret = sensor->attempted ? sensor->result : uke_front_camera_read_id(client, sensor);
	if (ret)
		return ret;
	return sysfs_emit(buf, "0x%04x\n", sensor->id);
}

static DEVICE_ATTR(sensor_id, 0400, sensor_id_show, NULL);

static struct attribute *uke_front_camera_attrs[] = {
	&dev_attr_sensor_id.attr,
	NULL,
};

ATTRIBUTE_GROUPS(uke_front_camera);

static int uke_front_camera_probe(struct i2c_client *client)
{
	struct device *dev = &client->dev;
	struct uke_front_camera_id *sensor;
	int ret;

	ret = uke_front_camera_check_bus(client);
	if (ret)
		return ret;
	ret = uke_front_sensor_pins_graph(dev);
	if (ret)
		return ret;

	sensor = devm_kzalloc(dev, sizeof(*sensor), GFP_KERNEL);
	if (!sensor)
		return -ENOMEM;

	mutex_init(&sensor->lock);
	sensor->power.sensor = dev;
	i2c_set_clientdata(client, sensor);
	return 0;
}

static const struct of_device_id uke_front_camera_of_match[] = {
	{ .compatible = "xiaomi,uke-front-camera-identify" },
	{ }
};

static struct i2c_driver uke_front_camera_driver = {
	.driver = {
		.name = "uke-front-camera-identify",
		.of_match_table = uke_front_camera_of_match,
		.suppress_bind_attrs = true,
		.dev_groups = uke_front_camera_groups,
	},
	.probe = uke_front_camera_probe,
};

builtin_i2c_driver(uke_front_camera_driver);
