/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef UKE_FRONT_CAMERA_CLOCK_H
#define UKE_FRONT_CAMERA_CLOCK_H

#include <dt-bindings/clock/qcom,sm7675-camcc.h>
#include <linux/clk.h>
#include <linux/device.h>
#include <linux/device/driver.h>
#include <linux/of.h>
#include <linux/platform_device.h>
#include <linux/pm_domain.h>
#include <linux/pm_runtime.h>
#include <linux/property.h>
#include <linux/slab.h>
#include <linux/soc/qcom/sm7675-camcc.h>

#define UKE_FRONT_MCLK_HZ 19200000UL

struct uke_front_camera_clock {
	struct platform_device *anchor;
	struct device *domain;
	struct clk *mclk;
	bool domain_held;
	bool enabled;
};

/* Called by a permanent driver, with the sensor's power lock held. */
static int uke_front_camera_clock_off(struct uke_front_camera_clock *clock)
{
	int ret;

	if (clock->enabled) {
		clk_disable_unprepare(clock->mclk);
		clk_rate_exclusive_put(clock->mclk);
		clock->enabled = false;
	}
	if (!clock->domain_held)
		return 0;

	ret = pm_runtime_put_sync_suspend(clock->domain);
	if (ret < 0) {
		/* The failed put consumed the count but did not prove suspension. */
		pm_runtime_get_noresume(clock->domain);
		return ret;
	}
	clock->domain_held = false;
	return 0;
}

static int uke_front_camera_clock_on(struct uke_front_camera_clock *clock)
{
	int ret, cleanup;

	if (clock->enabled || clock->domain_held)
		return -EBUSY;

	ret = qcom_sm7675_camcc_status();
	if (ret)
		return ret;
	ret = pm_runtime_resume_and_get(clock->domain);
	if (ret < 0)
		return ret;
	clock->domain_held = true;
	ret = qcom_sm7675_camcc_status();
	if (ret)
		goto put_domain;

	ret = clk_set_rate_exclusive(clock->mclk, UKE_FRONT_MCLK_HZ);
	if (ret)
		goto put_domain;
	if (clk_get_rate(clock->mclk) != UKE_FRONT_MCLK_HZ) {
		ret = -ERANGE;
		goto put_rate;
	}
	ret = clk_prepare_enable(clock->mclk);
	if (ret)
		goto put_rate;
	clock->enabled = true;
	return 0;

put_rate:
	clk_rate_exclusive_put(clock->mclk);
put_domain:
	cleanup = uke_front_camera_clock_off(clock);
	return cleanup ?: ret;
}

static void uke_front_camera_clock_release(void *data)
{
	struct uke_front_camera_clock *clock = data;
	struct device *domain;

	if (clock->enabled || clock->domain_held) {
		dev_err(&clock->anchor->dev, "camera clock ownership retained until reboot\n");
		return;
	}

	/* Hold the object while generic GenPD removes and unregisters it. */
	domain = get_device(clock->domain);
	dev_pm_domain_detach(domain, true);
	if (domain->pm_domain) {
		dev_err(&clock->anchor->dev, "camera domain detach failed\n");
		put_device(domain);
		return;
	}
	put_device(domain);
	platform_device_unregister(clock->anchor);
	kfree(clock);
}

static int uke_front_camera_clock_graph(struct device_node *sensor,
					struct device_node *anchor)
{
	struct of_phandle_args pd, clk;
	int ret;

	if (of_property_present(sensor, "power-domains") ||
	    of_property_present(anchor, "compatible") ||
	    of_property_present(anchor, "required-opps") ||
	    of_count_phandle_with_args(anchor, "power-domains", "#power-domain-cells") != 1 ||
	    of_count_phandle_with_args(sensor, "clocks", "#clock-cells") != 1 ||
	    of_property_match_string(sensor, "clock-names", "xclk") != 0)
		return -EINVAL;

	ret = of_parse_phandle_with_args(anchor, "power-domains",
					"#power-domain-cells", 0, &pd);
	if (ret)
		return ret;
	ret = of_parse_phandle_with_args(sensor, "clocks", "#clock-cells", 0, &clk);
	if (!ret) {
		if (pd.args_count != 1 || pd.args[0] != CAM_CC_TITAN_TOP_GDSC ||
		    clk.args_count != 1 || clk.args[0] != CAM_CC_MCLK4_CLK ||
		    clk.np != pd.np || !of_device_is_compatible(pd.np, "qcom,sm7675-camcc"))
			ret = -EINVAL;
		of_node_put(clk.np);
	}
	of_node_put(pd.np);
	return ret;
}

/*
 * Give GenPD a separate firmware device so I2C can probe with the domain off.
 * The virtual GenPD device has no runtime-PM dependency on the sensor itself.
 */
static struct uke_front_camera_clock *
uke_front_camera_clock_get(struct device *sensor)
{
	struct uke_front_camera_clock *clock;
	struct device_node *node;
	struct platform_device *anchor;
	int ret;

	if (!of_machine_is_compatible("xiaomi,uke") || !sensor->of_node ||
	    of_node_check_flag(sensor->of_node, OF_DYNAMIC) ||
	    !sensor->driver || sensor->driver->owner ||
	    !sensor->driver->suppress_bind_attrs)
		return ERR_PTR(-EINVAL);

	node = of_get_child_by_name(sensor->of_node, "camera-clock-domain");
	if (!node)
		return ERR_PTR(-EINVAL);
	ret = uke_front_camera_clock_graph(sensor->of_node, node);
	if (ret)
		goto put_node;
	ret = qcom_sm7675_camcc_status();
	if (ret)
		goto put_node;

	clock = kzalloc_obj(*clock);
	if (!clock) {
		ret = -ENOMEM;
		goto put_node;
	}
	clock->mclk = devm_clk_get(sensor, "xclk");
	if (IS_ERR(clock->mclk)) {
		ret = PTR_ERR(clock->mclk);
		goto free_clock;
	}
	anchor = platform_device_alloc("uke-front-camera-domain", PLATFORM_DEVID_AUTO);
	if (!anchor) {
		ret = -ENOMEM;
		goto free_clock;
	}
	device_set_node(&anchor->dev, fwnode_handle_get(of_fwnode_handle(node)));
	ret = platform_device_add(anchor);
	if (ret) {
		platform_device_put(anchor);
		goto free_clock;
	}
	clock->anchor = anchor;
	clock->domain = dev_pm_domain_attach_by_id(&anchor->dev, 0);
	if (IS_ERR_OR_NULL(clock->domain)) {
		ret = clock->domain ? PTR_ERR(clock->domain) : -ENODEV;
		platform_device_unregister(anchor);
		goto free_clock;
	}

	of_node_put(node);
	ret = devm_add_action_or_reset(sensor, uke_front_camera_clock_release, clock);
	if (ret)
		return ERR_PTR(ret);
	return clock;

free_clock:
	kfree(clock);
put_node:
	of_node_put(node);
	return ERR_PTR(ret);
}

#endif
