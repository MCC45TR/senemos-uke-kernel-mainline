/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef UKE_FRONT_CAMERA_ID_DT_H
#define UKE_FRONT_CAMERA_ID_DT_H

/* Used after the fitted GENI, EEPROM and VDIG admission on Linux's FDT copy. */
#define UKE_FRONT_ID_OLD UKE_FRONT_BUS "/qcom,cam-sensor1"
#define UKE_FRONT_ID_NEW UKE_FRONT_BUS "/camera@10"
#define UKE_FRONT_ID_CAMCC "/soc/clock-controller@ade0000"
#define UKE_FRONT_ID_MCLK_ACTIVE UKE_FRONT_TLMM "/cam_sensor_mclk4_active"
#define UKE_FRONT_ID_MCLK_IDLE UKE_FRONT_TLMM "/cam_sensor_mclk4_suspend"
#define UKE_FRONT_ID_RESET_ACTIVE UKE_FRONT_TLMM "/cam_sensor_front_active_rst"
#define UKE_FRONT_ID_RESET_IDLE UKE_FRONT_TLMM "/cam_sensor_front_suspend_rst"

static const char * const uke_front_id_reset_nodes[] = {
	"uke-front-reset-active",
	"uke-front-reset-parked",
	"uke-front-reset-remote",
};

static int UKE_INIT uke_front_id_add_reset(void *fdt, unsigned int index,
					   unsigned int *phandle)
{
	int tlmm, node, ret;

	tlmm = fdt_path_offset(fdt, UKE_FRONT_TLMM);
	if (tlmm < 0)
		return tlmm;
	ret = fdt_generate_phandle(fdt, phandle);
	if (ret)
		return ret;
	node = fdt_add_subnode(fdt, tlmm, uke_front_id_reset_nodes[index]);
	if (node < 0)
		return node;
	ret = fdt_setprop_u32(fdt, node, "phandle", *phandle);
	if (ret)
		return ret;
	ret = fdt_setprop_string(fdt, node, "pins", "gpio3");
	if (ret)
		return ret;
	if (index == 2)
		return fdt_setprop_string(fdt, node, "function", "egpio");
	ret = fdt_setprop_u32(fdt, node, "drive-strength", 2);
	if (ret)
		return ret;
	if (index == 0)
		return fdt_setprop(fdt, node, "bias-disable", NULL, 0);
	ret = fdt_setprop(fdt, node, "bias-pull-down", NULL, 0);
	if (ret)
		return ret;
	return fdt_setprop(fdt, node, "output-low", NULL, 0);
}

static int UKE_INIT uke_front_camera_id_graph(void *fdt)
{
	static const char pins[] = "sensor-active\0sensor-parked\0sensor-remote";
	static const struct {
		const char *legacy, *native, *name;
	} supply[] = {
		{ "cam_bob-supply", "bob-supply", "pmxr2230_bob" },
		{ "cam_v_custom1-supply", "custom-supply", "pmxr2230_s2" },
		{ "cam_vio-supply", "vio-supply", "pmxr2230_l20" },
		{ "cam_vana-supply", "vana-supply", "camera_front_avdd_ldo" },
		{ "cam_vdig-supply", "vdig-supply", "pm_v6c_l3" },
	};
	fdt32_t reset[3], gpio[6], clocks[2], pins_active[2], pins_idle[2], pd[2];
	fdt32_t supplied[ARRAY_SIZE(supply)];
	unsigned int mclk_active, mclk_idle, reset_active, reset_idle, phandle;
	int bus, sensor, child, camcc, tlmm, vdig, node, anchor, ret, len;
	const fdt32_t *value;
	unsigned int i;

	if (fdt_node_check_compatible(fdt, 0, "xiaomi,uke") ||
	    fdt_node_check_compatible(fdt, 0, "qcom,sm7675"))
		return 0;
	bus = fdt_path_offset(fdt, UKE_FRONT_BUS);
	sensor = fdt_path_offset(fdt, UKE_FRONT_ID_OLD);
	camcc = fdt_path_offset(fdt, UKE_FRONT_ID_CAMCC);
	tlmm = fdt_path_offset(fdt, UKE_FRONT_TLMM);
	vdig = fdt_path_offset(fdt, UKE_FRONT_VDIG_PROVIDER);
	if (bus < 0 || sensor < 0 || camcc < 0 || tlmm < 0 || vdig < 0 ||
	    fdt_node_check_compatible(fdt, bus, "qcom,geni-i2c") ||
	    fdt_node_check_compatible(fdt, sensor, "qcom,cam-i2c-sensor") ||
	    fdt_node_check_compatible(fdt, camcc, "qcom,sm7675-camcc") ||
	    fdt_node_check_compatible(fdt, tlmm, "qcom,cliffs-pinctrl") ||
	    !uke_front_u32(fdt, bus, "#address-cells", 1) ||
	    !uke_front_u32(fdt, bus, "#size-cells", 0) ||
	    !uke_front_disabled(fdt, sensor) ||
	    !uke_front_u32(fdt, sensor, "reg", 0x20) ||
	    !uke_front_u32(fdt, sensor, "cell-index", 1) ||
	    !uke_front_u32(fdt, sensor, "csiphy-sd-index", 4) ||
	    !uke_front_u32(fdt, sensor, "gpio-reset", 1) ||
	    !uke_front_u32(fdt, sensor, "clock-rates", 19200000) ||
	    !uke_front_u32(fdt, camcc, "#clock-cells", 1) ||
	    !uke_front_u32(fdt, camcc, "#power-domain-cells", 1) ||
	    !uke_front_u32(fdt, tlmm, "#gpio-cells", 2) ||
	    !uke_front_bytes(fdt, vdig, UKE_FRONT_VDIG_READY, "", 0))
		return 0;

	clocks[0] = cpu_to_fdt32(fdt_get_phandle(fdt, camcc));
	clocks[1] = cpu_to_fdt32(113);
	reset[0] = cpu_to_fdt32(fdt_get_phandle(fdt, tlmm));
	reset[1] = cpu_to_fdt32(3);
	reset[2] = cpu_to_fdt32(1);
	gpio[0] = gpio[3] = reset[0];
	gpio[1] = cpu_to_fdt32(68);
	gpio[4] = reset[1];
	gpio[2] = gpio[5] = 0;
	if (!clocks[0] || !reset[0] ||
	    !uke_front_bytes(fdt, sensor, "clocks", clocks, sizeof(clocks)) ||
	    !uke_front_bytes(fdt, sensor, "gpios", gpio, sizeof(gpio)))
		return 0;

	mclk_active = uke_front_phandle(fdt, UKE_FRONT_ID_MCLK_ACTIVE);
	mclk_idle = uke_front_phandle(fdt, UKE_FRONT_ID_MCLK_IDLE);
	reset_active = uke_front_phandle(fdt, UKE_FRONT_ID_RESET_ACTIVE);
	reset_idle = uke_front_phandle(fdt, UKE_FRONT_ID_RESET_IDLE);
	if (!mclk_active || !mclk_idle || !reset_active || !reset_idle ||
	    !uke_front_pin(fdt, UKE_FRONT_ID_MCLK_ACTIVE, "gpio68", 7,
			   "cam_aon_mclk4", "bias-disable") ||
	    !uke_front_pin(fdt, UKE_FRONT_ID_MCLK_IDLE, "gpio68", 7,
			   "cam_aon_mclk4", "bias-pull-down"))
		return 0;
	pins_active[0] = cpu_to_fdt32(mclk_active);
	pins_active[1] = cpu_to_fdt32(reset_active);
	pins_idle[0] = cpu_to_fdt32(mclk_idle);
	pins_idle[1] = cpu_to_fdt32(reset_idle);
	if (!uke_front_bytes(fdt, sensor, "pinctrl-0", pins_active, sizeof(pins_active)) ||
	    !uke_front_bytes(fdt, sensor, "pinctrl-1", pins_idle, sizeof(pins_idle)))
		return 0;
	node = fdt_path_offset(fdt, UKE_FRONT_ID_RESET_ACTIVE "/config");
	if (node < 0 || !uke_front_bytes(fdt, node, "qcom,apps", "", 0))
		return 0;
	node = fdt_path_offset(fdt, UKE_FRONT_ID_RESET_IDLE "/config");
	if (node < 0 || !uke_front_bytes(fdt, node, "qcom,remote", "", 0) ||
	    !uke_front_bytes(fdt, node, "output-low", "", 0))
		return 0;

	for (i = 0; i < ARRAY_SIZE(supply); i++) {
		value = fdt_getprop(fdt, sensor, supply[i].legacy, &len);
		if (!value || len != sizeof(*value))
			return 0;
		supplied[i] = *value;
		node = fdt_node_offset_by_phandle(fdt, fdt32_to_cpu(*value));
		if (node < 0 || (i == ARRAY_SIZE(supply) - 1 && fdt_parent_offset(fdt, node) != vdig) ||
		    !uke_front_bytes(fdt, node, "regulator-name", supply[i].name,
				     strlen(supply[i].name) + 1))
			return 0;
	}
	for (i = 0; i < ARRAY_SIZE(uke_front_id_reset_nodes); i++)
		if (fdt_subnode_offset(fdt, tlmm, uke_front_id_reset_nodes[i]) != -FDT_ERR_NOTFOUND)
			return 0;
	fdt_for_each_subnode(child, fdt, bus)
		if (uke_front_u32(fdt, child, "reg", 0x10))
			return 0;
	if (fdt_path_offset(fdt, UKE_FRONT_ID_NEW) != -FDT_ERR_NOTFOUND)
		return 0;

	/* All new mux nodes remain unreferenced until the sensor node is complete. */
	pins_active[1] = cpu_to_fdt32(mclk_active);
	pins_idle[1] = cpu_to_fdt32(mclk_idle);
	ret = uke_front_id_add_reset(fdt, 0, &phandle);
	if (ret)
		return ret;
	pins_active[0] = cpu_to_fdt32(phandle);
	ret = uke_front_id_add_reset(fdt, 1, &phandle);
	if (ret)
		return ret;
	pins_idle[0] = cpu_to_fdt32(phandle);
	ret = uke_front_id_add_reset(fdt, 2, &phandle);
	if (ret)
		return ret;

	bus = fdt_path_offset(fdt, UKE_FRONT_BUS);
	node = fdt_add_subnode(fdt, bus, "camera@10");
	if (node < 0)
		return node;
	ret = fdt_setprop_string(fdt, node, "status", "disabled");
	if (ret)
		return ret;
	if ((ret = fdt_setprop_string(fdt, node, "compatible", "xiaomi,uke-front-camera-identify")) ||
	    (ret = fdt_setprop_u32(fdt, node, "reg", 0x10)) ||
	    (ret = fdt_setprop(fdt, node, "reset-gpios", reset, sizeof(reset))) ||
	    (ret = fdt_setprop(fdt, node, "pinctrl-names", pins, sizeof(pins))) ||
	    (ret = fdt_setprop(fdt, node, "pinctrl-0", pins_active, sizeof(pins_active))) ||
	    (ret = fdt_setprop(fdt, node, "pinctrl-1", pins_idle, sizeof(pins_idle))) ||
	    (ret = fdt_setprop_u32(fdt, node, "pinctrl-2", phandle)) ||
	    (ret = fdt_setprop(fdt, node, "clocks", clocks, sizeof(clocks))) ||
	    (ret = fdt_setprop_string(fdt, node, "clock-names", "xclk")))
		return ret;
	for (i = 0; i < ARRAY_SIZE(supply); i++) {
		ret = fdt_setprop(fdt, node, supply[i].native, &supplied[i], sizeof(supplied[i]));
		if (ret)
			return ret;
	}
	anchor = fdt_add_subnode(fdt, node, "camera-clock-domain");
	if (anchor < 0)
		return anchor;
	pd[0] = clocks[0];
	pd[1] = cpu_to_fdt32(0);
	ret = fdt_setprop(fdt, anchor, "power-domains", pd, sizeof(pd));
	if (ret)
		return ret;
	return fdt_setprop_string(fdt, node, "status", "okay");
}

#endif
