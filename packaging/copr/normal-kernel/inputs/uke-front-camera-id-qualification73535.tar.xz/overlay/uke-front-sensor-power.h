/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef UKE_FRONT_SENSOR_POWER_H
#define UKE_FRONT_SENSOR_POWER_H

#include <dt-bindings/gpio/gpio.h>
#include <linux/delay.h>
#include <linux/gpio/consumer.h>
#include <linux/i2c.h>
#include <linux/limits.h>
#include <linux/of_address.h>
#include <linux/pinctrl/consumer.h>
#include <linux/regulator/consumer.h>
#include <linux/unaligned.h>
#include "uke-front-camera-clock.h"

enum uke_front_rail {
	UKE_FRONT_BOB,
	UKE_FRONT_CUSTOM,
	UKE_FRONT_VIO,
	UKE_FRONT_VANA,
	UKE_FRONT_VDIG,
	UKE_FRONT_RAIL_COUNT,
};

static const struct {
	unsigned int microvolts;
	unsigned int microamps;
	unsigned int settle_us;
} uke_front_rail_spec[UKE_FRONT_RAIL_COUNT] = {
	[UKE_FRONT_BOB] = { 3296000, 103000, 1000 },
	[UKE_FRONT_CUSTOM] = { 1256000, 454000, 1000 },
	[UKE_FRONT_VIO] = { 1800000, 106000, 1000 },
	[UKE_FRONT_VANA] = { 2800000, 102000, 0 },
	[UKE_FRONT_VDIG] = { 1200000, 130000, 5000 },
};

struct uke_front_sensor_power {
	struct uke_front_camera_clock *clock;
	struct device *sensor;
	struct pinctrl *pinctrl;
	struct pinctrl_state *parked;
	struct pinctrl_state *remote;
	struct gpio_desc *reset;
	struct regulator *supplies[UKE_FRONT_RAIL_COUNT];
	unsigned long voltage_votes;
	unsigned long load_votes;
	unsigned long enabled;
	bool reset_configured;
	int fault;
};

static bool uke_front_sensor_pin_node(struct device_node *sensor, const char *property,
				      int index, struct device_node *tlmm,
				      const char *name)
{
	struct device_node *node = of_parse_phandle(sensor, property, index);
	struct device_node *provider;
	bool valid = false;

	if (node) {
		provider = of_get_parent(node);
		valid = provider == tlmm && of_node_name_eq(node, name);
		of_node_put(provider);
	}
	of_node_put(node);
	return valid;
}

static bool uke_front_sensor_pin_states(struct device_node *sensor,
				       struct device_node *tlmm)
{
	return of_property_count_u32_elems(sensor, "pinctrl-0") == 2 &&
	       of_property_count_u32_elems(sensor, "pinctrl-1") == 2 &&
	       of_property_count_u32_elems(sensor, "pinctrl-2") == 1 &&
	       uke_front_sensor_pin_node(sensor, "pinctrl-0", 0, tlmm,
					 "uke-front-reset-active") &&
	       uke_front_sensor_pin_node(sensor, "pinctrl-0", 1, tlmm,
					 "cam_sensor_mclk4_active") &&
	       uke_front_sensor_pin_node(sensor, "pinctrl-1", 0, tlmm,
					 "uke-front-reset-parked") &&
	       uke_front_sensor_pin_node(sensor, "pinctrl-1", 1, tlmm,
					 "cam_sensor_mclk4_suspend") &&
	       uke_front_sensor_pin_node(sensor, "pinctrl-2", 0, tlmm,
					 "uke-front-reset-remote");
}

/*
 * Admit only the fitted front reset path. Named states are selected by this
 * driver, so general device binding never takes the firmware's idle pin.
 */
static int uke_front_sensor_pins_graph(struct device *sensor)
{
	struct device_node *node = sensor->of_node;
	struct of_phandle_args gpio;
	struct resource tlmm;
	int ret;

	if (!of_machine_is_compatible("xiaomi,uke") || !node ||
	    of_node_check_flag(node, OF_DYNAMIC) ||
	    !of_device_is_compatible(node, "xiaomi,uke-front-camera-identify") ||
	    of_property_count_strings(node, "pinctrl-names") != 3 ||
	    of_property_match_string(node, "pinctrl-names", "sensor-active") != 0 ||
	    of_property_match_string(node, "pinctrl-names", "sensor-parked") != 1 ||
	    of_property_match_string(node, "pinctrl-names", "sensor-remote") != 2 ||
	    of_count_phandle_with_args(node, "reset-gpios", "#gpio-cells") != 1)
		return -EINVAL;

	ret = of_parse_phandle_with_args(node, "reset-gpios", "#gpio-cells", 0, &gpio);
	if (ret)
		return ret;
	if (gpio.args_count != 2 || gpio.args[0] != 3 ||
	    gpio.args[1] != GPIO_ACTIVE_LOW ||
	    !of_device_is_compatible(gpio.np, "qcom,cliffs-pinctrl") ||
	    of_address_to_resource(gpio.np, 0, &tlmm) || tlmm.start != 0x0f000000 ||
	    !uke_front_sensor_pin_states(node, gpio.np))
		ret = -EINVAL;
	of_node_put(gpio.np);
	return ret;
}

static int uke_front_sensor_pins_off(struct uke_front_sensor_power *power)
{
	int ret;

	if (!power->pinctrl)
		return 0;

	/* Park the reset line low before removing the AP mux ownership. */
	if (power->reset) {
		ret = pinctrl_select_state(power->pinctrl, power->parked);
		if (ret)
			return ret;
		gpiod_put(power->reset);
		power->reset = NULL;
	}
	ret = pinctrl_select_state(power->pinctrl, power->remote);
	if (ret)
		return ret;

	/* The hardware stays in EGPIO. Drop the Linux mux claim for next use. */
	pinctrl_put(power->pinctrl);
	power->pinctrl = NULL;
	return 0;
}

static int uke_front_sensor_pins_on(struct uke_front_sensor_power *power)
{
	struct pinctrl_state *active;
	struct pinctrl *pins;
	struct gpio_desc *reset;
	int ret, cleanup;

	ret = uke_front_sensor_pins_graph(power->sensor);
	if (ret)
		return ret;
	pins = pinctrl_get(power->sensor);
	if (IS_ERR(pins))
		return PTR_ERR(pins);
	active = pinctrl_lookup_state(pins, "sensor-active");
	if (IS_ERR(active)) {
		ret = PTR_ERR(active);
		goto put_pins;
	}
	power->parked = pinctrl_lookup_state(pins, "sensor-parked");
	if (IS_ERR(power->parked)) {
		ret = PTR_ERR(power->parked);
		goto put_pins;
	}
	power->remote = pinctrl_lookup_state(pins, "sensor-remote");
	if (IS_ERR(power->remote)) {
		ret = PTR_ERR(power->remote);
		goto put_pins;
	}

	/* GPIO request checks competing ownership before applying the AP mux. */
	reset = gpiod_get(power->sensor, "reset", GPIOD_ASIS);
	if (IS_ERR(reset)) {
		ret = PTR_ERR(reset);
		goto put_pins;
	}
	power->pinctrl = pins;
	power->reset = reset;
	ret = gpiod_is_active_low(reset) ? pinctrl_select_state(pins, active) : -EINVAL;
	if (!ret)
		return 0;

	cleanup = uke_front_sensor_pins_off(power);
	if (cleanup)
		power->fault = cleanup;
	return cleanup ?: ret;

put_pins:
	pinctrl_put(pins);
	return ret;
}

/* The caller owns the regulators and serializes the entire transaction. */
static int uke_front_rail_on(struct uke_front_sensor_power *power, unsigned int i)
{
	struct regulator *rail = power->supplies[i];
	int ret;

	ret = regulator_set_voltage(rail, uke_front_rail_spec[i].microvolts,
				    uke_front_rail_spec[i].microvolts);
	if (ret)
		return ret;
	power->voltage_votes |= BIT(i);
	ret = regulator_set_load(rail, uke_front_rail_spec[i].microamps);
	if (ret)
		return ret;
	power->load_votes |= BIT(i);
	ret = regulator_enable(rail);
	if (ret)
		return ret;
	power->enabled |= BIT(i);
	if (uke_front_rail_spec[i].settle_us)
		fsleep(uke_front_rail_spec[i].settle_us);
	return 0;
}

static int uke_front_rail_off(struct uke_front_sensor_power *power, unsigned int i)
{
	struct regulator *rail = power->supplies[i];
	int ret;

	if (power->enabled & BIT(i)) {
		ret = regulator_disable(rail);
		if (ret)
			return ret;
		power->enabled &= ~BIT(i);
	}
	if (power->load_votes & BIT(i)) {
		ret = regulator_set_load(rail, 0);
		if (ret)
			return ret;
		power->load_votes &= ~BIT(i);
	}
	if (power->voltage_votes & BIT(i)) {
		ret = regulator_set_voltage(rail, 0, INT_MAX);
		if (ret)
			return ret;
		power->voltage_votes &= ~BIT(i);
	}
	return 0;
}

static int uke_front_sensor_off(struct uke_front_sensor_power *power)
{
	bool clock_was_held = power->clock->domain_held;
	unsigned int i;
	int ret;

	if (power->fault)
		return power->fault;

	ret = uke_front_camera_clock_off(power->clock);
	if (ret)
		goto fault;
	if (clock_was_held)
		fsleep(2000);
	if (power->reset_configured) {
		ret = gpiod_direction_output(power->reset, 1);
		if (ret)
			goto fault;
	}
	for (i = UKE_FRONT_RAIL_COUNT; i-- > 0;) {
		ret = uke_front_rail_off(power, i);
		if (ret)
			goto fault;
	}
	power->reset_configured = false;
	ret = uke_front_sensor_pins_off(power);
	if (ret)
		goto fault;
	return 0;

fault:
	/* Retain the remaining ownership rather than dropping dependent rails. */
	power->fault = ret;
	return ret;
}

static int uke_front_sensor_on(struct uke_front_sensor_power *power)
{
	unsigned int i;
	int ret, cleanup;

	if (power->fault)
		return power->fault;
	if (power->enabled || power->voltage_votes || power->load_votes ||
	    power->clock->domain_held || power->pinctrl || power->reset)
		return -EBUSY;
	ret = qcom_sm7675_camcc_status();
	if (ret)
		return ret;
	ret = uke_front_sensor_pins_on(power);
	if (ret)
		return ret;

	for (i = UKE_FRONT_BOB; i < UKE_FRONT_VIO; i++) {
		ret = uke_front_rail_on(power, i);
		if (ret)
			goto unwind;
	}

	ret = gpiod_direction_output(power->reset, 1);
	if (ret)
		goto unwind;
	power->reset_configured = true;

	for (i = UKE_FRONT_VIO; i < UKE_FRONT_RAIL_COUNT; i++) {
		ret = uke_front_rail_on(power, i);
		if (ret)
			goto unwind;
	}

	ret = gpiod_direction_output(power->reset, 0);
	if (ret)
		goto unwind;
	fsleep(1000);
	ret = uke_front_camera_clock_on(power->clock);
	if (ret) {
		if (power->clock->domain_held) {
			power->fault = ret;
			return ret;
		}
		goto unwind;
	}
	fsleep(8000);
	return 0;

unwind:
	cleanup = uke_front_sensor_off(power);
	return cleanup ?: ret;
}

/* Read the configured OEM ID transaction without touching a mode table. */
static int uke_front_sensor_identify(struct i2c_client *client,
				    struct uke_front_sensor_power *power, u16 *id)
{
	u8 address[2] = { 0, 0 };
	u8 identification[2];
	struct i2c_msg messages[] = {
		{ .addr = client->addr, .len = sizeof(address), .buf = address },
		{ .addr = client->addr, .flags = I2C_M_RD, .len = sizeof(identification),
		  .buf = identification },
	};
	const int message_count = ARRAY_SIZE(messages);
	int ret, cleanup;

	if (client->addr != 0x10 || (client->flags & I2C_CLIENT_TEN) ||
	    !i2c_check_functionality(client->adapter, I2C_FUNC_I2C))
		return -ENODEV;

	ret = uke_front_sensor_on(power);
	if (ret)
		return ret;
	ret = i2c_transfer(client->adapter, messages, message_count);
	cleanup = uke_front_sensor_off(power);
	if (cleanup)
		return cleanup;
	if (ret != message_count)
		return ret < 0 ? ret : -EIO;

	*id = get_unaligned_be16(identification);
	return 0;
}

#endif
