#!/usr/bin/bash
# SPDX-License-Identifier: MIT
set -Eeuo pipefail
export LC_ALL=C
assets=$(cd -- "$(dirname -- "$0")" && pwd)
patches=(
    "$assets/0031-uke-keep-partial-cap-status-coherent.patch"
    "$assets/0079-uke-dp-prefer-uncompressed-sdr.patch"
)

case ${1:-} in
    prepare)
        [[ $# == 2 ]]
        (cd "$assets"; sha256sum -c --strict --quiet SHA256SUMS)
        checks=$(mktemp -d)
        trap 'rm -rf -- "$checks"' EXIT
        key=2204a661ea630a5303500085538797e72a3e4eca
        [[ $(gpg --batch --with-colons --show-keys "$assets/parent-key.gpg" | awk -F: '$1=="fpr"{print tolower($10); exit}') == "$key" ]]
        mkdir "$checks/trust"
        rpmkeys --dbpath "$checks/trust" --import "$assets/parent-key.gpg"
        for result in "$assets"/uke-kernel-migration-check-7.3.5-3{5.cap_status,6.dp_sdr_policy}.fc46.aarch64.rpm; do
            rpmkeys --dbpath "$checks/trust" --checksig -v "$result" >"$checks/signatures"
            [[ $(grep -Fc "key fingerprint: $key: OK" "$checks/signatures") == 2 ]]
            ! grep -Eq 'NOKEY|BAD|NOT OK' "$checks/signatures"
        done
        rpm2cpio "$assets/uke-kernel-migration-check-7.3.5-35.cap_status.fc46.aarch64.rpm" |
            cpio -i --quiet --to-stdout './usr/share/uke-kernel-migration-check/cap-status735/qualification.txt' >"$checks/battery"
        rpm2cpio "$assets/uke-kernel-migration-check-7.3.5-36.dp_sdr_policy.fc46.aarch64.rpm" |
            cpio -i --quiet --to-stdout './usr/share/uke-kernel-migration-check/dp-sdr-policy735/qualification.txt' >"$checks/display"
        grep -Fxq 'Exact signed normal 7.3.5-25 source, COPR 11367793.' "$checks/battery"
        grep -Fxq 'Exact cumulative normal 7.3.5-25 source, COPR 11367793.' "$checks/display"
        [[ $(grep -Fxc 'Capped charge status: 37 cases passed; no firmware SET.' "$checks/battery") == 4 ]]
        [[ $(grep -Fxc 'Uke SST policy: 12 RGB, DSC, HDR, mode and compatibility cases passed.' "$checks/display") == 4 ]]
        for i in 0 1; do
            proof=(battery display)
            read -r digest _ < <(sha256sum "${patches[i]}")
            grep -Fxq "$digest  ./${patches[i]##*/}" "$checks/${proof[i]}"
        done
        cd -- "$2"
        sha256sum -c --strict --quiet "$assets/before.sha256"
        git apply --check --whitespace=error "${patches[@]}"
        git apply --whitespace=error "${patches[@]}"
        sha256sum -c --strict --quiet "$assets/after.sha256"
        ;;
    linked)
        [[ $# == 3 ]]
        cd -- "$2"
        battery=drivers/power/supply/qcom_battmgr.ko
        display=drivers/gpu/drm/msm/msm.ko
        for module in "$battery" "$display"; do
            [[ -s "$module" && $(modinfo -F vermagic "$module") == "$3 "* ]]
            readelf -h "$module" | grep -F AArch64
        done
        llvm-nm --defined-only "$battery" | awk '$NF=="qcom_battmgr_bat_get_property"{found=1} END{exit !found}'
        llvm-nm --defined-only "$display" | awk '$NF=="msm_dp_display_atomic_check"{found=1} END{exit !found}'
        sha256sum "$battery" "$display"
        ;;
    restore)
        [[ $# == 2 ]]
        cd -- "$2"
        sha256sum -c --strict --quiet "$assets/after.sha256"
        git apply --reverse --check --whitespace=error "${patches[@]}"
        git apply --reverse --whitespace=error "${patches[@]}"
        sha256sum -c --strict --quiet "$assets/before.sha256"
        ;;
    *)
        exit 2
        ;;
esac
