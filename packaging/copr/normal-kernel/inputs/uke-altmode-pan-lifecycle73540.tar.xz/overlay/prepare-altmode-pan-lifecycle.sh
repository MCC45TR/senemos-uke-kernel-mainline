#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C
umask 077
[[ $# == 2 ]]
assets=$(cd -- "$(dirname -- "$0")" && pwd)
tree=$(realpath -e "$2")
patch=$assets/pmic-glink-altmode-separate-wire-acks.patch
proof=$assets/uke-kernel-migration-check-7.3.5-81.uke_altmode_pan_queue40.fc46.aarch64.rpm
key=2204a661ea630a5303500085538797e72a3e4eca
(cd "$assets"; sha256sum -c --strict --quiet SHA256SUMS)
cd "$tree"
case "$1" in
    prepare)
        sha256sum -c --strict "$assets/before.sha256"
        [[ $(gpg --batch --with-colons --show-keys "$assets/parent-key.gpg" |
            awk -F: '$1=="fpr"{print tolower($10);exit}') == "$key" ]]
        trust=$(mktemp -d --tmpdir="$tree" .uke-altmode-pan.XXXXXXXX)
        trap 'find "$trust" -maxdepth 1 -type f -delete; rmdir -- "$trust"' EXIT
        rpmkeys --dbpath "$trust" --import "$assets/parent-key.gpg"
        rpmkeys --dbpath "$trust" --checksig -v "$proof" >"$trust/signatures"
        [[ $(grep -Fc "key fingerprint: $key: OK" "$trust/signatures") == 2 ]]
        ! grep -Eq 'NOKEY|BAD|NOT OK' "$trust/signatures"
        rpm2cpio "$proof" |
            cpio -i --quiet --to-stdout './usr/share/uke-kernel-migration-check/altmode-pan-lifecycle40/qualification.txt' >"$trust/qualification"
        [[ $(grep -Fxc 'Stalled AUX: 99 wire ACKs, attach/IRQ/detach/reattach in order' "$trust/qualification") == 4 ]]
        [[ $(grep -Fxc 'Acknowledged backlog: reset DRM, apply only the latest confirmed route' "$trust/qualification") == 4 ]]
        [[ $(grep -Fxc 'Genuine wire overflow: reject ambiguous ACKs and disconnect' "$trust/qualification") == 4 ]]
        [[ $(grep -Fxc 'Deadline ACK, genuine timeout and cancellation checks passed.' "$trust/qualification") == 2 ]]
        grep -Fxq 'AArch64 PMIC GLINK Alt Mode object and exact patch inverse verified.' "$trust/qualification"
        grep -Fxq "$(cd "$assets"; sha256sum -- "${patch##*/}")" "$trust/qualification"
        for hash in parent before after; do
            grep -Fxq "$(cat "$assets/$hash.sha256")" "$trust/qualification"
        done
        git apply --check --whitespace=error "$patch"
        git apply --whitespace=error "$patch"
        sha256sum -c --strict "$assets/after.sha256"
        ;;
    restore)
        sha256sum -c --strict "$assets/after.sha256"
        git apply --reverse --check --whitespace=error "$patch"
        git apply --reverse --whitespace=error "$patch"
        sha256sum -c --strict "$assets/before.sha256"
        ;;
    *) exit 2 ;;
esac
