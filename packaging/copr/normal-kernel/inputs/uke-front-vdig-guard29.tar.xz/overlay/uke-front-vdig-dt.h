/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef UKE_FRONT_VDIG_DT_H
#define UKE_FRONT_VDIG_DT_H

#define UKE_FRONT_VDIG_PROVIDER "/soc/rsc@17a00000/drv@2/rpmh-regulator-ldoc3"
#define UKE_FRONT_VDIG_SENSOR UKE_FRONT_BUS "/qcom,cam-sensor1"
#define UKE_FRONT_VDIG_READY "xiaomi,uke-front-vdig-demand-only"

/*
 * Linux only: the disabled front sensor does not need the vendor proxy
 * consumer. Leave the fitted regulator and its active/sleep vote data for
 * the sensor's demand-driven power sequence.
 */
static int UKE_INIT uke_front_vdig_graph(void *fdt)
{
	const fdt32_t modes[] = { cpu_to_fdt32(2), cpu_to_fdt32(4) };
	const fdt32_t loads[] = { cpu_to_fdt32(0), cpu_to_fdt32(30000) };
	int controller, rail, sensor, ret;
	unsigned int phandle;

	if (fdt_node_check_compatible(fdt, 0, "xiaomi,uke") ||
	    fdt_node_check_compatible(fdt, 0, "qcom,sm7675"))
		return 0;

	controller = fdt_path_offset(fdt, UKE_FRONT_VDIG_PROVIDER);
	sensor = fdt_path_offset(fdt, UKE_FRONT_VDIG_SENSOR);
	if (controller < 0 || sensor < 0 ||
	    fdt_node_check_compatible(fdt, controller, "qcom,rpmh-vrm-regulator") ||
	    fdt_node_check_compatible(fdt, sensor, "qcom,cam-i2c-sensor") ||
	    !uke_front_disabled(fdt, sensor) ||
	    !uke_front_bytes(fdt, controller, "qcom,resource-name", "ldoc3",
			     sizeof("ldoc3")) ||
	    !uke_front_bytes(fdt, controller, "qcom,regulator-type", "pmic5-ldo",
			     sizeof("pmic5-ldo")) ||
	    !uke_front_bytes(fdt, controller, "qcom,supported-modes", modes, sizeof(modes)) ||
	    !uke_front_bytes(fdt, controller, "qcom,mode-threshold-currents", loads, sizeof(loads)) ||
	    fdt_getprop(fdt, controller, "qcom,send-defaults", NULL) ||
	    fdt_getprop(fdt, controller, UKE_FRONT_VDIG_READY, NULL))
		return 0;

	rail = fdt_subnode_offset(fdt, controller, "regulator-pm_v6c-l3");
	if (rail < 0 || rail != fdt_first_subnode(fdt, controller) ||
	    fdt_next_subnode(fdt, rail) != -FDT_ERR_NOTFOUND)
		return 0;

	phandle = fdt_get_phandle(fdt, rail);
	if (!phandle || !uke_front_u32(fdt, sensor, "cam_vdig-supply", phandle) ||
	    !uke_front_u32(fdt, controller, "proxy-supply", phandle) ||
	    !uke_front_bytes(fdt, rail, "regulator-name", "pm_v6c_l3",
			     sizeof("pm_v6c_l3")) ||
	    !uke_front_u32(fdt, rail, "regulator-min-microvolt", 1200000) ||
	    !uke_front_u32(fdt, rail, "regulator-max-microvolt", 1250000) ||
	    !uke_front_u32(fdt, rail, "qcom,set", 3) ||
	    !uke_front_u32(fdt, rail, "qcom,init-voltage", 1200000) ||
	    !uke_front_u32(fdt, rail, "qcom,init-mode", 4) ||
	    fdt_getprop(fdt, rail, "qcom,init-enable", NULL) ||
	    fdt_getprop(fdt, rail, "regulator-initial-mode", NULL) ||
	    !uke_front_u32(fdt, rail, "qcom,proxy-consumer-current", 200000) ||
	    !uke_front_bytes(fdt, rail, "qcom,proxy-consumer-enable", "", 0) ||
	    fdt_getprop(fdt, rail, "qcom,proxy-consumer-voltage", NULL) ||
	    fdt_getprop(fdt, rail, "regulator-boot-on", NULL) ||
	    fdt_getprop(fdt, rail, "regulator-always-on", NULL))
		return 0;

	ret = fdt_delprop(fdt, rail, "qcom,proxy-consumer-enable");
	if (ret)
		return ret;
	ret = fdt_delprop(fdt, rail, "qcom,proxy-consumer-current");
	if (ret)
		return ret;
	ret = fdt_delprop(fdt, controller, "proxy-supply");
	if (ret)
		return ret;

	return fdt_setprop(fdt, controller, UKE_FRONT_VDIG_READY, NULL, 0);
}

#endif
