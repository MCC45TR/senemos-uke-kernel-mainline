#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C
[[ $# == 2 ]]
assets=$(cd -- "$(dirname -- "$0")" && pwd)
tree=$(realpath -e -- "$2")
proof="$assets/uke-kernel-migration-check-7.3.5-50.uke_front_vdig_demand29.fc46.aarch64.rpm"
key=2204a661ea630a5303500085538797e72a3e4eca
header=arch/arm64/kernel/uke-front-vdig-dt.h
patches=("$assets/0001-regulator-uke-guard-front-vdig-ldoc3.patch" \
         "$assets/0002-arm64-gate-front-vdig-after-native-eeprom.patch")
cd "$tree"
case $1 in
    prepare)
        (cd "$assets"; sha256sum -c --strict --quiet SHA256SUMS)
        sha256sum -c --strict "$assets/rpmh-before.sha256" "$assets/abl-before.sha256"
        [[ ! -e $header && ! -L $header ]]
        [[ $(gpg --batch --with-colons --show-keys "$assets/parent-key.gpg" | awk -F: '$1=="fpr"{print tolower($10);exit}') == "$key" ]]
        trust=$(mktemp -d --tmpdir="$tree" .front-vdig.XXXXXXXX)
        trap 'find "$trust" -maxdepth 1 -type f -delete; rmdir -- "$trust"' EXIT
        rpmkeys --dbpath "$trust" --import "$assets/parent-key.gpg"
        rpmkeys --dbpath "$trust" --checksig -v "$proof" > "$trust/signatures"
        [[ $(grep -Fc "key fingerprint: $key: OK" "$trust/signatures") == 2 ]]
        ! grep -Eq 'NOKEY|NOT OK|BAD' "$trust/signatures"
        rpm2cpio "$proof" | cpio -i --quiet --to-stdout \
            './usr/share/uke-kernel-migration-check/front-vdig-demand29/qualification.txt' > "$trust/receipt"
        for input in "${patches[@]##*/}" "${header##*/}"; do
            grep -Fxq "$(cd "$assets"; sha256sum "$input")" "$trust/receipt"
        done
        grep -Fxq 'Native AArch64 RPMh provider and selected FDT transform compiled; inverse round trip verified.' "$trust/receipt"
        git apply --check --whitespace=error "${patches[@]}"
        git apply --whitespace=error "${patches[@]}"
        install -m644 "$assets/${header##*/}" "$header"
        sha256sum -c --strict "$assets/rpmh-after.sha256" "$assets/abl-after.sha256"
        ;;
    restore)
        cmp "$assets/${header##*/}" "$header"
        sha256sum -c --strict "$assets/rpmh-after.sha256" "$assets/abl-after.sha256"
        git apply --reverse --check --whitespace=error "${patches[@]}"
        git apply --reverse --whitespace=error "${patches[@]}"
        unlink "$header"
        sha256sum -c --strict "$assets/rpmh-before.sha256" "$assets/abl-before.sha256"
        ;;
    *) exit 2 ;;
esac
