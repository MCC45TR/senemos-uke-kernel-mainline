#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

typedef uint64_t u64;
#define READ_ONCE(x) (x)
#define DIV_ROUND_UP_ULL(v, d) (((v) + (d) - 1) / (d))
#define max(a, b) ((a) > (b) ? (a) : (b))
#define min(a, b) ((a) < (b) ? (a) : (b))
#define min3(a, b, c) min(min((a), (b)), (c))
#define round_down(v, divisor) ((v) / (divisor) * (divisor))
#define BIT(n) (1U << (n))
#define DRM_OUTPUT_COLOR_FORMAT_YCBCR422 2
#define DRM_MODE_FLAG_INTERLACE (1u << 4)
#define DP_DOWNSTREAMPORT_PRESENT 5
#define DP_SDP_VSC 7
#define DP_COLORIMETRY_DEFAULT 0
#define DP_COLORIMETRY_BT2020_RGB 6
#define DP_DYNAMIC_RANGE_VESA 0
#define DP_DYNAMIC_RANGE_CTA 1
#define DP_CONTENT_TYPE_NOT_DEFINED 0

enum drm_colorspace { DRM_MODE_COLORIMETRY_DEFAULT, DRM_MODE_COLORIMETRY_BT2020_RGB, OTHER_COLORSPACE };
enum dp_pixelformat { DP_PIXELFORMAT_RGB, DP_PIXELFORMAT_YUV444, DP_PIXELFORMAT_YUV422, DP_PIXELFORMAT_YUV420 };
struct drm_dp_vsc_sdp {
    unsigned int sdp_type, revision, length, bpc, dynamic_range, content_type, colorimetry;
    enum dp_pixelformat pixelformat;
};
struct dp_sdp { struct drm_dp_vsc_sdp value; };
static int drm_dp_vsc_sdp_pack(const struct drm_dp_vsc_sdp *vsc, struct dp_sdp *packet)
{
    packet->value = *vsc;
    return 36;
}

struct drm_display_info { int color_formats; unsigned int bpc, max_tmds_clock; bool is_hdmi; };
struct drm_display_mode { unsigned int clock, hdisplay, flags; };
struct msm_dp_link_info { unsigned int rate, num_lanes; };
struct msm_dp_link { struct msm_dp_link_info link_caps; bool vsc_sdp_supported; };
struct msm_dp_panel { bool dsc_force; unsigned char dpcd[16]; };
struct drm_bridge { bool ycbcr_420_allowed; };
struct platform_device { struct { const char *of_node; } dev; };
struct msm_dp { bool is_edp, mst_active; struct drm_bridge *bridge; struct platform_device *pdev; };
struct msm_dp_display_private {
    struct msm_dp msm_dp_display;
    struct msm_dp_link *link;
    struct msm_dp_panel *panel;
    bool wide_bus_supported;
};
static bool drm_dp_is_branch(const unsigned char *dpcd)
{
    return dpcd[DP_DOWNSTREAMPORT_PRESENT] & 1;
}
static bool of_device_is_compatible(const char *node, const char *name)
{
    return !strcmp(node, name);
}
#include "native-sst.inc"

int main(void)
{
    struct drm_display_info info = { BIT(DRM_OUTPUT_COLOR_FORMAT_YCBCR422), 8, 600000, true };
    struct drm_display_mode mode = { 594000, 3840, 0 };
    struct msm_dp_panel panel = {0};
    struct msm_dp_link link = { { 810000, 2 }, true };
    struct drm_bridge bridge = { true };
    struct platform_device device = { { "qcom,sm7675-dp" } };
    struct msm_dp_display_private dp = { { false, false, &bridge, &device }, &link, &panel, true };
    struct dp_sdp sdp = {0};

    assert(msm_dp_sdr_422_fallback(&dp, &info, &mode));
    assert(msm_dp_utils_select_bpp(8, 8, 594000, 810000, 2, false, false, 600000) == 18);
    assert(msm_dp_utils_select_bpp(8, 8, 533250, 810000, 2, false, false, 600000) == 24);
    assert(msm_dp_utils_link_fits(594000, 16, 810000, 2, false));
    assert(!msm_dp_utils_link_fits(594000, 16, 540000, 2, false));
    assert(!msm_dp_utils_link_fits(594000, 24, 810000, 2, false));
    assert(msm_dp_utils_link_fits(594000, 24, 540000, 2, true));

    link.link_caps.rate = 540000;
    assert(!msm_dp_sdr_422_fallback(&dp, &info, &mode));
    link.link_caps.rate = 810000;
    link.link_caps.num_lanes = 1;
    assert(!msm_dp_sdr_422_fallback(&dp, &info, &mode));
    link.link_caps.num_lanes = 2;
    link.vsc_sdp_supported = false;
    assert(!msm_dp_sdr_422_fallback(&dp, &info, &mode));
    link.vsc_sdp_supported = true;
    info.color_formats = 0;
    assert(!msm_dp_sdr_422_fallback(&dp, &info, &mode));
    info.color_formats = BIT(DRM_OUTPUT_COLOR_FORMAT_YCBCR422);
    info.bpc = 6;
    assert(!msm_dp_sdr_422_fallback(&dp, &info, &mode));
    info.bpc = 8;
    info.max_tmds_clock = 300000;
    assert(!msm_dp_sdr_422_fallback(&dp, &info, &mode));
    info.max_tmds_clock = 600000;
    panel.dpcd[DP_DOWNSTREAMPORT_PRESENT] = 1;
    assert(!msm_dp_sdr_422_fallback(&dp, &info, &mode));
    panel.dpcd[DP_DOWNSTREAMPORT_PRESENT] = 0;
    panel.dsc_force = true;
    assert(!msm_dp_sdr_422_fallback(&dp, &info, &mode));
    panel.dsc_force = false;
    dp.msm_dp_display.mst_active = true;
    assert(!msm_dp_sdr_422_fallback(&dp, &info, &mode));
    dp.msm_dp_display.mst_active = false;
    dp.msm_dp_display.is_edp = true;
    assert(!msm_dp_sdr_422_fallback(&dp, &info, &mode));
    dp.msm_dp_display.is_edp = false;
    dp.wide_bus_supported = false;
    assert(!msm_dp_sdr_422_fallback(&dp, &info, &mode));
    dp.wide_bus_supported = true;
    mode.flags = DRM_MODE_FLAG_INTERLACE;
    assert(!msm_dp_sdr_422_fallback(&dp, &info, &mode));
    mode.flags = 0;
    mode.hdisplay = 3839;
    assert(!msm_dp_sdr_422_fallback(&dp, &info, &mode));
    mode.hdisplay = 3840;
    assert(msm_dp_sdr_422_fallback(&dp, &info, &mode));

    assert(msm_dp_utils_pack_vsc_sdp(&sdp, DRM_MODE_COLORIMETRY_DEFAULT, 8, DP_PIXELFORMAT_YUV422) == 0);
    assert(sdp.value.pixelformat == DP_PIXELFORMAT_YUV422 && sdp.value.bpc == 8);
    assert(sdp.value.dynamic_range == DP_DYNAMIC_RANGE_CTA && sdp.value.colorimetry == DP_COLORIMETRY_DEFAULT);
    assert(msm_dp_utils_pack_vsc_sdp(&sdp, DRM_MODE_COLORIMETRY_BT2020_RGB, 8, DP_PIXELFORMAT_YUV422) == -EINVAL);
    assert(msm_dp_utils_pack_vsc_sdp(&sdp, DRM_MODE_COLORIMETRY_BT2020_RGB, 10, DP_PIXELFORMAT_RGB) == 0);
    assert(sdp.value.dynamic_range == DP_DYNAMIC_RANGE_VESA && sdp.value.colorimetry == DP_COLORIMETRY_BT2020_RGB);
    assert(msm_dp_utils_pack_vsc_sdp(&sdp, DRM_MODE_COLORIMETRY_DEFAULT, 8, DP_PIXELFORMAT_YUV420) == 0);
    assert(sdp.value.pixelformat == DP_PIXELFORMAT_YUV420 && sdp.value.dynamic_range == DP_DYNAMIC_RANGE_CTA);
    puts("Passed native SST fallback coverage and RGB/YCbCr signaling checks.");
    return 0;
}
