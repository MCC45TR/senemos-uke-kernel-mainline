#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C
[[ $# == 2 && $(uname -m) == aarch64 ]]
inputs=$(realpath -e "$1")
result=$(realpath -m "$2")
mkdir replay
cd replay
parent=senemos-uke-linux-kernel-mainline-7.3.5-42.fc46.src.rpm
base=https://download.copr.fedorainfracloud.org/results/mcc45tr/uke-linux-unstable/fedora-rawhide-aarch64/11371502-senemos-uke-linux-kernel-mainline
key=2204a661ea630a5303500085538797e72a3e4eca
curl -qfsSL --proto '=https' --retry 2 --max-time 205 --max-filesize 190000000 "$base/$parent" -o "$parent"
sha256sum -c --strict "$inputs/parent.sha256"
[[ $(gpg --batch --with-colons --show-keys "$inputs/parent-key.gpg" | awk -F: '$1=="fpr"{print tolower($10);exit}') == "$key" ]]
mkdir trust out
rpmkeys --dbpath "$PWD/trust" --import "$inputs/parent-key.gpg"
rpmkeys --dbpath "$PWD/trust" --checksig -v "$parent" > parent-signatures.txt
[[ $(grep -Fc "key fingerprint: $key: OK" parent-signatures.txt) == 2 ]]
! grep -Eq 'NOKEY|BAD|NOT OK' parent-signatures.txt
rpm2cpio "$parent" | cpio -id --quiet --no-absolute-filenames './linux-7.3.5.tar.xz' './senemos-native-profile-7.3.5.tar.xz' './senemos-uke-adaptation-7.3.5.tar.xz' './uke-native-abm734.tar.xz' './uke-dp-sst422-73541.tar.xz'
printf '%s  %s\n' 048eddcf2bbed8f44e27b6e415835e8bc9204b0b898e0c5a71dd393afa00ffa8 uke-dp-sst422-73541.tar.xz | sha256sum -c --strict
tar -xJf linux-7.3.5.tar.xz
tar -xJf senemos-native-profile-7.3.5.tar.xz native-profile/patches/display native-profile/src/display native-profile/patches/boot/0009-uke-displayport-dma-scope.patch native-profile/audio-profile
tar -xJf senemos-uke-adaptation-7.3.5.tar.xz senemos-adaptation
tar -xJf uke-native-abm734.tar.xz abm734/src/display/0077-o82-live-abm734.patch abm734/src/display/abm734-post.sha256
profile=$PWD/native-profile
out=$PWD/out
cd linux-7.3.5
git init -q
mv ../senemos-adaptation .
while IFS= read -r name; do
    git apply "senemos-adaptation/patches/$name"
    printf '%s\n' "$name" >> senemos-applied-patches.txt
done < senemos-adaptation/patches/series
git apply "$profile/patches/display/0065-msm-framebuffer-pin-state.patch"
bash "$profile/src/display/prepare-source.sh" "$PWD"
for name in 0066-msm-dpu-reservation-ownership.patch 0067-msm-kms-lifecycle-unwind.patch \
            0068-msm-scanout-retirement.patch \
            0005-native-dpu-dsc-active-width.patch; do
    git apply "$profile/patches/display/$name"
done
if [[ $(cat "$profile/audio-profile") =~ ^(hdmi-only|speakers|microphones)$ ]]; then
    git apply --include="drivers/gpu/drm/msm/**" "$profile/patches/boot/0009-uke-displayport-dma-scope.patch"
    if [[ $(cat "$profile/audio-profile") =~ ^(speakers|microphones)$ ]]; then
        git apply "$profile/patches/display/0057-uke-displayport-eld-notification.patch"
    fi
fi
for name in 0069-o82-requested-vrr-floor.patch 0070-o82-adaptive-backlight.patch \
            0071-o82-panel-variants.patch; do
    git apply "$profile/patches/display/$name"
done
bash "$profile/src/display/prepare-o82-regdma.sh" "$PWD"
git apply "$profile/src/display/0075-o82-avr-retime-rollback.patch"
git apply --include=drivers/gpu/drm/msm/msm_atomic.c \
    --include=drivers/gpu/drm/msm/dsi/dsi.h ../abm734/src/display/0077-o82-live-abm734.patch
grep -F '  drivers/gpu/drm/msm/msm_atomic.c' ../abm734/src/display/abm734-post.sha256 | sha256sum -c --strict

families=(
    uke-normal-display735 uke-normal-display-cap-status735
    uke-juo-display73530 uke-usb-dp-stability73531 uke-display-fault73531
    uke-normal-dp-hbr3-trial73526 uke-hbr3-mainlink-fallback73526
    uke-dpu-atomic-total73533 uke-dp-attach-ownership73533
    uke-mst-rate-governor73533 uke-dp-sdr-dsc-fallback73539
)
members=()
for family in "${families[@]}"; do members+=("./$family.tar.xz"); done
(cd ..; rpm2cpio "$parent" | cpio -id --quiet --no-absolute-filenames "${members[@]}")
dp=drivers/gpu/drm/msm/dp
msm=drivers/gpu/drm/msm
dpu="$msm/disp/dpu1"
include=(--include="$dp/*" --include="$msm/msm_drv.h" --include=include/linux/phy/uke-dp.h)
apply_from() {
    local archive=$1 member=$2
    shift 2
    tar -xJOf "../$archive.tar.xz" "$member" | git apply --whitespace=error "$@"
}
git apply "$profile/src/display/0001-uke-mst-stream-depth733.patch"
apply_from uke-normal-display735 ./0077-uke-dp-sdr-420-bandwidth-fallback.patch
apply_from uke-normal-display-cap-status735 overlay/0079-uke-dp-prefer-uncompressed-sdr.patch "${include[@]}"
for candidate in 0110-uke-dp-trial-profile.patch 0110-uke-dp-guard-cliffs-hbr3.patch; do
    apply_from uke-normal-dp-hbr3-trial73526 "overlay/$candidate" "${include[@]}"
done
apply_from uke-hbr3-mainlink-fallback73526 overlay/hbr3-mainlink-fallback.patch "${include[@]}"
apply_from uke-juo-display73530 overlay/sst/0001-msm-dp-use-420-if-rgb-only-fits-six-bpc.patch "${include[@]}"
apply_from uke-usb-dp-stability73531 overlay/mst-keep-aux-after-last-stream.patch
apply_from uke-usb-dp-stability73531 overlay/uke-dp-propagate-training-failure.patch
apply_from uke-display-fault73531 overlay/dpu/dpu-use-incoming-planes-for-perf.patch
apply_from uke-dpu-atomic-total73533 overlay/dpu-check-atomic-total-bandwidth.patch
apply_from uke-dp-attach-ownership73533 overlay/dp-attach-ownership.patch

governor=../uke-mst-rate-governor73533.tar.xz
tar -xJOf "$governor" overlay/governor-before.sha256 | sha256sum -c --strict
apply_from uke-mst-rate-governor73533 overlay/msm-dp-mst-preserve-exact-rate-governor-slot.patch
tar -xJOf "$governor" overlay/governor-after.sha256 | sha256sum -c --strict

archive=../uke-dp-sdr-dsc-fallback73539.tar.xz
tar -xJOf "$archive" overlay/sdr-before.sha256 | sha256sum -c --strict
tar -xJOf "$archive" overlay/uke-dp-retry-sdr-without-dsc.patch | git apply --whitespace=error
tar -xJOf "$archive" overlay/sdr-after.sha256 | sha256sum -c --strict
sha256sum -c --strict "$inputs/dp-preimage.sha256"
patch=$inputs/0001-drm-msm-dp-support-native-sdr-ycbcr422.patch
git apply --check --whitespace=error "$patch"
git apply --whitespace=error "$patch"
teardown="$inputs/0002-drm-msm-dp-reset-only-with-link-clocks.patch"
git apply --check --whitespace=error "$teardown"
git apply --whitespace=error "$teardown"
stream_teardown="$inputs/0003-drm-msm-dp-quiesce-stream-before-gating-pixel-clock.patch"
git apply --check --whitespace=error "$stream_teardown"
git apply --whitespace=error "$stream_teardown"
sha256sum -c --strict "$inputs/dp-postimage.sha256"
sha256sum -c --strict "$inputs/idle-aux-before.sha256"
idle_aux="$inputs/0001-drm-msm-dp-restore-idle-sst-aux-on-cliffs.patch"
git apply --check --whitespace=error "$idle_aux"
git apply --whitespace=error "$idle_aux"
idle_maintenance="$inputs/0002-drm-msm-dp-guard-idle-link-maintenance.patch"
git apply --check --whitespace=error "$idle_maintenance"
git apply --whitespace=error "$idle_maintenance"
sha256sum -c --strict "$inputs/idle-aux-after.sha256"
for compiler in gcc clang; do
    bash "$inputs/check-fallback.sh" "$PWD" "$inputs/test-fallback.c" "$out" "$compiler"
    bash "$inputs/check-idle-aux.sh" "$PWD" "$inputs/test-idle-aux.c" "$out" "$compiler"
done | tee "$out/tests.txt"
[[ $(grep -c '^Passed native SST fallback coverage' "$out/tests.txt") == 4 ]]
[[ $(grep -c '^Passed active, failed-training and repeated DisplayPort teardown checks.' "$out/tests.txt") == 4 ]]
[[ $(grep -Fxc 'Passed stream-packet cleanup before pixel clock gating.' "$out/tests.txt") == 4 ]]
[[ $(grep -Fxc 'Actual SST and MST idle AUX, disconnect ownership, and failure unwind passed.' "$out/tests.txt") == 4 ]]
[[ $(grep -Fxc 'Idle native HPD still admits AUX while refusing unpowered mainlink training.' "$out/tests.txt") == 4 ]]
cp "$inputs/accepted.config" "$out/.config"
scripts/config --file "$out/.config" --set-str INITRAMFS_SOURCE '' --set-str MODULE_SIG_KEY certs/signing_key.pem \
    --set-str SYSTEM_TRUSTED_KEYS '' --set-str SYSTEM_REVOCATION_KEYS ''
make -s O="$out" ARCH=arm64 LLVM=1 LLVM_IAS=1 -j4 olddefconfig prepare modules_prepare
objects=("$dp/dp_display.o" "$dp/dp_drm.o" "$dp/dp_ctrl.o" "$dp/dp_panel.o" "$dp/dp_utils.o" "$dpu/dpu_encoder.o")
make -s O="$out" ARCH=arm64 LLVM=1 LLVM_IAS=1 -j4 "${objects[@]}"
for object in "${objects[@]}"; do llvm-readelf -h "$out/$object" | grep -F AArch64; done
llvm-nm "$out/$dp/dp_display.o" | grep -E ' T msm_dp_stream_chroma_format$'
git apply --reverse --check --whitespace=error "$idle_maintenance"
git apply --reverse --whitespace=error "$idle_maintenance"
git apply --reverse --check --whitespace=error "$idle_aux"
git apply --reverse --whitespace=error "$idle_aux"
sha256sum -c --strict "$inputs/idle-aux-before.sha256"
git apply --reverse --check --whitespace=error "$stream_teardown"
git apply --reverse --whitespace=error "$stream_teardown"
git apply --reverse --check --whitespace=error "$teardown"
git apply --reverse --whitespace=error "$teardown"
git apply --reverse --check --whitespace=error "$patch"
git apply --reverse --whitespace=error "$patch"
sha256sum -c --strict "$inputs/dp-preimage.sha256"
{
    cat "$inputs/parent.sha256" "$inputs/dp-preimage.sha256" "$inputs/dp-postimage.sha256" "$inputs/idle-aux-after.sha256" "$out/tests.txt"
    (cd "$out"; sha256sum "${objects[@]}")
    printf '%s\n' 'Signed 7.3.5-42 source projection, patch inverse, and six AArch64 DRM objects verified.'
} > "$result"
