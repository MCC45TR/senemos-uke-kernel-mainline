#!/usr/bin/bash
set -Eeuo pipefail
source=$1
fixture=$2
output=$3
compiler=$4
dp=$source/drivers/gpu/drm/msm/dp
mkdir -p "$output"
{
    sed -n '/^bool msm_dp_utils_link_fits(/,/^}/p; /^bool msm_dp_utils_tmds_fits(/,/^}/p; /^int msm_dp_utils_select_bpp(/,/^}/p; /^int msm_dp_utils_pack_vsc_sdp(/,/^}/p' "$dp/dp_utils.c"
    sed -n '/^static bool msm_dp_sdr_422_fallback(/,/^}/p' "$dp/dp_display.c"
} > "$output/native-sst.inc"
[[ $(grep -c '^}' "$output/native-sst.inc") == 5 ]]
sed -n '/^static int msm_dp_ctrl_deinitialize_mainlink(/,/^}/p; /^void msm_dp_ctrl_off_pixel_clk(/,/^}/p; /^int msm_dp_ctrl_off_link(/,/^}/p' "$dp/dp_ctrl.c" > "$output/native-teardown.inc"
[[ $(grep -c '^}' "$output/native-teardown.inc") == 3 ]]
for opts in plain sanitized; do
    flags=()
    if [[ $opts == sanitized ]]; then flags=(-fsanitize=address,undefined -fno-omit-frame-pointer); fi
    test_bin="$output/test-$compiler-$opts"
    "$compiler" -std=gnu11 -Wall -Wextra -Werror -I"$output" "${flags[@]}" "$fixture" -o "$test_bin"
    ASAN_OPTIONS=detect_leaks=0 "$test_bin"
    "$compiler" -std=gnu11 -Wall -Wextra -Werror -I"$output" "${flags[@]}" "${fixture%/*}/test-teardown.c" -o "$test_bin-teardown"
    ASAN_OPTIONS=detect_leaks=0 "$test_bin-teardown"
done
