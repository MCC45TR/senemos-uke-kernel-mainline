#include <assert.h>
#include <errno.h>
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>

struct device { bool of_node; };
struct platform_device { struct device dev; };
struct msm_dp_link { unsigned int sink_count, link_caps, sink_request, test_response; };
struct msm_dp_ctrl { bool present; };
struct msm_dp_ctrl_private {
    struct msm_dp_ctrl msm_dp_ctrl;
    struct msm_dp_link *link;
    bool link_clks_on;
    void *drm_dev;
};
struct msm_dp_panel { bool video_test; unsigned int dpcd, downstream_ports; };
struct msm_dp {
    struct platform_device *pdev;
    void *connector;
    unsigned int active_stream_cnt;
    bool is_edp, mst_active, link_ready;
};
struct msm_dp_display_private {
    struct msm_dp msm_dp_display;
    struct msm_dp_link *link;
    struct msm_dp_panel *panel;
    bool plugged_lock, plugged, phy_initialized, stream_pm_active, stream_link_attempted;
    bool sink_mst_capable, link_failed, link_status_notified, dsc_policy_changed;
    void *ctrl, *aux, *drm_dev;
};
#define container_of(ptr, type, member) ((type *)((char *)(ptr) - offsetof(type, member)))
#define READ_ONCE(x) (x)
#define WRITE_ONCE(x, value) ((x) = (value))
#define drm_dbg_dp(drm, ...) ((void)(drm))
#define drm_err(drm, ...) ((void)(drm))
#define of_device_is_compatible(node, value) ((node) && !strcmp(value, "qcom,sm7675-dp"))
#define lockdep_assert_held(ptr) assert(*(ptr))
enum { connector_status_disconnected };

static bool *acquire(bool *held) { assert(!*held); *held = true; return held; }
static void release(bool **held) { assert(**held); **held = false; }
#define guard(class) bool *lock __attribute__((cleanup(release))) = acquire
#define scoped_guard(class, ptr) \
    for (bool *lock __attribute__((cleanup(release))) = acquire(ptr), *loop = lock; loop; loop = NULL)

static char actions[64];
static unsigned int action_len;
static int off_error, exit_error, init_error;
static void step(char c) { assert(action_len < sizeof(actions) - 1); actions[action_len++] = c; actions[action_len] = 0; }
static void reset_actions(void) { action_len = 0; actions[0] = 0; }
static int msm_dp_ctrl_phy_exit(void *ctrl) { assert(ctrl); step('X'); return exit_error; }
static int msm_dp_ctrl_phy_init(void *ctrl) { assert(ctrl); step('I'); return init_error; }
static void msm_dp_ctrl_enable_irq(void *ctrl) { assert(ctrl); step('N'); }
static void msm_dp_aux_init(void *aux) { assert(aux); step('A'); }
static void msm_dp_aux_enable_xfers(void *aux, bool enable) { assert(aux); step(enable ? 'E' : 'D'); }
static void msm_dp_display_host_phy_exit(struct msm_dp_display_private *dp)
{
    if (dp->phy_initialized) {
        msm_dp_ctrl_phy_exit(dp->ctrl);
        dp->phy_initialized = false;
    }
}
static int msm_dp_ctrl_off_link(void *ctrl, void *panel, bool quiesce)
{
    assert(ctrl && panel); step(quiesce ? 'Q' : 'L'); return off_error;
}
static void msm_dp_link_psm_config(void *link, void *caps, bool sleep)
{ assert(link && caps && sleep); step('Z'); }
static void msm_dp_ctrl_reinit_phy(void *ctrl) { assert(ctrl); step('T'); }
static void pm_runtime_put_sync(void *dev) { assert(dev); step('R'); }
static void drm_edid_connector_update(void *connector, void *edid)
{ assert(connector && !edid); step('B'); }
static void drm_dp_set_subconnector_property(void *conn, int status, unsigned int dpcd, unsigned int ports)
{ assert(conn && status == connector_status_disconnected); (void)dpcd; (void)ports; step('C'); }
static void msm_dp_mst_display_set_mgr_state(struct msm_dp *dp, bool active)
{ assert(dp && !active); step('M'); }
static void msm_dp_display_handle_plugged_change(struct msm_dp *dp, bool plugged)
{ assert(dp && !plugged); step('H'); }
enum { DP_TEST_LINK_PHY_TEST_PATTERN = 1, DP_LINK_STATUS_UPDATED = 2,
       DP_TEST_LINK_TRAINING = 4, DP_TEST_NAK = 2 };
typedef uint32_t u32;
#define DRM_ERROR(...) ((void)0)
static int msm_dp_ctrl_process_phy_test_request(struct msm_dp_ctrl_private *c, struct msm_dp_panel *panel)
{ assert(c && panel); step('P'); c->link_clks_on = true; return 0; }
static int msm_dp_ctrl_link_maintenance(struct msm_dp_ctrl_private *c, struct msm_dp_panel *panel)
{ assert(c->link_clks_on && panel); step('K'); return 0; }
static void msm_dp_link_send_test_response(struct msm_dp_link *link)
{ assert(link); step(link->test_response == DP_TEST_NAK ? 'F' : 'Y'); }
#include "native-idle-aux.inc"

int main(void)
{
    struct platform_device pdev = { .dev.of_node = true };
    struct msm_dp_link link = { .sink_count = 1 };
    struct msm_dp_panel panel = {0};
    struct msm_dp_display_private dp = {
        .msm_dp_display = { .pdev = &pdev, .connector = &link, .link_ready = true },
        .link = &link, .panel = &panel, .ctrl = &dp, .aux = &link, .drm_dev = &dp,
        .plugged = true, .phy_initialized = true, .stream_pm_active = true, .stream_link_attempted = true,
    };

    msm_dp_display_unprepare(&dp.msm_dp_display);
    assert(!strcmp(actions, "QXINAER"));
    assert(dp.phy_initialized && !dp.stream_pm_active && !dp.stream_link_attempted && !dp.msm_dp_display.link_ready);

    reset_actions();
    assert(!msm_dp_hpd_unplug_handle(&dp));
    assert(!strcmp(actions, "DBXCHR"));
    assert(!dp.plugged && !dp.phy_initialized && !dp.plugged_lock);

    reset_actions();
    dp.plugged = true;
    dp.phy_initialized = true;
    dp.stream_pm_active = dp.stream_link_attempted = true;
    dp.msm_dp_display.mst_active = true;
    msm_dp_display_unprepare(&dp.msm_dp_display);
    assert(!strcmp(actions, "QXINAER"));

    reset_actions();
    dp.stream_pm_active = dp.stream_link_attempted = true;
    assert(!msm_dp_hpd_unplug_handle(&dp));
    assert(!strcmp(actions, "DBCMHR") && dp.phy_initialized);
    reset_actions();
    msm_dp_display_unprepare(&dp.msm_dp_display);
    assert(!strcmp(actions, "LXR") && !dp.phy_initialized);

    reset_actions();
    dp.plugged = dp.phy_initialized = dp.stream_pm_active = dp.stream_link_attempted = true;
    pdev.dev.of_node = false;
    msm_dp_display_unprepare(&dp.msm_dp_display);
    assert(!strcmp(actions, "LXR"));

    reset_actions();
    pdev.dev.of_node = true;
    dp.plugged = dp.phy_initialized = dp.stream_pm_active = dp.stream_link_attempted = true;
    init_error = -5;
    msm_dp_display_unprepare(&dp.msm_dp_display);
    assert(!strcmp(actions, "QXIR") && !dp.phy_initialized && !dp.stream_pm_active);
    init_error = 0;

    reset_actions();
    dp.plugged = dp.phy_initialized = dp.stream_pm_active = dp.stream_link_attempted = true;
    off_error = -5;
    msm_dp_display_unprepare(&dp.msm_dp_display);
    assert(!strcmp(actions, "QR") && !dp.stream_pm_active);
    reset_actions();
    struct msm_dp_ctrl_private ctrl = { .link = &link, .drm_dev = &dp };
    link.sink_request = DP_LINK_STATUS_UPDATED;
    assert(!msm_dp_ctrl_handle_sink_request(&ctrl.msm_dp_ctrl, &panel));
    assert(!strcmp(actions, ""));
    link.sink_request = DP_TEST_LINK_TRAINING;
    assert(!msm_dp_ctrl_handle_sink_request(&ctrl.msm_dp_ctrl, &panel));
    assert(link.test_response == DP_TEST_NAK && !strcmp(actions, "F"));

    reset_actions();
    link.sink_request = DP_TEST_LINK_PHY_TEST_PATTERN;
    assert(!msm_dp_ctrl_handle_sink_request(&ctrl.msm_dp_ctrl, &panel));
    assert(ctrl.link_clks_on && !strcmp(actions, "P"));
    link.sink_request = DP_LINK_STATUS_UPDATED;
    assert(!msm_dp_ctrl_handle_sink_request(&ctrl.msm_dp_ctrl, &panel));
    link.sink_request = DP_TEST_LINK_TRAINING;
    link.test_response = 0;
    assert(!msm_dp_ctrl_handle_sink_request(&ctrl.msm_dp_ctrl, &panel));
    assert(!strcmp(actions, "PKYK"));

    puts("Actual SST and MST idle AUX, disconnect ownership, and failure unwind passed.");
    puts("Idle native HPD still admits AUX while refusing unpowered mainlink training.");
    return 0;
}
