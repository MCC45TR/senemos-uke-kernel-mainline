set -Eeuo pipefail
source=$1
test_src=$2
out=$3
compiler=$4
mkdir -p "$out"
sed -n '/^static bool msm_dp_display_uses_idle_aux(/,/^}/p; /^static int msm_dp_display_restore_idle_aux(/,/^}/p; /^static int msm_dp_hpd_unplug_handle(/,/^}/p; /^void msm_dp_display_unprepare(/,/^}/p' "$source/drivers/gpu/drm/msm/dp/dp_display.c" > "$out/native-idle-aux.inc"
sed -n '/^int msm_dp_ctrl_handle_sink_request(/,/^}/p' "$source/drivers/gpu/drm/msm/dp/dp_ctrl.c" >> "$out/native-idle-aux.inc"
[[ $(grep -c '^}' "$out/native-idle-aux.inc") == 5 ]]
for mode in plain sanitized; do
    flags=()
    if [[ $mode == sanitized ]]; then flags=(-fsanitize=address,undefined -fno-omit-frame-pointer); fi
    binary="$out/idle-aux-$compiler-$mode"
    "$compiler" -std=gnu11 -Wall -Wextra -Werror "${flags[@]}" -I"$out" "$test_src" -o "$binary"
    ASAN_OPTIONS=detect_leaks=0 "$binary"
done
