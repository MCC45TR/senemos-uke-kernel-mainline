#include <assert.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>

struct msm_dp_ctrl { int present; };
struct msm_dp_panel { unsigned int id, stream_id; };
struct phy { unsigned int n; };
struct msm_dp_ctrl_private {
    struct msm_dp_ctrl msm_dp_ctrl;
    struct phy *phy;
    bool link_clks_on, phy_powered, mst_active;
    bool stream_clks_on[2];
    void *pixel_clk[2];
    unsigned int num_pixel_clks;
    void *aux;
    struct device *dev;
};
#define container_of(p, type, member) ((type *)((char *)(p) - offsetof(type, member)))
static unsigned int reset_count, disable_count, phy_off_count, phy_reinit_count;
static unsigned int fec_count, stop_aux_count, release_rate_count;
static int power_off_error;
static unsigned int packet_step, vsc_count, hdr_count, dto_count, pixel_off_count;
static bool cliffs, stream_registers_powered;

static void msm_dp_ctrl_mainlink_disable(struct msm_dp_ctrl_private *c)
{
    assert(c->link_clks_on);
    disable_count++;
}
static void msm_dp_ctrl_reset(struct msm_dp_ctrl *ctrl, struct msm_dp_panel *panel)
{
    assert(panel->id && container_of(ctrl, struct msm_dp_ctrl_private, msm_dp_ctrl)->link_clks_on);
    reset_count++;
}
static void msm_dp_ctrl_link_clk_disable(struct msm_dp_ctrl *ctrl)
{
    container_of(ctrl, struct msm_dp_ctrl_private, msm_dp_ctrl)->link_clks_on = false;
}
static int msm_dp_ctrl_phy_power_off(struct msm_dp_ctrl_private *c)
{
    if (!c->phy_powered)
        return 0;
    phy_off_count++;
    if (!power_off_error)
        c->phy_powered = false;
    return power_off_error;
}
static void phy_exit(struct phy *phy) { assert(phy != NULL); }
static void phy_init(struct phy *phy) { assert(phy != NULL); phy_reinit_count++; }
static void msm_dp_ctrl_fec_disable(struct msm_dp_ctrl_private *c, struct msm_dp_panel *panel)
{
    assert(c != NULL && panel != NULL);
    fec_count++;
}
static void msm_dp_aux_enable_xfers(void *aux, bool enable)
{
    assert(aux != NULL && !enable);
    stop_aux_count++;
}
static void msm_dp_panel_disable_vsc_sdp(struct msm_dp_panel *panel)
{
    assert(panel && stream_registers_powered && packet_step++ == 0);
    vsc_count++;
}
static void msm_dp_panel_disable_hdr_sdp(struct msm_dp_panel *panel)
{
    assert(panel && stream_registers_powered && packet_step++ == 1);
    hdr_count++;
}
static void msm_dp_panel_config_dto(struct msm_dp_panel *panel, bool reset)
{
    assert(panel && reset && stream_registers_powered && packet_step++ == 2);
    dto_count++;
}
static void clk_disable_unprepare(void *clk)
{
    assert(clk && packet_step == (stream_registers_powered ? (cliffs ? 3U : 1U) : 0U));
    stream_registers_powered = false;
    pixel_off_count++;
}
struct device { const void *of_node; };
#define of_device_is_compatible(node, name) (cliffs)
static void msm_dp_ctrl_mst_config(struct msm_dp_ctrl_private *c, bool enabled)
{
    assert(c->link_clks_on && !enabled);
}
static void dev_pm_opp_set_rate(void *dev, unsigned int rate)
{
    assert(dev != NULL && !rate);
    release_rate_count++;
}
#include "native-teardown.inc"

int main(void)
{
    struct msm_dp_panel panel = { .id = 1 };
    struct phy phy = {0};
    struct device dev = {0};
    struct msm_dp_ctrl_private c = {
        .phy = &phy, .link_clks_on = true, .phy_powered = true,
        .mst_active = true, .aux = &phy, .dev = &dev,
    };

    assert(msm_dp_ctrl_deinitialize_mainlink(&c, &panel) == 0);
    assert(reset_count == 1 && disable_count == 1 && phy_off_count == 1 && phy_reinit_count == 1);
    assert(!c.link_clks_on && !c.phy_powered);
    assert(msm_dp_ctrl_off_link(&c.msm_dp_ctrl, &panel, false) == 0);
    assert(reset_count == 1 && disable_count == 1 && release_rate_count == 1 && fec_count == 1);
    assert(!c.mst_active);

    assert(msm_dp_ctrl_deinitialize_mainlink(&c, &panel) == 0);
    assert(reset_count == 1 && disable_count == 1 && phy_reinit_count == 2);
    c.link_clks_on = true;
    c.phy_powered = true;
    power_off_error = -5;
    assert(msm_dp_ctrl_off_link(&c.msm_dp_ctrl, &panel, true) == -5);
    assert(reset_count == 2 && disable_count == 2 && stop_aux_count == 1);
    assert(!c.link_clks_on && c.phy_powered);
    power_off_error = 0;
    assert(msm_dp_ctrl_off_link(&c.msm_dp_ctrl, &panel, true) == 0);
    assert(reset_count == 2 && disable_count == 2 && stop_aux_count == 2 && !c.phy_powered);
    c.num_pixel_clks = 2;
    c.pixel_clk[0] = &phy;
    c.pixel_clk[1] = &phy;
    c.link_clks_on = true;
    c.stream_clks_on[0] = true;
    stream_registers_powered = true;
    cliffs = true;
    msm_dp_ctrl_off_pixel_clk(&c.msm_dp_ctrl, &panel);
    assert(packet_step == 3 && pixel_off_count == 1 && !c.stream_clks_on[0]);
    msm_dp_ctrl_off_pixel_clk(&c.msm_dp_ctrl, &panel);
    assert(msm_dp_ctrl_off_link(&c.msm_dp_ctrl, &panel, false) == 0);
    assert(vsc_count == 1 && hdr_count == 1 && dto_count == 1 && pixel_off_count == 1);

    packet_step = 0;
    c.stream_clks_on[0] = true;
    msm_dp_ctrl_off_pixel_clk(&c.msm_dp_ctrl, &panel);
    assert(packet_step == 0 && pixel_off_count == 2 && !c.stream_clks_on[0]);

    cliffs = false;
    c.link_clks_on = true;
    c.stream_clks_on[1] = true;
    stream_registers_powered = true;
    panel.stream_id = 1;
    msm_dp_ctrl_off_pixel_clk(&c.msm_dp_ctrl, &panel);
    assert(packet_step == 1 && pixel_off_count == 3 && !c.stream_clks_on[1]);
    assert(vsc_count == 2 && hdr_count == 1 && dto_count == 1);
    panel.stream_id = 2;
    msm_dp_ctrl_off_pixel_clk(&c.msm_dp_ctrl, &panel);
    assert(pixel_off_count == 3);
    puts("Passed active, failed-training and repeated DisplayPort teardown checks.");
    puts("Passed stream-packet cleanup before pixel clock gating.");
    return 0;
}
