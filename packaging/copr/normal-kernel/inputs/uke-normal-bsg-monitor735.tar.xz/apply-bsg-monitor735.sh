#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C

[[ $# == 2 || $# == 3 ]]
action=$1
kernel=$(realpath -e "$2")
assets=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
patch=$assets/fs19xx-bsg-monitor-get.patch
cd "$kernel"

case "$action" in
    prepare)
        [[ $# == 2 ]]
        sha256sum --strict -c "$assets/before.sha256"
        git apply --check --whitespace=error "$patch"
        git apply --whitespace=error "$patch"
        sha256sum --strict -c "$assets/after.sha256"
        ;;
    verify-and-restore)
        [[ $# == 3 ]]
        out=$(realpath -e "$3")
        module=$out/sound/soc/qcom/qdsp6/snd-q6apm.ko
        grep -Fxq '# CONFIG_SND_SOC_FS19XX_UKE_QUALIFIED_GAIN is not set' "$out/.config"
        readelf -h "$module" | grep -F AArch64
        readelf -Ws "$module" | awk '
            $7!="UND" { linked[$NF]++ }
            END {
                exit !(linked["q6apm_fs19xx_read_bsg_info"]==1 &&
                       linked["fs19xx_bsg_get"]==1 && linked["q6apm_vi_snapshot_show"]==1)
            }
        '
        grep -aqF 'FS19xx DSP BSG Monitor Info' "$module"
        sha256sum --strict -c "$assets/after.sha256"
        git apply --reverse --check --whitespace=error "$patch"
        git apply --reverse --whitespace=error "$patch"
        sha256sum --strict -c "$assets/before.sha256"
        ;;
    *) exit 2 ;;
esac
