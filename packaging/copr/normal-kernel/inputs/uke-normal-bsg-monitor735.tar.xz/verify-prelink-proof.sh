#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C
umask 077

assets=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
package=$assets/uke-kernel-migration-check-7.3.5-32.bsg_monitor_prelink.fc46.aarch64.rpm
keyfile=$assets/copr-signing-key.gpg
fingerprint=2204a661ea630a5303500085538797e72a3e4eca
printf '%s  %s\n' 8aee833d527aeba37c1c5e8ae8aacb408a1224eda298e6d08caf91c36e6d3ebd "$package" |
    sha256sum --check --strict
actual=$(gpg --batch --with-colons --show-keys "$keyfile" | awk -F: '$1=="fpr" && !seen++ {print tolower($10)}')
[[ "$actual" == "$fingerprint" ]]
work=$(mktemp -d)
trap 'find "$work" -depth -delete' EXIT
mkdir "$work/trust"
rpmkeys --dbpath "$work/trust" --import "$keyfile"
rpmkeys --dbpath "$work/trust" --checksig --verbose "$package" > "$work/signatures"
[[ $(grep -Fc "signature, key fingerprint: $fingerprint: OK" "$work/signatures") == 2 ]]
! grep -Eq 'BAD|NOT OK|NOKEY' "$work/signatures"
rpm2cpio "$package" |
    cpio -i --quiet --to-stdout ./usr/share/uke-kernel-migration-check/audio-bsg-monitor-prelink735/qualification.txt > "$work/proof"
for ledger in before.sha256 after.sha256; do
    while IFS= read -r line; do grep -Fxq -- "$line" "$work/proof"; done < "$assets/$ledger"
done
patch=fs19xx-bsg-monitor-get.patch
patch_hash=$(sha256sum "$assets/$patch" | cut -d ' ' -f 1)
grep -Eq "^${patch_hash}  (\./)?${patch//./\\.}$" "$work/proof"
grep -Fxq '# CONFIG_SND_SOC_FS19XX_UKE_QUALIFIED_GAIN is not set' "$work/proof"
grep -Fxq 'FS19xx DSP BSG Monitor Info' "$work/proof"
grep -Fx 'Actual AArch64 snd-q6apm composite linked, known controls retained, and source restored byte-for-byte.' "$work/proof"
