#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C
[[ $# == 2 && $(uname -m) == aarch64 ]]
inputs=$(realpath -e "$1")
result=$(realpath -m "$2")
mkdir replay
cd replay
parent=senemos-uke-linux-kernel-mainline-7.3.5-45.fc46.src.rpm
base=https://download.copr.fedorainfracloud.org/results/mcc45tr/uke-linux-unstable/fedora-rawhide-aarch64/11372229-senemos-uke-linux-kernel-mainline
key=2204a661ea630a5303500085538797e72a3e4eca
curl -qfsSL --proto '=https' --retry 3 --retry-all-errors --max-time 205 --max-filesize 190000000 "$base/$parent" -o "$parent"
sha256sum -c --strict "$inputs/parent.sha256"
[[ $(gpg --batch --with-colons --show-keys "$inputs/parent-key.gpg" | awk -F: '$1=="fpr"{print tolower($10);exit}') == "$key" ]]
mkdir trust out hpd
rpmkeys --dbpath "$PWD/trust" --import "$inputs/parent-key.gpg"
rpmkeys --dbpath "$PWD/trust" --checksig -v "$parent" > parent-signatures.txt
[[ $(grep -Fc "key fingerprint: $key: OK" parent-signatures.txt) == 2 ]]
! grep -Eq 'NOKEY|BAD|NOT OK' parent-signatures.txt
rpm2cpio "$parent" | cpio -id --quiet --no-absolute-filenames './linux-7.3.5.tar.xz' './senemos-native-profile-7.3.5.tar.xz' './uke-dp-hpd-worker73538.tar.xz'
printf '%s  %s\n' 7b96228cd871f3b795c8d2af18beb8a6ae5f4889472cfa8e4f73037b86d5e276 uke-dp-hpd-worker73538.tar.xz | sha256sum -c --strict
tar -xJf linux-7.3.5.tar.xz
tar -xJf senemos-native-profile-7.3.5.tar.xz native-profile/patches/display/0061-uke-dp-mst-and-negotiated-lanes.patch
tar -xJf uke-dp-hpd-worker73538.tar.xz -C hpd
hpd=$PWD/hpd/hpd-overlay
out=$PWD/out
cd linux-7.3.5
file=drivers/gpu/drm/display/drm_bridge_connector.c
patch=$inputs/0001-drm-bridge-restore-fixed-dsi-depth-on-state-create.patch
git apply --include="$file" --include='include/drm/**' ../native-profile/patches/display/0061-uke-dp-mst-and-negotiated-lanes.patch
grep -F "  $file" "$hpd/dp-hpd-before.sha256" | sha256sum -c --strict
git apply --include="$file" --whitespace=error "$hpd/drm-bridge-defer-passive-dp-hpd-probe.patch"
grep -F "  $file" "$hpd/dp-hpd-after.sha256" | sha256sum -c --strict
sha256sum -c --strict "$inputs/before.sha256"
git apply --check --whitespace=error "$patch"
git apply --whitespace=error "$patch"
sha256sum -c --strict "$inputs/after.sha256"
for compiler in gcc clang; do
    bash "$inputs/check-fixed-bpc.sh" "$file" "$inputs/test-fixed-bpc.c" "$out" "$compiler"
done | tee "$out/tests.txt"
[[ $(grep -Fxc 'Eight fixed-DSI state creation, reset and preservation cases passed.' "$out/tests.txt") == 4 ]]
cp "$inputs/accepted.config" "$out/.config"
scripts/config --file "$out/.config" --set-str INITRAMFS_SOURCE '' --set-str MODULE_SIG_KEY certs/signing_key.pem     --set-str SYSTEM_TRUSTED_KEYS '' --set-str SYSTEM_REVOCATION_KEYS ''
make -s O="$out" ARCH=arm64 LLVM=1 LLVM_IAS=1 -j4 olddefconfig prepare modules_prepare
object="${file%.c}.o"
make -s O="$out" ARCH=arm64 LLVM=1 LLVM_IAS=1 -j4 "$object"
llvm-readelf -h "$out/$object" | grep -F AArch64
llvm-nm "$out/$object" | grep -E ' [tT] drm_bridge_connector_create_state$'
git apply --reverse --check --whitespace=error "$patch"
git apply --reverse --whitespace=error "$patch"
sha256sum -c --strict "$inputs/before.sha256"
{
    cat "$inputs/parent.sha256" "$inputs/before.sha256" "$inputs/after.sha256" "$out/tests.txt"
    (cd "$out"; sha256sum "$object")
    printf '%s\n' 'Signed cumulative bridge preimage, fixed DSI patch inverse, and AArch64 object verified.'
} > "$result"
