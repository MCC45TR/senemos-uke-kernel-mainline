#!/usr/bin/bash
set -Eeuo pipefail
[[ $# == 4 ]]
source_file=$1 fixture=$2 work=$3 compiler=$4
mkdir -p "$work"
awk '
    /^drm_bridge_connector_create_state\(/ { exact=1; print "static struct drm_connector_state *"; }
    exact { print }
    exact && /^}$/ { exit }
' "$source_file" > "$work/create-state.inc"
grep -Fq 'max_requested_bpc' "$work/create-state.inc"
for sanitize in plain sanitized; do
    options=()
    if [[ $sanitize == sanitized ]]; then
        options+=(-fsanitize=undefined -fno-sanitize-recover=all)
    fi
    "$compiler" -Wall -Wextra -Werror -std=c11 -O1 "${options[@]}" -I "$work" "$fixture" -o "$work/test-$compiler-$sanitize"
    "$work/test-$compiler-$sanitize"
done
