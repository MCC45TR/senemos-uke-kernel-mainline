#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C
[[ $# == 2 ]]
assets=$(cd -- "$(dirname -- "$0")" && pwd)
tree=$(realpath -e -- "$2")
patch=$assets/ov08d10-reset-error-unwind.patch
proof=$assets/uke-kernel-migration-check-7.3.5-45.ov08d10_reset27.fc46.aarch64.rpm
key=2204a661ea630a5303500085538797e72a3e4eca
cd "$tree"
case "$1" in
    prepare)
        (cd "$assets"; sha256sum -c --strict --quiet SHA256SUMS)
        sha256sum -c --strict --quiet "$assets/before.sha256"
        [[ $(gpg --batch --with-colons --show-keys "$assets/parent-key.gpg" | awk -F: '$1=="fpr"{print tolower($10);exit}') == "$key" ]]
        trust=$(mktemp -d --tmpdir="$tree" .ov08d10-reset.XXXXXXXX)
        trap 'find "$trust" -maxdepth 1 -type f -delete; rmdir -- "$trust"' EXIT
        rpmkeys --dbpath "$trust" --import "$assets/parent-key.gpg"
        rpmkeys --dbpath "$trust" --checksig -v "$proof" > "$trust/signatures"
        [[ $(grep -Fc "key fingerprint: $key: OK" "$trust/signatures") == 2 ]]
        ! grep -Eq 'NOKEY|NOT OK|BAD' "$trust/signatures"
        rpm2cpio "$proof" | cpio -i --quiet --to-stdout \
            './usr/share/uke-kernel-migration-check/ov08d10-reset-unwind73527/qualification.txt' > "$trust/receipt"
        hash=$(sha256sum "$patch")
        grep -Fxq "${hash%% *}  ${patch##*/}" "$trust/receipt"
        [[ $(grep -Fxc 'Six production power-on paths passed; reset failure stops clock and supplies.' "$trust/receipt") == 4 ]]
        grep -Fxq 'Native AArch64 OV08D10 object checked; exact source inverse verified.' "$trust/receipt"
        git apply --check --whitespace=error "$patch"
        git apply --whitespace=error "$patch"
        sha256sum -c --strict "$assets/after.sha256"
        ;;
    restore)
        sha256sum -c --strict "$assets/after.sha256"
        git apply --reverse --check --whitespace=error "$patch"
        git apply --reverse --whitespace=error "$patch"
        sha256sum -c --strict "$assets/before.sha256"
        ;;
    *) exit 2 ;;
esac
