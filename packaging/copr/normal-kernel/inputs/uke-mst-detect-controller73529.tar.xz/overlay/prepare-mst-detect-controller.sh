#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C
[[ $# == 2 ]]
assets=$(cd -- "$(dirname -- "$0")" && pwd)
tree=$(realpath -e -- "$2")
key=2204a661ea630a5303500085538797e72a3e4eca
proof="$assets/uke-kernel-migration-check-7.3.5-49.uke_mst_detect29.fc46.aarch64.rpm"
patch="$assets/0001-msm-dp-mst-detect-own-controller.patch"
cd "$tree"
case $1 in
    prepare)
        (cd "$assets"; sha256sum -c --strict --quiet SHA256SUMS)
        sha256sum -c --strict "$assets/before.sha256"
        [[ $(gpg --batch --with-colons --show-keys "$assets/parent-key.gpg" | awk -F: '$1=="fpr"{print tolower($10);exit}') == "$key" ]]
        trust=$(mktemp -d --tmpdir="$tree" .mst-pm.XXXXXXXX)
        trap 'find "$trust" -maxdepth 1 -type f -delete; rmdir -- "$trust"' EXIT
        rpmkeys --dbpath "$trust" --import "$assets/parent-key.gpg"
        rpmkeys --dbpath "$trust" --checksig -v "$proof" > "$trust/verified"
        [[ $(grep -Fc "key fingerprint: $key: OK" "$trust/verified") == 2 ]]
        ! grep -Eq 'NOKEY|BAD|NOT OK' "$trust/verified"
        rpm2cpio "$proof" | cpio -i --quiet --to-stdout             './usr/share/uke-kernel-migration-check/mst-detect29/qualification.txt' > "$trust/receipt"
        [[ $(grep -Fc '6 MST detect cases passed' "$trust/receipt") == 4 ]]
        for entry in "${patch##*/}" before.sha256 after.sha256; do
            grep -Fxq "$(cd "$assets"; sha256sum "$entry")" "$trust/receipt"
        done
        git apply --check --whitespace=error "$patch"
        git apply --whitespace=error "$patch"
        sha256sum -c --strict "$assets/after.sha256"
        ;;
    restore)
        sha256sum -c --strict "$assets/after.sha256"
        git apply --reverse --check --whitespace=error "$patch"
        git apply --reverse --whitespace=error "$patch"
        sha256sum -c --strict "$assets/before.sha256"
        ;;
    *) exit 2 ;;
esac
