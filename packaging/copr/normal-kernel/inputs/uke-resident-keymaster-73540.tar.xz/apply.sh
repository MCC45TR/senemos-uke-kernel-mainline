#!/usr/bin/bash
# SPDX-License-Identifier: GPL-2.0-only
set -Eeuo pipefail
[[ $# == 2 ]]
kernel=$(realpath -e "$1")
inputs=$(realpath -e "$2")
[[ -e $kernel/drivers/firmware/qcom/qcom_scm.c && -e $kernel/include/linux/uke-rtc-policy.h ]]
(cd "$inputs"; sha256sum -c --strict --quiet SHA256SUMS)
cd "$kernel"
sha256sum -c --strict "$inputs/scm-before.sha256"
git apply --check --whitespace=error "$inputs/0001-qcom-scm-report-resident-uke-keymaster.patch"
git apply --whitespace=error "$inputs/0001-qcom-scm-report-resident-uke-keymaster.patch"
sha256sum -c --strict "$inputs/scm-after.sha256"
