#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C
[[ $# == 2 ]]
assets=$(cd -- "$(dirname -- "$0")" && pwd)
tree=$(realpath -e "$2")
key=2204a661ea630a5303500085538797e72a3e4eca
gpi="$assets/gpi/gpi-validate-event-ring-producer.patch"
dpu="$assets/dpu/dpu-use-incoming-planes-for-perf.patch"
before=("$assets/gpi/gpi-ring-before.sha256" "$assets/dpu/before.sha256")
after=("$assets/gpi/gpi-ring-after.sha256" "$assets/dpu/after.sha256")

verify_proof() {
    local group=$1 source=$2 result=$3
    shift 3
    local dir="$assets/$group" name
    local proof=("$dir/"*.aarch64.rpm)
    [[ ${#proof[@]} == 1 ]]
    rpmkeys --dbpath "$trust" --checksig -v "${proof[0]}" > "$trust/signatures"
    [[ $(grep -Fc "key fingerprint: $key: OK" "$trust/signatures") == 2 ]]
    ! grep -Eq 'NOKEY|BAD|NOT OK' "$trust/signatures"
    rpm2cpio "${proof[0]}" |
        cpio -i --quiet --to-stdout "./usr/share/uke-kernel-migration-check/$source/qualification.txt" > "$trust/receipt"
    [[ $(grep -Fxc "$result" "$trust/receipt") == 4 ]]
    (
        cd "$dir"
        for name; do grep -Fxq "$(sha256sum -- "$name")" "$trust/receipt"; done
    )
}

cd "$tree"
(cd "$assets"; sha256sum -c --strict --quiet SHA256SUMS)
case "$1" in
    prepare)
        sha256sum -c --strict "${before[@]}"
        [[ $(gpg --batch --with-colons --show-keys "$assets/parent-key.gpg" |
            awk -F: '$1=="fpr" && !seen++ {print tolower($10)}') == "$key" ]]
        umask 077
        trust=$(mktemp -d --tmpdir="$tree" .uke-display-fault.XXXXXXXX)
        trap 'find "$trust" -maxdepth 1 -type f -delete; rmdir -- "$trust"' EXIT
        rpmkeys --dbpath "$trust" --import "$assets/parent-key.gpg"
        verify_proof gpi gpi-event-ring31 'Eight GPI ring consumption and reset cases passed.' \
            gpi-ring-before.sha256 gpi-ring-after.sha256 "${gpi##*/}"
        verify_proof dpu dpu-atomic-perf31 'Seven DPU prospective bandwidth and clock cases passed.' \
            before.sha256 after.sha256 "${dpu##*/}"
        git apply --check --whitespace=error "$gpi" "$dpu"
        git apply --whitespace=error "$gpi" "$dpu"
        sha256sum -c --strict "${after[@]}"
        ;;
    restore)
        sha256sum -c --strict "${after[@]}"
        git apply --reverse --check --whitespace=error "$dpu" "$gpi"
        git apply --reverse --whitespace=error "$dpu" "$gpi"
        sha256sum -c --strict "${before[@]}"
        ;;
    *) exit 2 ;;
esac
