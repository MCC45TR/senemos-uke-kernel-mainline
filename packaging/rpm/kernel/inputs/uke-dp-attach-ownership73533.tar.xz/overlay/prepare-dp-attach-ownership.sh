#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C
umask 077
[[ $# == 2 ]]
assets=$(cd -- "$(dirname -- "$0")" && pwd)
tree=$(realpath -e "$2")
key=2204a661ea630a5303500085538797e72a3e4eca
patch="$assets/dp-attach-ownership.patch"

cd "$tree"
(cd "$assets"; sha256sum -c --strict --quiet SHA256SUMS)
case "$1" in
    prepare)
        sha256sum -c --strict "$assets/attach-before.sha256"
        [[ $(gpg --batch --with-colons --show-keys "$assets/parent-key.gpg" |
            awk -F: '$1=="fpr" && !seen++ {print tolower($10)}') == "$key" ]]
        trust=$(mktemp -d --tmpdir="$tree" .uke-dp-attach-proof.XXXXXXXX)
        trap 'find "$trust" -maxdepth 1 -type f -delete; rmdir -- "$trust"' EXIT
        rpmkeys --dbpath "$trust" --import "$assets/parent-key.gpg"
        proof=("$assets"/uke-kernel-migration-check-7.3.5-60.uke_dp_attach_ownership33*.aarch64.rpm)
        [[ ${#proof[@]} == 1 && -f ${proof[0]} ]]
        rpmkeys --dbpath "$trust" --checksig -v "${proof[0]}" > "$trust/signatures"
        [[ $(grep -Fc "key fingerprint: $key: OK" "$trust/signatures") == 2 ]]
        ! grep -Eq 'NOKEY|BAD|NOT OK' "$trust/signatures"
        rpm2cpio "${proof[0]}" |
            cpio -i --quiet --to-stdout './usr/share/uke-kernel-migration-check/dp-attach-ownership33/qualification.txt' > "$trust/qualification"
        [[ $(grep -Fxc 'Eleven MSM DP attachment and probe ownership cases passed.' "$trust/qualification") == 4 ]]
        grep -Fx 'Four native AArch64 MSM DP objects and exact patch inverses verified.' "$trust/qualification"
        (
            cd "$assets"
            for file in attach-before.sha256 attach-after.sha256 "${patch##*/}"; do
                grep -Fxq "$(sha256sum -- "./$file")" "$trust/qualification"
            done
        )
        git apply --check --whitespace=error "$patch"
        git apply --whitespace=error "$patch"
        sha256sum -c --strict "$assets/attach-after.sha256"
        ;;
    restore)
        sha256sum -c --strict "$assets/attach-after.sha256"
        git apply --reverse --check --whitespace=error "$patch"
        git apply --reverse --whitespace=error "$patch"
        sha256sum -c --strict "$assets/attach-before.sha256"
        ;;
    *) exit 2 ;;
esac
