#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C

[[ $# == 2 || $# == 3 ]]
phase=$1
tree=$(realpath -e -- "$2")
assets=$(cd -- "$(dirname -- "$0")" && pwd)
patch="$assets/0027-power-supply-qcom-battmgr-coalesce-uke-status-bursts.patch"
case $phase in
    prepare)
        [[ $# == 2 ]]
        (cd "$assets"; sha256sum -c --strict --quiet SHA256SUMS)
        rpm=uke-kernel-migration-check-7.3.5-24.bat_status.fc46.aarch64.rpm
        proof=$(rpm2cpio "$assets/$rpm" | cpio -i --quiet --to-stdout \
            './usr/share/uke-kernel-migration-check/battery-status-burst735/qualification.txt')
        grep -Fxq 'Signed normal Uke 7.3.5-20 source, COPR 11366541.' <<< "$proof"
        grep -Fxq 'Immediate first, bounded trailing, other classes, startup, suspend/resume, PDR, backlog and removal passed.' <<< "$proof"
        grep -Fxq 'ARM64 QCOM battery driver object compiled and the patch reverses to the exact signed preimage.' <<< "$proof"
        for member in "$patch" "$assets/before.sha256" "$assets/after.sha256"; do
            read -r digest _ < <(sha256sum "$member")
            grep -Fxq "$digest  ./${member##*/}" <<< "$proof"
        done
        cd -- "$tree"
        sha256sum -c --strict --quiet "$assets/before.sha256"
        git apply --check --whitespace=error "$patch"
        git apply --whitespace=error "$patch"
        sha256sum -c --strict --quiet "$assets/after.sha256"
        ;;
    linked)
        [[ $# == 3 ]]
        module="$tree/drivers/power/supply/qcom_battmgr.ko"
        readelf -h "$module" | grep -F AArch64
        [[ $(modinfo -F vermagic "$module") == "$3 "* ]]
        readelf -Ws "$module" | awk '$7 != "UND" && $8 == "qcom_battmgr_uke_battery_status_worker" { found=1 } END { exit !found }'
        grep -Fx 'CONFIG_BATTERY_QCOM_BATTMGR=m' "$tree/.config"
        grep -Fx 'CONFIG_HZ=250' "$tree/.config"
        sha256sum "$module"
        ;;
    restore)
        [[ $# == 2 ]]
        cd -- "$tree"
        sha256sum -c --strict --quiet "$assets/after.sha256"
        git apply --reverse --check --whitespace=error "$patch"
        git apply --reverse --whitespace=error "$patch"
        sha256sum -c --strict --quiet "$assets/before.sha256"
        ;;
    *) exit 2 ;;
esac
