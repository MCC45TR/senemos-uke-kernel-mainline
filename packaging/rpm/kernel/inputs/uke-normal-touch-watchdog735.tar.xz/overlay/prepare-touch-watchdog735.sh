#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C
[[ $# == 2 || $# == 3 ]]
phase=$1
tree=$(realpath -e -- "$2")
assets=$(cd -- "$(dirname -- "$0")" && pwd)
patch="$assets/nt36532-retain-fresh-thp-frame.patch"
module=drivers/input/touchscreen/nt36532-uke/nt36532-uke-touch.ko

check_receipt() {
    local proof digest file
    (cd "$assets"; sha256sum -c --strict --quiet SHA256SUMS)
    proof=$(rpm2cpio "$assets/uke-kernel-migration-check-7.3.5-29.touch_watchdog.fc46.aarch64.rpm" |
        cpio -i --quiet --to-stdout ./usr/share/uke-kernel-migration-check/touch-watchdog735/qualification.txt)
    grep -Fxq 'Signed normal Uke 7.3.5-22 source, COPR 11367218.' <<<"$proof"
    grep -Fxq 'The previous driver failed the valid duplicate burst assertion.' <<<"$proof"
    grep -Fxq 'ARM64 NT36532 composite compiled and the source reverses to the exact signed preimage.' <<<"$proof"
    test "$(grep -Fc 'Watchdog frame-progress contract passed:' <<<"$proof")" = 4
    for file in "$patch" "$assets/before.sha256" "$assets/after.sha256" "$assets/check-watchdog.sh" "$assets/watchdog-transport.c"; do
        read -r digest _ < <(sha256sum "$file")
        grep -Fxq "$digest  ./${file##*/}" <<<"$proof"
    done
}

case $phase in
    prepare)
        [[ $# == 2 ]]
        check_receipt
        cd -- "$tree"
        sha256sum -c --strict --quiet "$assets/before.sha256"
        git apply --check --whitespace=error "$patch"
        git apply --whitespace=error "$patch"
        sha256sum -c --strict --quiet "$assets/after.sha256"
        CC=gcc bash "$assets/check-watchdog.sh" "$PWD" candidate
        ;;
    linked)
        [[ $# == 3 && $3 =~ ^[0-9]+\.[0-9]+\.[0-9]+-[0-9]+$ ]]
        cd -- "$tree"
        grep -Fxq 'CONFIG_TOUCHSCREEN_NT36532_UKE=m' .config
        grep -Fxq 'CONFIG_DRM_PANEL_XIAOMI_O82=m' .config
        readelf -h "$module" | grep -F AArch64
        [[ $(modinfo -F vermagic "$module") == "$3 "* ]]
        readelf -Ws "$module" | awk '
            $4=="FUNC" && $7!="UND" && $8=="nvt_uke_decode" { decode=1 }
            $4=="FUNC" && $7!="UND" && $8=="nvt_uke_watchdog" { watchdog=1 }
            $4=="FUNC" && $7!="UND" && $8=="nvt_read_contacts" { input=1 }
            END { exit !(decode && watchdog && input) }
        '
        sha256sum "$module"
        ;;
    restore)
        [[ $# == 2 ]]
        cd -- "$tree"
        sha256sum -c --strict --quiet "$assets/after.sha256"
        git apply --reverse --check --whitespace=error "$patch"
        git apply --reverse --whitespace=error "$patch"
        sha256sum -c --strict --quiet "$assets/before.sha256"
        ;;
    *) exit 2 ;;
esac
