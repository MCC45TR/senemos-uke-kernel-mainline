#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C
[[ $# == 2 ]]
phase=$1
tree=$(realpath -e -- "$2")
assets=$(cd -- "$(dirname -- "$0")" && pwd)
patch="$assets/nt36532-reset-marker-and-distinct-scans.patch"

verify_qualification() {
    local proof digest file
    (cd "$assets"; sha256sum -c --strict --quiet SHA256SUMS)
    proof=$(rpm2cpio "$assets/uke-kernel-migration-check-7.3.5-33.touch_distinct.fc46.aarch64.rpm" |
        cpio -i --quiet --to-stdout ./usr/share/uke-kernel-migration-check/touch-distinct735/qualification.txt)
    grep -Fxq 'Signed normal Uke 7.3.5-23 source, COPR 11367446.' <<<"$proof"
    grep -Fxq 'The signed parent processed duplicate scans and failed the one-scan publication assertion.' <<<"$proof"
    grep -Fxq 'ARM64 NT36532 composite compiled and the source reverses to the exact signed preimage.' <<<"$proof"
    [[ $(grep -Fc 'Distinct scans and OEM reset marker:' <<<"$proof") == 4 ]]
    [[ $(grep -Fc '100 in-flight panel races: PASS' <<<"$proof") == 4 ]]
    for file in "$patch" "$assets/previous.sha256" "$assets/candidate.sha256" \
        "$assets/check-watchdog.sh" "$assets/watchdog-transport.c"; do
        read -r digest _ < <(sha256sum "$file")
        grep -Fxq "$digest  ./${file##*/}" <<<"$proof"
    done
}

cd -- "$tree"
case $phase in
    prepare)
        verify_qualification
        sha256sum --strict --quiet -c "$assets/previous.sha256"
        git apply --check --whitespace=error "$patch"
        git apply --whitespace=error "$patch"
        sha256sum --strict --quiet -c "$assets/candidate.sha256"
        CC=gcc bash "$assets/check-watchdog.sh" "$PWD" candidate
        ;;
    restore)
        sha256sum --strict --quiet -c "$assets/candidate.sha256"
        git apply --reverse --check --whitespace=error "$patch"
        git apply --reverse --whitespace=error "$patch"
        sha256sum --strict --quiet -c "$assets/previous.sha256"
        ;;
    *) exit 2 ;;
esac
