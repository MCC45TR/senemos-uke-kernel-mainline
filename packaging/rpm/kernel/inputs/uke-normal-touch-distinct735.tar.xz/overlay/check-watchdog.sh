#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C
[[ $# == 2 && ( $2 == previous || $2 == candidate ) ]]
tree=$(realpath -e "$1")
root=$(cd -- "$(dirname -- "$0")" && pwd)
dir=$tree/drivers/input/touchscreen/nt36532-uke
testdir=$(mktemp -d)
trap 'find "$testdir" -depth -delete' EXIT
awk '
 /^#define NVT_UKE_(IRQ_FALLBACK|POLL_PERIOD|STALE_INPUT)_MS / { print }
 /^static (bool nvt_active\(|void nvt_schedule_poll\(|int nvt_ready\(|int nvt_transfer\(|int nvt_spi_io\(|void nvt_irq_set\(|void nvt_quiesce\(|void nvt_fault\(|void nvt_boot_worker\(|void nvt_read_contacts\(|int nvt_panel_changed\(|int nvt_suspend\(|int nvt_resume\(|void nvt_apply_charger\(|void nvt_charger_worker\(|int nvt_supply_changed\()/ { copy=1 }
 copy { print }
 copy && /^}/ { copy=0; count++ }
 END { exit count!=16 }
' "$dir/nt36532-uke-spi.c" >"$testdir/production.h"
awk '
 /^int nvt_uke_(decode|watchdog)\(/ { print; copy=1; next }
 copy { print }
 copy && /^}/ { copy=0; count++ }
 END { exit count!=2 }
' "$dir/nt36532-uke-protocol.c" >"$testdir/watchdog-protocol.h"
flags=()
if [[ $2 == previous ]]; then flags+=(-DUKE_TOUCH_PREVIOUS=1); fi
if [[ ${UKE_SANITIZE:-0} == 1 ]]; then
    flags+=(-fsanitize=address,undefined -fno-sanitize-recover=all -fno-omit-frame-pointer)
fi
"${CC:-gcc}" -std=gnu11 -O2 -g -UNDEBUG -Wall -Wextra -Werror -Wno-unused-parameter -pthread "${flags[@]}" \
    -I "$testdir" "$root/watchdog-transport.c" -o "$testdir/check"
ulimit -c 0
timeout 30s "$testdir/check"
