#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C
[[ $# == 2 ]]
assets=$(cd -- "$(dirname -- "$0")" && pwd)
tree=$(realpath -e -- "$2")
patch="$assets/drm-bridge-defer-passive-dp-hpd-probe.patch"
key=2204a661ea630a5303500085538797e72a3e4eca
proof="$assets/uke-kernel-migration-check-7.3.5-73.uke_dp_hpd_probe38.fc46.aarch64.rpm"
member=./usr/share/uke-kernel-migration-check/dp-hpd-probe38/qualification.txt

cd -- "$tree"
(cd -- "$assets" && sha256sum -c --strict --quiet SHA256SUMS)
case $1 in
    prepare)
        sha256sum -c --strict "$assets/dp-hpd-before.sha256"
        fingerprint=$(gpg --batch --with-colons --show-keys "$assets/parent-key.gpg" |
            awk -F: '$1=="fpr"{print tolower($10);exit}')
        [[ $fingerprint == "$key" ]]
        trust=$(mktemp -d --tmpdir="$tree" .dp-hpd-probe.XXXXXXXX)
        trap 'find "$trust" -maxdepth 1 -type f -delete; rmdir -- "$trust"' EXIT
        rpmkeys --dbpath "$trust" --import "$assets/parent-key.gpg"
        rpmkeys --dbpath "$trust" --checksig -v "$proof" > "$trust/signatures"
        [[ $(grep -Fc "key fingerprint: $key: OK" "$trust/signatures") == 2 ]]
        ! grep -Eq 'NOKEY|BAD|NOT OK' "$trust/signatures"
        rpm2cpio "$proof" | cpio -i --quiet --to-stdout "$member" > "$trust/qualification.txt"
        [[ $(grep -Fxc 'Eight DP HPD delivery and connector lifetime cases passed.' "$trust/qualification.txt") == 4 ]]
        grep -Fxq 'Signed 7.3.5-38 parent, two AArch64 DRM objects and exact patch inverse verified.' "$trust/qualification.txt"
        for digest in parent dp-hpd-before dp-hpd-after; do
            while IFS= read -r line; do grep -Fxq -- "$line" "$trust/qualification.txt"; done < "$assets/$digest.sha256"
        done
        git apply --check --whitespace=error "$patch"
        git apply --whitespace=error "$patch"
        sha256sum -c --strict "$assets/dp-hpd-after.sha256"
        ;;
    restore)
        sha256sum -c --strict "$assets/dp-hpd-after.sha256"
        git apply --reverse --check --whitespace=error "$patch"
        git apply --reverse --whitespace=error "$patch"
        sha256sum -c --strict "$assets/dp-hpd-before.sha256"
        ;;
    *) exit 2 ;;
esac
