#!/usr/bin/bash
set -Eeuo pipefail
ulimit -c 0
source=$1
fixture=$2
output=$3
compiler=$4
dpu=$source/drivers/gpu/drm/msm/disp/dpu1
mkdir -p "$output"
{
    grep -E '^#define DPU_GAMMA_LUT_SIZE[[:space:]]' "$dpu/dpu_hw_dspp.h"
    sed -n '/^static inline u32 drm_color_lut_extract(/,/^}/p' "$source/include/drm/drm_color_mgmt.h"
    sed -n '/^static bool dpu_crtc_gamma_is_identity(/,/^}/p' "$dpu/dpu_crtc.c"
} > "$output/gamma-helper.inc"
[[ $(grep -c '^}' "$output/gamma-helper.inc") == 2 ]]
for variant in plain sanitized; do
    flags=()
    if [[ $variant == sanitized ]]; then
        flags=(-fsanitize=address,undefined -fno-omit-frame-pointer)
    fi
    binary="$output/test-gamma-$compiler-$variant"
    "$compiler" -std=gnu11 -Wall -Wextra -Werror -I"$output" "${flags[@]}" "$fixture" -o "$binary"
    ASAN_OPTIONS=detect_leaks=0 "$binary"
done
