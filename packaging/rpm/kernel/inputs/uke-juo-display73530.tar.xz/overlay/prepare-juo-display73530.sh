#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C
[[ $# == 2 ]]
assets=$(cd -- "$(dirname -- "$0")" && pwd)
tree=$(realpath -e -- "$2")
key=2204a661ea630a5303500085538797e72a3e4eca
mst="$assets/mst"
sst="$assets/sst"
patches=(
    "$mst/0001-msm-mst-preallocate-max-bpc.patch"
    "$mst/0002-mst-ddc-do-not-enumerate-parent-of.patch"
    "$sst/0001-msm-dp-use-420-if-rgb-only-fits-six-bpc.patch"
)

verify_proof() {
    local directory=$1 package=$2 member=$3 result=$4
    shift 4
    local proof="$directory/$package" entry
    rpmkeys --dbpath "$trust" --checksig -v "$proof" > "$trust/signatures"
    [[ $(grep -Fc "key fingerprint: $key: OK" "$trust/signatures") == 2 ]]
    ! grep -Eq 'NOKEY|BAD|NOT OK' "$trust/signatures"
    rpm2cpio "$proof" |
        cpio -i --quiet --to-stdout "./usr/share/uke-kernel-migration-check/$member/qualification.txt" > "$trust/receipt"
    [[ $(grep -Fxc "$result" "$trust/receipt") == 4 ]]
    for entry in before.sha256 after.sha256 "$@"; do
        grep -Fxq "$(cd -- "$directory" && sha256sum -- "$entry")" "$trust/receipt"
    done
}

check_files() {
    local state=$1
    sha256sum -c --strict "$mst/$state.sha256" "$sst/$state.sha256"
}

cd -- "$tree"
(cd -- "$assets" && sha256sum -c --strict --quiet SHA256SUMS)
case $1 in
    prepare)
        check_files before
        [[ $(gpg --batch --with-colons --show-keys "$assets/parent-key.gpg" | awk -F: '$1=="fpr"{print tolower($10);exit}') == "$key" ]]
        umask 077
        trust=$(mktemp -d --tmpdir="$tree" .juo-display.XXXXXXXX)
        trap 'find "$trust" -maxdepth 1 -type f -delete; rmdir -- "$trust"' EXIT
        rpmkeys --dbpath "$trust" --import "$assets/parent-key.gpg"
        verify_proof "$mst" uke-kernel-migration-check-7.3.5-51.uke_mst_hotplug29.fc46.aarch64.rpm mst-hotplug29 \
            'MST allocation, two unwind cases and two firmware-free virtual DDC adapters passed' \
            "${patches[0]##*/}" "${patches[1]##*/}"
        verify_proof "$sst" uke-kernel-migration-check-7.3.5-53.uke_dp_sst420_29.fc46.aarch64.rpm dp-sst420-29 \
            'Twelve SST format cases passed, including 6-bpc RGB fallback at 594 MHz' "${patches[2]##*/}"
        git apply --check --whitespace=error "${patches[@]}"
        git apply --whitespace=error "${patches[@]}"
        check_files after
        ;;
    restore)
        check_files after
        git apply --reverse --check --whitespace=error "${patches[@]}"
        git apply --reverse --whitespace=error "${patches[@]}"
        check_files before
        ;;
    *) exit 2 ;;
esac
