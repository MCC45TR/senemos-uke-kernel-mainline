/* SPDX-License-Identifier: GPL-2.0-only */
#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

typedef uint32_t u32;
struct device_driver { unsigned int tag; };
struct device {
    struct device_driver *driver;
    void *data;
    bool locked, busy;
    unsigned int refs;
};
struct platform_device { struct device dev; };
struct device_node { unsigned int refs; };
struct power_supply { unsigned int tag; };
union power_supply_propval {int intval;};
struct qcom_battmgr_uke_transaction {
    unsigned int lock;
    u32 generation;
    bool desynced, suspended, removing;
};
struct qcom_battmgr {
    struct qcom_battmgr_uke_transaction transaction;
    struct power_supply *bat_psy;
    unsigned int variant;
    bool service_up;
};
static struct { struct device_driver driver; } qcom_battmgr_driver;
static struct device_driver other_driver;
static struct device supplier;
static struct platform_device controller;
static struct device_node node;
static struct power_supply pack, replacement;
static struct qcom_battmgr battery;
static unsigned int requests, dt_reads;
static bool is_uke, is_sm7675, has_node, matches_node, has_parent, has_supplier;
static int returned_error, sample_uv;
#define READ_ONCE(value) (value)
#define QCOM_BATTMGR_UKE 7
#define POWER_SUPPLY_PROP_VOLTAGE_NOW 5
#define lockdep_assert_held(lock) assert(*(lock) == 1)
#define spin_lock_irqsave(lock, flags) do { assert(*(lock) == 0); *(lock) = 1; (flags) = 1; } while (0)
#define spin_unlock_irqrestore(lock, flags) do { assert(*(lock) == 1 && (flags) == 1); *(lock) = 0; } while (0)

enum transition { UNCHANGED, NEW_GENERATION, BECAME_UNAVAILABLE, NEW_PACK };
static enum transition transition;

enum power_supply_prop { TEST_POWER_PROP_VOLTAGE = POWER_SUPPLY_PROP_VOLTAGE_NOW };

static int device_trylock(struct device *dev)
{
    assert(dev->refs && !dev->locked);
    if (dev == &supplier)
        assert(controller.dev.locked && controller.dev.refs);
    if (dev->busy)
        return 0;
    dev->locked = true;
    return 1;
}

static void device_unlock(struct device *dev)
{
    assert(dev->refs && dev->locked);
    if (dev == &controller.dev)
        assert(!supplier.locked && !supplier.refs);
    dev->locked = false;
}

static void *dev_get_drvdata(struct device *dev)
{
    assert(dev == &supplier && dev->locked && controller.dev.locked);
    return dev->data;
}

static struct device *device_find_child(struct device *dev, const void *data,
                    int (*match)(struct device *, const void *))
{
    assert(dev == &controller.dev && dev->locked && dev->refs);
    assert(data == &qcom_battmgr_driver.driver);
    assert(!match(&controller.dev, data));
    if (!has_supplier || !match(&supplier, data))
        return NULL;
    supplier.refs++;
    return &supplier;
}

static void put_device(struct device *dev)
{
    assert(dev->refs == 1 && !dev->locked);
    if (dev == &supplier)
        assert(controller.dev.locked);
    dev->refs--;
}

static bool of_machine_is_compatible(const char *compatible)
{
    if (!strcmp(compatible, "xiaomi,uke"))
        return is_uke;
    assert(!strcmp(compatible, "qcom,sm7675"));
    return is_sm7675;
}

static struct device_node *of_find_node_by_path(const char *path)
{
    assert(!strcmp(path, "/pmic-glink") && !node.refs);
    dt_reads++;
    if (!has_node)
        return NULL;
    node.refs++;
    return &node;
}

static bool of_device_is_compatible(struct device_node *np, const char *compatible)
{
    assert(np == &node && np->refs == 1);
    assert(!strcmp(compatible, "xiaomi,uke-typec-pmic-glink"));
    return matches_node;
}

static struct platform_device *of_find_device_by_node(struct device_node *np)
{
    assert(np == &node && np->refs == 1 && !controller.dev.refs);
    if (!has_parent)
        return NULL;
    controller.dev.refs++;
    return &controller;
}

static void of_node_put(struct device_node *np)
{
    assert(np == &node && np->refs == 1);
    np->refs--;
}

static int qcom_battmgr_uke_get_pack_meter(struct power_supply *psy, int property,
                     union power_supply_propval *voltage)
{
    assert(psy == &pack && property == TEST_POWER_PROP_VOLTAGE);
    assert(battery.bat_psy == psy && battery.service_up);
    assert(supplier.locked && supplier.refs == 1);
    assert(controller.dev.locked && controller.dev.refs == 1);
    assert(battery.transaction.lock == 0);
    requests++;
    voltage->intval = sample_uv;
    if (transition == NEW_GENERATION)
        battery.transaction.generation++;
    if (transition == BECAME_UNAVAILABLE)
        battery.service_up = false;
    if (transition == NEW_PACK)
        battery.bat_psy = &replacement;
    return returned_error;
}

#include "functions.h"

static void reset_fixture(void)
{
    controller.dev = (struct device){ .driver = &other_driver };
    supplier = (struct device){ .driver = &qcom_battmgr_driver.driver, .data = &battery };
    battery = (struct qcom_battmgr){ .variant = QCOM_BATTMGR_UKE, .service_up = true, .bat_psy = &pack };
    battery.transaction.generation = 4;
    is_uke = is_sm7675 = has_node = matches_node = has_parent = has_supplier = true;
    requests = dt_reads = node.refs = 0;
    returned_error = 0;
    sample_uv = 4204008;
    transition = UNCHANGED;
}

static void expect(int ret, unsigned int wire_reads)
{
    int value = -1234;
    assert(qcom_battmgr_uke_read_pack_voltage_uv(&value) == ret);
    assert(value == (ret ? -1234 : sample_uv));
    assert(requests == wire_reads);
    assert(!node.refs && !supplier.refs && !controller.dev.refs);
    assert(!supplier.locked && !controller.dev.locked && !battery.transaction.lock);
}

int main(void)
{
    reset_fixture(); expect(0, 1);
    reset_fixture(); sample_uv = 0; expect(-ENODATA, 1);
    reset_fixture(); sample_uv = -1; expect(-ENODATA, 1);
    reset_fixture(); returned_error = -ETIMEDOUT; expect(-ETIMEDOUT, 1);
    reset_fixture(); transition = NEW_GENERATION; expect(-ESTALE, 1);
    reset_fixture(); transition = NEW_PACK; expect(-ESTALE, 1);
    reset_fixture(); transition = BECAME_UNAVAILABLE; expect(-ESTALE, 1);
    reset_fixture(); assert(qcom_battmgr_uke_read_pack_voltage_uv(NULL) == -EINVAL && !dt_reads);
    reset_fixture(); is_uke = false; expect(-ENODEV, 0); assert(!dt_reads);
    reset_fixture(); is_sm7675 = false; expect(-ENODEV, 0); assert(!dt_reads);
    reset_fixture(); has_node = false; expect(-ENODEV, 0);
    reset_fixture(); matches_node = false; expect(-ENODEV, 0);
    reset_fixture(); has_parent = false; expect(-ENODEV, 0);
    reset_fixture(); has_supplier = false; expect(-ENODEV, 0);
    reset_fixture(); supplier.driver = &other_driver; expect(-ENODEV, 0);
    reset_fixture(); supplier.data = NULL; expect(-ENODEV, 0);
    reset_fixture(); battery.variant = 1; expect(-ENODEV, 0);
    reset_fixture(); controller.dev.busy = true; expect(-EAGAIN, 0);
    reset_fixture(); supplier.busy = true; expect(-EAGAIN, 0);
    reset_fixture(); battery.bat_psy = NULL; expect(-EAGAIN, 0);
    reset_fixture(); battery.service_up = false; expect(-EAGAIN, 0);
    reset_fixture(); battery.transaction.suspended = true; expect(-EAGAIN, 0);
    reset_fixture(); battery.transaction.desynced = true; expect(-EAGAIN, 0);
    reset_fixture(); battery.transaction.removing = true; expect(-EAGAIN, 0);
    puts("Uke pack voltage: single committed-provider read, parent and child lifetime, transition and fault cases passed (24 cases).");
    return 0;
}
