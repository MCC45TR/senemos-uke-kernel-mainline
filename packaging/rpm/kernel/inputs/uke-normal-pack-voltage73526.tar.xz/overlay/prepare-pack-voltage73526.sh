#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C
[[ $# == 2 || $# == 3 ]]
phase=$1
tree=$(realpath -e -- "$2")
assets=$(cd -- "$(dirname -- "$0")" && pwd)
patch="$assets/0030-uke-pack-voltage-for-audio.patch"
module=drivers/power/supply/qcom_battmgr.ko

check_receipt() {
    local proof file digest
    (cd "$assets"; sha256sum --strict -c --quiet SHA256SUMS)
    proof=$(rpm2cpio "$assets/uke-kernel-migration-check-7.3.5-37.pack_voltage26.fc46.aarch64.rpm" |
        cpio -i --quiet --to-stdout ./usr/share/uke-kernel-migration-check/pack-voltage73526/qualification.txt)
    grep -Fxq 'Exact signed normal 7.3.5-26 source, COPR 11368308.' <<< "$proof"
    grep -Fxq 'Native ARM64 QCOM battery object and GPL pack-voltage symbol verified. Source reverses to signed preimage.' <<< "$proof"
    [[ $(grep -Fc 'transition and fault cases passed (24 cases).' <<< "$proof") == 4 ]]
    for file in "$patch" "$assets/before.sha256" "$assets/after.sha256" "$assets/check-voltage.sh" "$assets/voltage-test.c"; do
        read -r digest _ < <(sha256sum "$file")
        grep -Fxq "$digest  ./${file##*/}" <<< "$proof"
    done
}

cd -- "$tree"
case $phase in
    prepare)
        [[ $# == 2 ]]
        check_receipt
        sha256sum --strict -c "$assets/before.sha256"
        git apply --check --whitespace=error "$patch"
        git apply --whitespace=error "$patch"
        sha256sum --strict -c "$assets/after.sha256"
        CC=gcc bash "$assets/check-voltage.sh" "$PWD"
        ;;
    linked)
        [[ $# == 3 && $3 =~ ^[0-9]+\.[0-9]+\.[0-9]+-[0-9]+$ ]]
        grep -Fxq 'CONFIG_BATTERY_QCOM_BATTMGR=m' .config
        grep -Fxq 'CONFIG_OF=y' .config
        readelf -h "$module" | grep -F AArch64
        [[ $(modinfo -F vermagic "$module") == "$3 "* ]]
        readelf -Ws "$module" | awk '
            $4=="FUNC" && $7!="UND" && $8=="qcom_battmgr_uke_read_pack_voltage_uv" { fn++ }
            $7!="UND" && $8=="__ksymtab_qcom_battmgr_uke_read_pack_voltage_uv" { exported++ }
            END { exit !(fn==1 && exported==1) }
        '
        sha256sum "$module"
        ;;
    restore)
        [[ $# == 2 ]]
        sha256sum --strict -c "$assets/after.sha256"
        git apply --reverse --check --whitespace=error "$patch"
        git apply --reverse --whitespace=error "$patch"
        sha256sum --strict -c "$assets/before.sha256"
        [[ ! -e include/linux/power/uke-pack-voltage.h ]]
        ;;
    *) exit 2 ;;
esac
