#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C
[[ $# == 1 ]]
source_tree=$(realpath -e "$1")
inputs=$(dirname "$(realpath -e "$0")")
work=$(mktemp -d)
trap 'find "$work" -depth -delete' EXIT
awk '
    /^(static (bool qcom_battmgr_uke_can_publish|int qcom_battmgr_uke_(match_supplier|read_live_voltage))|int qcom_battmgr_uke_read_pack_voltage_uv)\(/ {copy=1}
    copy {print}
    copy && /^}/ {copy=0; count++}
    END { exit count!=4 }
' "$source_tree/drivers/power/supply/qcom_battmgr.c" > "$work/functions.h"
flags=()
if [[ ${UKE_SANITIZE:-0} == 1 ]]; then
    flags+=(-fsanitize=address,undefined -fno-sanitize-recover=all -fno-omit-frame-pointer -no-pie)
fi
"${CC:-gcc}" -std=gnu11 -O2 -g -UNDEBUG -Wall -Wextra -Werror "${flags[@]}" -I "$work" "$inputs/voltage-test.c" -o "$work/test"
ulimit -c 0
timeout 30s "$work/test"
