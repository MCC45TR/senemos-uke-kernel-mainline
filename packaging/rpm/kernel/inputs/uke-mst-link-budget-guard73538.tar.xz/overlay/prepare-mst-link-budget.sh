#!/usr/bin/bash
set -Eeuo pipefail
export LC_ALL=C
[[ $# == 2 ]]
assets=$(cd -- "$(dirname -- "$0")" && pwd)
tree=$(realpath -e -- "$2")
patch="$assets/msm-mst-reject-zero-link-budget.patch"
key=2204a661ea630a5303500085538797e72a3e4eca
proof="$assets/uke-kernel-migration-check-7.3.5-72.uke_mst_link_budget38.fc46.aarch64.rpm"
receipt_member=./usr/share/uke-kernel-migration-check/mst-link-budget38/qualification.txt

cd -- "$tree"
(cd -- "$assets" && sha256sum -c --strict --quiet SHA256SUMS)
case $1 in
    prepare)
        sha256sum -c --strict "$assets/link-budget-before.sha256"
        [[ $(gpg --batch --with-colons --show-keys "$assets/parent-key.gpg" |
            awk -F: '$1=="fpr"{print tolower($10);exit}') == "$key" ]]
        trust=$(mktemp -d --tmpdir="$tree" .mst-link-budget.XXXXXXXX)
        trap 'find "$trust" -maxdepth 1 -type f -delete; rmdir -- "$trust"' EXIT
        rpmkeys --dbpath "$trust" --import "$assets/parent-key.gpg"
        rpmkeys --dbpath "$trust" --checksig -v "$proof" > "$trust/signatures"
        [[ $(grep -Fc "key fingerprint: $key: OK" "$trust/signatures") == 2 ]]
        ! grep -Eq 'NOKEY|BAD|NOT OK' "$trust/signatures"
        rpm2cpio "$proof" | cpio -i --quiet --to-stdout "$receipt_member" > "$trust/qualification.txt"
        [[ $(grep -Fxc 'Seven MST link-budget transition cases passed.' "$trust/qualification.txt") == 4 ]]
        grep -Fxq 'Two native AArch64 MST objects and exact source inverse verified.' "$trust/qualification.txt"
        for digest in parent link-budget-before link-budget-after; do
            while IFS= read -r line; do
                grep -Fxq -- "$line" "$trust/qualification.txt"
            done < "$assets/$digest.sha256"
        done
        git apply --check --whitespace=error "$patch"
        git apply --whitespace=error "$patch"
        sha256sum -c --strict "$assets/link-budget-after.sha256"
        ;;
    restore)
        sha256sum -c --strict "$assets/link-budget-after.sha256"
        git apply --reverse --check --whitespace=error "$patch"
        git apply --reverse --whitespace=error "$patch"
        sha256sum -c --strict "$assets/link-budget-before.sha256"
        ;;
    *) exit 2 ;;
esac
